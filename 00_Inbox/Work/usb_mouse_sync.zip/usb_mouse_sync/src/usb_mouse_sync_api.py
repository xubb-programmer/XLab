#!/usr/bin/env python3
"""Local HTTP API for managing usb-mouse-sync configuration."""

import json
import logging
import os
import re
import subprocess
import tempfile
import threading
from dataclasses import dataclass
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse

from usb_hid_actions import ActionError, HidActionExecutor, HidActionSettings, list_action_names

ASSIGN_RE = re.compile(r"^\s*([A-Z0-9_]+)\s*=(.*)$")

CONFIG_SPEC: Dict[str, Dict[str, Any]] = {
    "UDC_NAME": {"type": "string"},
    "RECLAIM_UDC": {"type": "bool"},
    "UDC_STATE_PATH": {"type": "string"},
    "EVENT_DEVICE": {"type": "string"},
    "ENABLE_HID_OUTPUT": {"type": "bool"},
    "ENABLE_INPUT_BRIDGE": {"type": "bool"},
    "ENABLE_NETWORK": {"type": "bool"},
    "INPUT_PRIORITY": {"type": "enum", "choices": ["local", "network", "auto"]},
    "LOCAL_IDLE_TIMEOUT_MS": {"type": "int", "min": 0},
    "AUTO_REBIND_EVENT": {"type": "bool"},
    "ENABLE_KEYBOARD_SYNC": {"type": "bool"},
    "KEYBOARD_EVENT_DEVICE": {"type": "string"},
    "AUTO_REBIND_KEYBOARD_EVENT": {"type": "bool"},
    "NETWORK_ROLE": {"type": "enum", "choices": ["client", "server"]},
    "NETWORK_HOST": {"type": "string"},
    "NETWORK_PORT": {"type": "int", "min": 1, "max": 65535},
    "NETWORK_RETRY_MS": {"type": "int", "min": 0},
    "NETWORK_CONNECT_TIMEOUT_MS": {"type": "int", "min": 0},
    "NETWORK_QUEUE_SIZE": {"type": "int", "min": 1},
    "ENABLE_ACTION_TCP": {"type": "bool"},
    "ACTION_TCP_HOST": {"type": "string"},
    "ACTION_TCP_PORT": {"type": "int", "min": 1, "max": 65535},
    "ACTION_TCP_MAX_LINE_BYTES": {"type": "int", "min": 256},
    "ACTION_TCP_QUEUE_SIZE": {"type": "int", "min": 1},
    "ENABLE_ACTION_UDP": {"type": "bool"},
    "ACTION_UDP_HOST": {"type": "string"},
    "ACTION_UDP_PORT": {"type": "int", "min": 1, "max": 65535},
    "ACTION_UDP_MAX_DATAGRAM_BYTES": {"type": "int", "min": 256, "max": 65507},
    "ACTIONS_CONFIG_PATH": {"type": "string"},
    "HIDG_DEVICE": {"type": "string"},
    "KEYBOARD_HIDG_DEVICE": {"type": "string"},
    "HID_LOCK_PATH": {"type": "string"},
    "HID_PROFILE": {"type": "enum", "choices": ["extended5", "boot3"]},
    "HOME_ON_CONNECT": {"type": "bool"},
    "HOME_STEPS": {"type": "int", "min": 1},
    "START_BIAS_X": {"type": "int"},
    "START_BIAS_Y": {"type": "int"},
    "MOUSE_MODE": {"type": "enum", "choices": ["relative", "absolute-map"]},
    "SRC_WIDTH": {"type": "int", "min": 1},
    "SRC_HEIGHT": {"type": "int", "min": 1},
    "SRC_OFFSET_X": {"type": "int"},
    "SRC_OFFSET_Y": {"type": "int"},
    "DST_WIDTH": {"type": "int", "min": 1},
    "DST_HEIGHT": {"type": "int", "min": 1},
    "DST_OFFSET_X": {"type": "int", "min": 0},
    "DST_OFFSET_Y": {"type": "int", "min": 0},
    "DST_ACTIVE_WIDTH": {"type": "int", "min": 0},
    "DST_ACTIVE_HEIGHT": {"type": "int", "min": 0},
    "USE_CURSOR_QUERY": {"type": "bool"},
    "CURSOR_QUERY_CMD": {"type": "string"},
    "CURSOR_QUERY_USER": {"type": "string"},
    "CURSOR_DISPLAY": {"type": "string"},
    "CURSOR_XAUTHORITY": {"type": "string"},
    "CURSOR_XDG_RUNTIME_DIR": {"type": "string"},
    "CURSOR_TIMEOUT_MS": {"type": "int", "min": 0},
    "ALIGN_ON_CONNECT": {"type": "bool"},
    "CONNECT_SETTLE_MS": {"type": "int", "min": 0},
    "HOME_ROUNDS": {"type": "int", "min": 1},
    "ALIGN_RETRIES": {"type": "int", "min": 1},
    "ALIGN_RETRY_INTERVAL_MS": {"type": "int", "min": 0},
    "ALIGN_STEP_MAX": {"type": "int", "min": 1},
    "ALIGN_STEP_SLEEP_MS": {"type": "int", "min": 0},
    "SOURCE_HOME_ON_CONNECT": {"type": "bool"},
    "STRICT_ABSOLUTE_QUERY": {"type": "bool"},
    "MOVE_SCALE": {"type": "float"},
    "WHEEL_SCALE": {"type": "float"},
    "READ_CHUNK_EVENTS": {"type": "int", "min": 1},
    "USB_VID": {"type": "string"},
    "USB_PID": {"type": "string"},
    "USB_BCD_DEVICE": {"type": "string"},
    "USB_BCD_USB": {"type": "string"},
    "USB_SERIAL": {"type": "string"},
    "USB_MANUFACTURER": {"type": "string"},
    "USB_PRODUCT": {"type": "string"},
    "LOG_LEVEL": {"type": "enum", "choices": ["DEBUG", "INFO", "WARNING", "ERROR"]},
}

BOOL_TRUE = {"1", "true", "yes", "on"}
BOOL_FALSE = {"0", "false", "no", "off"}


@dataclass
class ApiSettings:
    bind_host: str
    port: int
    auth_token: str
    config_path: str
    target_service: str
    actions_config_path: str


def load_settings() -> ApiSettings:
    return ApiSettings(
        bind_host=os.environ.get("API_BIND_HOST", "127.0.0.1"),
        port=int(os.environ.get("API_PORT", "18081")),
        auth_token=os.environ.get("API_AUTH_TOKEN", "").strip(),
        config_path=os.environ.get("TARGET_CONFIG_PATH", "/etc/default/usb-mouse-sync"),
        target_service=os.environ.get("TARGET_SERVICE_NAME", "usb-mouse-sync.service"),
        actions_config_path=os.environ.get("ACTIONS_CONFIG_PATH", "/etc/usb-mouse-sync/actions.json"),
    )


def parse_config_file(path: str) -> Dict[str, str]:
    values: Dict[str, str] = {}
    if not os.path.exists(path):
        return values
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            match = ASSIGN_RE.match(line)
            if not match:
                continue
            values[match.group(1)] = match.group(2).strip()
    return values


def normalize_scalar(key: str, value: Any) -> Optional[str]:
    if key not in CONFIG_SPEC:
        raise ValueError(f"Unsupported config key: {key}")
    if value is None:
        return None

    spec = CONFIG_SPEC[key]
    kind = spec["type"]

    if kind == "bool":
        if isinstance(value, bool):
            return "1" if value else "0"
        normalized = str(value).strip().lower()
        if normalized in BOOL_TRUE:
            return "1"
        if normalized in BOOL_FALSE:
            return "0"
        raise ValueError(f"{key} must be a boolean-like value")

    if kind == "enum":
        normalized = str(value).strip()
        if normalized not in spec["choices"]:
            raise ValueError(f"{key} must be one of {spec['choices']}")
        return normalized

    if kind == "int":
        try:
            normalized_int = int(value)
        except (TypeError, ValueError):
            raise ValueError(f"{key} must be an integer") from None
        if "min" in spec and normalized_int < spec["min"]:
            raise ValueError(f"{key} must be >= {spec['min']}")
        if "max" in spec and normalized_int > spec["max"]:
            raise ValueError(f"{key} must be <= {spec['max']}")
        return str(normalized_int)

    if kind == "float":
        try:
            normalized_float = float(value)
        except (TypeError, ValueError):
            raise ValueError(f"{key} must be a float") from None
        return str(normalized_float)

    normalized = str(value)
    if any(ch in normalized for ch in ("\n", "\r", "\0")):
        raise ValueError(f"{key} contains an invalid character")
    return normalized


def normalize_updates(payload: Dict[str, Any]) -> Dict[str, Optional[str]]:
    normalized: Dict[str, Optional[str]] = {}
    for key, value in payload.items():
        normalized[key] = normalize_scalar(key, value)
    return normalized


def update_config_file(path: str, updates: Dict[str, Optional[str]]) -> None:
    existing_mode = 0o644
    lines: List[str] = []
    if os.path.exists(path):
        st = os.stat(path)
        existing_mode = st.st_mode & 0o777
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()

    seen = set()
    output: List[str] = []
    for line in lines:
        stripped = line.strip()
        if stripped and not stripped.startswith("#"):
            match = ASSIGN_RE.match(line)
            if match:
                key = match.group(1)
                if key in updates:
                    seen.add(key)
                    value = updates[key]
                    if value is None:
                        continue
                    output.append(f"{key}={value}\n")
                    continue
        output.append(line)

    missing = [(key, value) for key, value in updates.items() if key not in seen and value is not None]
    if missing:
        if output and output[-1].strip():
            output.append("\n")
        for key, value in missing:
            output.append(f"{key}={value}\n")

    directory = os.path.dirname(path) or "."
    fd, temp_path = tempfile.mkstemp(prefix=".usb-mouse-sync.", dir=directory, text=True)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as tmp:
            tmp.writelines(output)
            tmp.flush()
            os.fsync(tmp.fileno())
        os.chmod(temp_path, existing_mode)
        os.replace(temp_path, path)
    finally:
        if os.path.exists(temp_path):
            os.unlink(temp_path)


def run_systemctl(*args: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["systemctl", *args],
        capture_output=True,
        text=True,
        check=False,
    )


def get_service_status(service_name: str) -> Dict[str, str]:
    active = run_systemctl("is-active", service_name)
    enabled = run_systemctl("is-enabled", service_name)
    return {
        "active": (active.stdout.strip() or active.stderr.strip() or "unknown"),
        "enabled": (enabled.stdout.strip() or enabled.stderr.strip() or "unknown"),
    }


class ConfigApi:
    def __init__(self, settings: ApiSettings) -> None:
        self.settings = settings
        self.lock = threading.Lock()

    def actions_config_path(self) -> str:
        bridge_config = parse_config_file(self.settings.config_path)
        return bridge_config.get("ACTIONS_CONFIG_PATH", self.settings.actions_config_path)

    def read_config(self) -> Dict[str, Any]:
        return {
            "values": parse_config_file(self.settings.config_path),
            "service": {
                **get_service_status(self.settings.target_service),
            },
        }

    def update_config(self, values: Dict[str, Any], restart: bool) -> Dict[str, Any]:
        normalized = normalize_updates(values)
        with self.lock:
            update_config_file(self.settings.config_path, normalized)
            result = self.read_config()
            if restart:
                restart_result = self.restart_service_locked()
                result["restart"] = restart_result
        return result

    def restart_service(self) -> Dict[str, Any]:
        with self.lock:
            return self.restart_service_locked()

    def restart_service_locked(self) -> Dict[str, Any]:
        proc = run_systemctl("restart", self.settings.target_service)
        payload = {
            "ok": proc.returncode == 0,
            "returncode": proc.returncode,
            "stdout": proc.stdout.strip(),
            "stderr": proc.stderr.strip(),
            "service": {
                "name": self.settings.target_service,
                **get_service_status(self.settings.target_service),
            },
        }
        return payload

    def list_actions(self) -> Dict[str, Any]:
        config_path = self.actions_config_path()
        return {
            "config_path": config_path,
            "actions": list_action_names(config_path),
        }

    def run_action(self, name: str, params: Dict[str, Any]) -> Dict[str, Any]:
        bridge_config = parse_config_file(self.settings.config_path)
        actions_config_path = bridge_config.get("ACTIONS_CONFIG_PATH", self.settings.actions_config_path)
        action_settings = HidActionSettings(
            config_path=actions_config_path,
            mouse_hidg_path=bridge_config.get("HIDG_DEVICE", "/dev/hidg0"),
            keyboard_hidg_path=bridge_config.get("KEYBOARD_HIDG_DEVICE", "/dev/hidg1"),
            hid_profile=bridge_config.get("HID_PROFILE", "extended5"),
            hid_lock_path=bridge_config.get("HID_LOCK_PATH", "/run/lock/usb-mouse-sync-hid.lock"),
            udc_state_path=bridge_config.get("UDC_STATE_PATH", "/sys/class/udc/fc000000.usb/state"),
        )
        with HidActionExecutor(action_settings) as executor:
            return executor.run_named_action(name, params)


class RequestHandler(BaseHTTPRequestHandler):
    server_version = "UsbMouseSyncApi/1.0"

    def _api(self) -> ConfigApi:
        return self.server.api  # type: ignore[attr-defined]

    def _settings(self) -> ApiSettings:
        return self.server.settings  # type: ignore[attr-defined]

    def log_message(self, fmt: str, *args) -> None:
        logging.info("%s - %s", self.address_string(), fmt % args)

    def _check_auth(self) -> bool:
        token = self._settings().auth_token
        if not token:
            return True
        header = self.headers.get("Authorization", "")
        if header == f"Bearer {token}":
            return True
        self._write_json(HTTPStatus.UNAUTHORIZED, {"error": "unauthorized"})
        return False

    def _read_json(self) -> Dict[str, Any]:
        content_length = int(self.headers.get("Content-Length", "0") or "0")
        if content_length <= 0:
            return {}
        raw = self.rfile.read(content_length)
        if not raw:
            return {}
        try:
            data = json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"invalid json: {exc}") from None
        if not isinstance(data, dict):
            raise ValueError("json body must be an object")
        return data

    def _write_json(self, status: HTTPStatus, payload: Dict[str, Any]) -> None:
        body = json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
        self.send_response(status.value)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        if not self._check_auth():
            return
        path = urlparse(self.path).path
        if path in {"/health", "/healthz"}:
            self._write_json(HTTPStatus.OK, {"ok": True})
            return
        if path == "/api/v1/config":
            self._write_json(HTTPStatus.OK, self._api().read_config())
            return
        if path == "/api/v1/schema":
            self._write_json(
                HTTPStatus.OK,
                {
                    "config_path": self._settings().config_path,
                    "service_name": self._settings().target_service,
                    "actions_config_path": self._api().actions_config_path(),
                    "schema": CONFIG_SPEC,
                },
            )
            return
        if path == "/api/v1/actions":
            try:
                result = self._api().list_actions()
            except (OSError, json.JSONDecodeError, ActionError) as exc:
                self._write_json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": str(exc)})
                return
            self._write_json(HTTPStatus.OK, result)
            return
        self._write_json(HTTPStatus.NOT_FOUND, {"error": "not found"})

    def do_PATCH(self) -> None:
        self._handle_update()

    def do_PUT(self) -> None:
        self._handle_update()

    def _handle_update(self) -> None:
        if not self._check_auth():
            return
        path = urlparse(self.path).path
        if path != "/api/v1/config":
            self._write_json(HTTPStatus.NOT_FOUND, {"error": "not found"})
            return
        try:
            body = self._read_json()
            values = body.get("values")
            restart = body.get("restart", True)
            if not isinstance(values, dict):
                raise ValueError("values must be an object")
            if not isinstance(restart, bool):
                raise ValueError("restart must be a boolean")
            result = self._api().update_config(values, restart=restart)
        except ValueError as exc:
            self._write_json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
            return
        status = HTTPStatus.OK
        restart_result = result.get("restart")
        if isinstance(restart_result, dict) and not restart_result.get("ok", True):
            status = HTTPStatus.INTERNAL_SERVER_ERROR
        self._write_json(status, result)

    def do_POST(self) -> None:
        if not self._check_auth():
            return
        path = urlparse(self.path).path
        if path != "/api/v1/restart":
            prefix = "/api/v1/actions/"
            suffix = "/run"
            if path.startswith(prefix) and path.endswith(suffix):
                action_name = path[len(prefix) : -len(suffix)]
                if not action_name:
                    self._write_json(HTTPStatus.NOT_FOUND, {"error": "not found"})
                    return
                try:
                    body = self._read_json()
                    params = body.get("params", {})
                    if not isinstance(params, dict):
                        raise ValueError("params must be an object")
                    result = self._api().run_action(action_name, params)
                except ValueError as exc:
                    self._write_json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
                    return
                except FileNotFoundError as exc:
                    self._write_json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": f"file not found: {exc.filename}"})
                    return
                except (OSError, json.JSONDecodeError, ActionError) as exc:
                    self._write_json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": str(exc)})
                    return
                self._write_json(HTTPStatus.OK, result)
                return
            self._write_json(HTTPStatus.NOT_FOUND, {"error": "not found"})
            return
        result = self._api().restart_service()
        status = HTTPStatus.OK if result.get("ok") else HTTPStatus.INTERNAL_SERVER_ERROR
        self._write_json(status, result)


class ApiServer(ThreadingHTTPServer):
    def __init__(self, server_address, handler_cls, settings: ApiSettings, api: ConfigApi):
        super().__init__(server_address, handler_cls)
        self.settings = settings
        self.api = api


def main() -> int:
    settings = load_settings()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    api = ConfigApi(settings)
    server = ApiServer((settings.bind_host, settings.port), RequestHandler, settings, api)
    logging.info(
        "Config API listening on %s:%d config=%s target_service=%s auth=%s",
        settings.bind_host,
        settings.port,
        settings.config_path,
        settings.target_service,
        "enabled" if settings.auth_token else "disabled",
    )
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
