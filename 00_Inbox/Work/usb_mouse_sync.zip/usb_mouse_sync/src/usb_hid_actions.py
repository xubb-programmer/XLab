#!/usr/bin/env python3
"""Execute configured one-shot HID mouse/keyboard actions."""

import fcntl
import errno
import json
import os
import string
import threading
import time
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple


class ActionError(ValueError):
    pass


DEFAULT_HID_LOCK_PATH = "/run/lock/usb-mouse-sync-hid.lock"
_HID_THREAD_LOCK = threading.RLock()


class HidOutputLock:
    """Serialize HID writes both within this process and across processes."""

    def __init__(self, path: str = DEFAULT_HID_LOCK_PATH) -> None:
        self.path = path or DEFAULT_HID_LOCK_PATH
        self._fd: Optional[int] = None

    def __enter__(self) -> "HidOutputLock":
        _HID_THREAD_LOCK.acquire()
        try:
            parent = os.path.dirname(self.path)
            if parent:
                os.makedirs(parent, exist_ok=True)
            self._fd = os.open(
                self.path,
                os.O_CREAT | os.O_RDWR | os.O_CLOEXEC,
                0o666,
            )
            fcntl.flock(self._fd, fcntl.LOCK_EX)
            return self
        except BaseException:
            if self._fd is not None:
                try:
                    os.close(self._fd)
                except OSError:
                    pass
                self._fd = None
            _HID_THREAD_LOCK.release()
            raise

    def __exit__(self, _exc_type, _exc, _tb) -> None:
        try:
            if self._fd is not None:
                try:
                    fcntl.flock(self._fd, fcntl.LOCK_UN)
                finally:
                    os.close(self._fd)
                    self._fd = None
        finally:
            _HID_THREAD_LOCK.release()


@dataclass
class HidActionSettings:
    config_path: str = "/etc/usb-mouse-sync/actions.json"
    mouse_hidg_path: str = "/dev/hidg0"
    keyboard_hidg_path: str = "/dev/hidg1"
    hid_profile: str = "boot3"
    hid_lock_path: str = DEFAULT_HID_LOCK_PATH
    udc_state_path: str = ""
    udc_ready_timeout_ms: int = 5000
    default_delay_ms: int = 40
    key_press_ms: int = 30
    mouse_step_delay_ms: int = 5


MOUSE_BUTTONS = {
    "left": 0x01,
    "right": 0x02,
    "middle": 0x04,
    "side": 0x08,
    "extra": 0x10,
}

MODIFIER_KEYS = {
    "left_ctrl": 0x01,
    "ctrl": 0x01,
    "control": 0x01,
    "left_shift": 0x02,
    "shift": 0x02,
    "left_alt": 0x04,
    "alt": 0x04,
    "left_gui": 0x08,
    "gui": 0x08,
    "win": 0x08,
    "windows": 0x08,
    "right_ctrl": 0x10,
    "right_shift": 0x20,
    "right_alt": 0x40,
    "right_gui": 0x80,
}

KEY_USAGES = {
    "a": 0x04,
    "b": 0x05,
    "c": 0x06,
    "d": 0x07,
    "e": 0x08,
    "f": 0x09,
    "g": 0x0A,
    "h": 0x0B,
    "i": 0x0C,
    "j": 0x0D,
    "k": 0x0E,
    "l": 0x0F,
    "m": 0x10,
    "n": 0x11,
    "o": 0x12,
    "p": 0x13,
    "q": 0x14,
    "r": 0x15,
    "s": 0x16,
    "t": 0x17,
    "u": 0x18,
    "v": 0x19,
    "w": 0x1A,
    "x": 0x1B,
    "y": 0x1C,
    "z": 0x1D,
    "1": 0x1E,
    "2": 0x1F,
    "3": 0x20,
    "4": 0x21,
    "5": 0x22,
    "6": 0x23,
    "7": 0x24,
    "8": 0x25,
    "9": 0x26,
    "0": 0x27,
    "enter": 0x28,
    "return": 0x28,
    "esc": 0x29,
    "escape": 0x29,
    "backspace": 0x2A,
    "tab": 0x2B,
    "space": 0x2C,
    "minus": 0x2D,
    "equal": 0x2E,
    "left_bracket": 0x2F,
    "right_bracket": 0x30,
    "backslash": 0x31,
    "semicolon": 0x33,
    "quote": 0x34,
    "grave": 0x35,
    "comma": 0x36,
    "dot": 0x37,
    "period": 0x37,
    "slash": 0x38,
    "capslock": 0x39,
    "f1": 0x3A,
    "f2": 0x3B,
    "f3": 0x3C,
    "f4": 0x3D,
    "f5": 0x3E,
    "f6": 0x3F,
    "f7": 0x40,
    "f8": 0x41,
    "f9": 0x42,
    "f10": 0x43,
    "f11": 0x44,
    "f12": 0x45,
    "printscreen": 0x46,
    "scrolllock": 0x47,
    "pause": 0x48,
    "insert": 0x49,
    "home": 0x4A,
    "pageup": 0x4B,
    "delete": 0x4C,
    "end": 0x4D,
    "pagedown": 0x4E,
    "right": 0x4F,
    "left": 0x50,
    "down": 0x51,
    "up": 0x52,
}

CHAR_TO_KEY = {
    "a": (0, 0x04),
    "b": (0, 0x05),
    "c": (0, 0x06),
    "d": (0, 0x07),
    "e": (0, 0x08),
    "f": (0, 0x09),
    "g": (0, 0x0A),
    "h": (0, 0x0B),
    "i": (0, 0x0C),
    "j": (0, 0x0D),
    "k": (0, 0x0E),
    "l": (0, 0x0F),
    "m": (0, 0x10),
    "n": (0, 0x11),
    "o": (0, 0x12),
    "p": (0, 0x13),
    "q": (0, 0x14),
    "r": (0, 0x15),
    "s": (0, 0x16),
    "t": (0, 0x17),
    "u": (0, 0x18),
    "v": (0, 0x19),
    "w": (0, 0x1A),
    "x": (0, 0x1B),
    "y": (0, 0x1C),
    "z": (0, 0x1D),
    "A": (0x02, 0x04),
    "B": (0x02, 0x05),
    "C": (0x02, 0x06),
    "D": (0x02, 0x07),
    "E": (0x02, 0x08),
    "F": (0x02, 0x09),
    "G": (0x02, 0x0A),
    "H": (0x02, 0x0B),
    "I": (0x02, 0x0C),
    "J": (0x02, 0x0D),
    "K": (0x02, 0x0E),
    "L": (0x02, 0x0F),
    "M": (0x02, 0x10),
    "N": (0x02, 0x11),
    "O": (0x02, 0x12),
    "P": (0x02, 0x13),
    "Q": (0x02, 0x14),
    "R": (0x02, 0x15),
    "S": (0x02, 0x16),
    "T": (0x02, 0x17),
    "U": (0x02, 0x18),
    "V": (0x02, 0x19),
    "W": (0x02, 0x1A),
    "X": (0x02, 0x1B),
    "Y": (0x02, 0x1C),
    "Z": (0x02, 0x1D),
    "1": (0, 0x1E),
    "2": (0, 0x1F),
    "3": (0, 0x20),
    "4": (0, 0x21),
    "5": (0, 0x22),
    "6": (0, 0x23),
    "7": (0, 0x24),
    "8": (0, 0x25),
    "9": (0, 0x26),
    "0": (0, 0x27),
    "!": (0x02, 0x1E),
    "@": (0x02, 0x1F),
    "#": (0x02, 0x20),
    "$": (0x02, 0x21),
    "%": (0x02, 0x22),
    "^": (0x02, 0x23),
    "&": (0x02, 0x24),
    "*": (0x02, 0x25),
    "(": (0x02, 0x26),
    ")": (0x02, 0x27),
    "\n": (0, 0x28),
    "\r": (0, 0x28),
    "\t": (0, 0x2B),
    " ": (0, 0x2C),
    "-": (0, 0x2D),
    "_": (0x02, 0x2D),
    "=": (0, 0x2E),
    "+": (0x02, 0x2E),
    "[": (0, 0x2F),
    "{": (0x02, 0x2F),
    "]": (0, 0x30),
    "}": (0x02, 0x30),
    "\\": (0, 0x31),
    "|": (0x02, 0x31),
    ";": (0, 0x33),
    ":": (0x02, 0x33),
    "'": (0, 0x34),
    '"': (0x02, 0x34),
    "`": (0, 0x35),
    "~": (0x02, 0x35),
    ",": (0, 0x36),
    "<": (0x02, 0x36),
    ".": (0, 0x37),
    ">": (0x02, 0x37),
    "/": (0, 0x38),
    "?": (0x02, 0x38),
}


def load_actions_config(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, dict):
        raise ActionError("actions config must be a JSON object")
    actions = data.get("actions")
    if not isinstance(actions, dict):
        raise ActionError("actions config must contain an actions object")
    return data


def list_action_names(path: str) -> List[str]:
    data = load_actions_config(path)
    return sorted(str(name) for name in data["actions"].keys())


def clamp_s8(value: int) -> int:
    return max(-127, min(127, int(value)))


def positive_int(value: Any, name: str, default: int) -> int:
    if value is None:
        return default
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        raise ActionError(f"{name} must be an integer") from None
    if parsed < 0:
        raise ActionError(f"{name} must be >= 0")
    return parsed


class StrictFormatter(string.Formatter):
    def get_field(self, field_name: str, args: Sequence[Any], kwargs: Mapping[str, Any]) -> Any:
        if not field_name.replace("_", "").isalnum():
            raise ActionError(f"invalid template param name: {field_name}")
        return super().get_field(field_name, args, kwargs)

    def get_value(self, key: Any, args: Sequence[Any], kwargs: Mapping[str, Any]) -> Any:
        if isinstance(key, str):
            if key not in kwargs:
                raise ActionError(f"missing template param: {key}")
            return kwargs[key]
        return super().get_value(key, args, kwargs)


def render_template(value: Any, params: Mapping[str, Any]) -> Any:
    if isinstance(value, str):
        return StrictFormatter().format(value, **params)
    if isinstance(value, list):
        return [render_template(item, params) for item in value]
    if isinstance(value, dict):
        return {key: render_template(item, params) for key, item in value.items()}
    return value


class HidActionExecutor:
    def __init__(self, settings: HidActionSettings) -> None:
        self.settings = settings
        if settings.hid_profile not in {"boot3", "extended5"}:
            raise ActionError("hid_profile must be boot3 or extended5")
        self.mouse_report_len = 3 if settings.hid_profile == "boot3" else 5
        self.mouse_fd: Optional[int] = None
        self.keyboard_fd: Optional[int] = None

    def _read_udc_state(self) -> str:
        if not self.settings.udc_state_path:
            return ""
        try:
            with open(self.settings.udc_state_path, "r", encoding="utf-8", errors="ignore") as f:
                return f.read().strip().lower()
        except OSError:
            return ""

    def _wait_for_udc_ready(self) -> None:
        if not self.settings.udc_state_path:
            return
        timeout = max(0.0, float(self.settings.udc_ready_timeout_ms) / 1000.0)
        deadline = time.monotonic() + timeout
        last_state = ""
        while True:
            last_state = self._read_udc_state()
            if not last_state or last_state == "configured":
                return
            if time.monotonic() >= deadline:
                raise ActionError(f"USB HID link is not configured: {last_state}")
            time.sleep(0.1)

    def _close_mouse(self) -> None:
        if self.mouse_fd is not None:
            try:
                os.close(self.mouse_fd)
            except OSError:
                pass
            self.mouse_fd = None

    def _close_keyboard(self) -> None:
        if self.keyboard_fd is not None:
            try:
                os.close(self.keyboard_fd)
            except OSError:
                pass
            self.keyboard_fd = None

    def close(self) -> None:
        for fd in (self.mouse_fd, self.keyboard_fd):
            if fd is not None:
                try:
                    os.close(fd)
                except OSError:
                    pass
        self.mouse_fd = None
        self.keyboard_fd = None

    def __enter__(self) -> "HidActionExecutor":
        return self

    def __exit__(self, _exc_type, _exc, _tb) -> None:
        self.close()

    def run_named_action(self, name: str, params: Mapping[str, Any]) -> Dict[str, Any]:
        data = load_actions_config(self.settings.config_path)
        actions = data["actions"]
        if name not in actions:
            raise ActionError(f"unknown action: {name}")
        sequence = actions[name]
        if not isinstance(sequence, list):
            raise ActionError(f"action {name} must be a list")
        rendered = render_template(sequence, params)
        self.run_sequence(rendered)
        return {"ok": True, "action": name, "steps": len(rendered)}

    def run_sequence(self, sequence: Iterable[Any]) -> None:
        with HidOutputLock(self.settings.hid_lock_path):
            try:
                for idx, item in enumerate(sequence):
                    if not isinstance(item, dict):
                        raise ActionError(f"step {idx} must be an object")
                    self.run_step(item, idx)
            finally:
                self.release_all()

    def run_step(self, item: Dict[str, Any], idx: int) -> None:
        kind = str(item.get("type", "")).strip()
        if not kind:
            raise ActionError(f"step {idx} missing type")
        if kind == "delay":
            self.delay(positive_int(item.get("ms"), "ms", self.settings.default_delay_ms))
        elif kind == "key":
            self.key(str(item.get("key", "")), item.get("press_ms"))
        elif kind == "key_combo":
            keys = item.get("keys")
            if not isinstance(keys, list) or not keys:
                raise ActionError(f"step {idx} keys must be a non-empty list")
            self.key_combo([str(key) for key in keys], item.get("press_ms"))
        elif kind == "type_text":
            text = item.get("text")
            if text is None:
                raise ActionError(f"step {idx} missing text")
            self.type_text(str(text), item.get("press_ms"))
        elif kind == "mouse_move":
            self.mouse_move(int(item.get("dx", 0)), int(item.get("dy", 0)))
        elif kind == "mouse_click":
            self.mouse_click(str(item.get("button", "left")), int(item.get("count", 1)), item.get("press_ms"))
        elif kind == "mouse_scroll":
            self.mouse_scroll(int(item.get("wheel", 0)), int(item.get("hwheel", 0)))
        else:
            raise ActionError(f"step {idx} unsupported type: {kind}")
        if kind != "delay":
            self.delay(positive_int(item.get("after_ms"), "after_ms", self.settings.default_delay_ms))

    def delay(self, ms: int) -> None:
        if ms > 0:
            time.sleep(ms / 1000.0)

    def open_mouse(self) -> int:
        self._wait_for_udc_ready()
        if self.mouse_fd is None:
            self.mouse_fd = os.open(self.settings.mouse_hidg_path, os.O_RDWR | os.O_CLOEXEC)
        return self.mouse_fd

    def open_keyboard(self) -> int:
        self._wait_for_udc_ready()
        if self.keyboard_fd is None:
            self.keyboard_fd = os.open(self.settings.keyboard_hidg_path, os.O_RDWR | os.O_CLOEXEC)
        return self.keyboard_fd

    def _write_mouse_report(self, report: bytes) -> None:
        self._write_report_with_retry("mouse", report)

    def _write_keyboard_report(self, report: bytes) -> None:
        self._write_report_with_retry("keyboard", report)

    def _write_report_with_retry(self, target: str, report: bytes) -> None:
        transient = {
            errno.ENODEV,
            errno.ENXIO,
            errno.EPIPE,
            getattr(errno, "ENOTCONN", 107),
            getattr(errno, "ESHUTDOWN", 108),
        }
        timeout = max(0.0, float(self.settings.udc_ready_timeout_ms) / 1000.0)
        deadline = time.monotonic() + timeout
        last_exc: Optional[OSError] = None

        while True:
            self._wait_for_udc_ready()
            try:
                if target == "mouse":
                    os.write(self.open_mouse(), report)
                else:
                    os.write(self.open_keyboard(), report)
                return
            except OSError as exc:
                if exc.errno not in transient:
                    raise
                last_exc = exc
                if target == "mouse":
                    self._close_mouse()
                else:
                    self._close_keyboard()
                if time.monotonic() >= deadline:
                    raise last_exc
                time.sleep(0.1)

    def write_mouse(self, buttons: int = 0, dx: int = 0, dy: int = 0, wheel: int = 0, hwheel: int = 0) -> None:
        if self.mouse_report_len == 3:
            report = bytes([buttons & 0x07, dx & 0xFF, dy & 0xFF])
        else:
            report = bytes([buttons & 0x1F, dx & 0xFF, dy & 0xFF, wheel & 0xFF, hwheel & 0xFF])
        self._write_mouse_report(report)

    def write_keyboard(self, modifiers: int = 0, keys: Optional[List[int]] = None) -> None:
        key_list = list(keys or [])[:6]
        while len(key_list) < 6:
            key_list.append(0)
        self._write_keyboard_report(bytes([modifiers & 0xFF, 0] + key_list))

    def release_all(self) -> None:
        if self.keyboard_fd is not None:
            self.write_keyboard()
        if self.mouse_fd is not None:
            self.write_mouse()

    def key(self, name: str, press_ms: Any = None) -> None:
        modifiers, usages = resolve_keys([name])
        self.write_keyboard(modifiers, usages)
        self.delay(positive_int(press_ms, "press_ms", self.settings.key_press_ms))
        self.write_keyboard()

    def key_combo(self, keys: List[str], press_ms: Any = None) -> None:
        modifiers, usages = resolve_keys(keys)
        self.write_keyboard(modifiers, usages)
        self.delay(positive_int(press_ms, "press_ms", self.settings.key_press_ms))
        self.write_keyboard()

    def type_text(self, text: str, press_ms: Any = None) -> None:
        hold_ms = positive_int(press_ms, "press_ms", self.settings.key_press_ms)
        for ch in text:
            if ch not in CHAR_TO_KEY:
                raise ActionError(f"unsupported text character: {ch!r}")
            modifiers, usage = CHAR_TO_KEY[ch]
            self.write_keyboard(modifiers, [usage])
            self.delay(hold_ms)
            self.write_keyboard()
            self.delay(self.settings.default_delay_ms)

    def mouse_move(self, dx: int, dy: int) -> None:
        while dx or dy:
            step_dx = clamp_s8(dx)
            step_dy = clamp_s8(dy)
            self.write_mouse(0, step_dx, step_dy, 0, 0)
            dx -= step_dx
            dy -= step_dy
            self.delay(self.settings.mouse_step_delay_ms)
        self.write_mouse()

    def mouse_click(self, button: str, count: int, press_ms: Any = None) -> None:
        normalized = button.strip().lower()
        if normalized not in MOUSE_BUTTONS:
            raise ActionError(f"unsupported mouse button: {button}")
        hold_ms = positive_int(press_ms, "press_ms", self.settings.key_press_ms)
        for _ in range(max(1, count)):
            self.write_mouse(MOUSE_BUTTONS[normalized])
            self.delay(hold_ms)
            self.write_mouse()
            self.delay(self.settings.default_delay_ms)

    def mouse_scroll(self, wheel: int, hwheel: int = 0) -> None:
        if self.mouse_report_len == 3:
            raise ActionError("mouse_scroll requires HID_PROFILE=extended5")
        while wheel or hwheel:
            step_wheel = clamp_s8(wheel)
            step_hwheel = clamp_s8(hwheel)
            self.write_mouse(0, 0, 0, step_wheel, step_hwheel)
            wheel -= step_wheel
            hwheel -= step_hwheel
            self.delay(self.settings.mouse_step_delay_ms)
        self.write_mouse()


def normalize_key_name(name: str) -> str:
    return name.strip().lower().replace("-", "_").replace(" ", "_")


def resolve_keys(names: List[str]) -> Tuple[int, List[int]]:
    modifiers = 0
    usages: List[int] = []
    for name in names:
        normalized = normalize_key_name(name)
        if normalized in MODIFIER_KEYS:
            modifiers |= MODIFIER_KEYS[normalized]
            continue
        usage = KEY_USAGES.get(normalized)
        if usage is None:
            raise ActionError(f"unsupported key: {name}")
        if usage not in usages:
            usages.append(usage)
    if len(usages) > 6:
        raise ActionError("keyboard report supports at most 6 non-modifier keys")
    return modifiers, usages
