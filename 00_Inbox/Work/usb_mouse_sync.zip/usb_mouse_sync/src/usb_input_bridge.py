#!/usr/bin/env python3
"""Unified local/network mouse-keyboard bridge with HID output arbitration."""

import argparse
import json
import logging
import signal
import socket
import struct
import threading
import time
import queue
from typing import Any, Dict, List, Optional, Tuple

from usb_hid_actions import (
    ActionError,
    HidActionExecutor,
    HidActionSettings,
    HidOutputLock,
)
from usb_keyboard_sync import (
    KeyboardSyncService,
    autodetect_keyboard_event,
    prefer_stable_event_path as prefer_stable_keyboard_event_path,
)
from usb_mouse_sync import (
    DEFAULT_ALIGN_RETRIES,
    DEFAULT_ALIGN_RETRY_INTERVAL_MS,
    DEFAULT_ALIGN_STEP_MAX,
    DEFAULT_ALIGN_STEP_SLEEP_MS,
    DEFAULT_CONNECT_SETTLE_MS,
    HID_TRANSIENT_ERRNOS,
    MouseSyncService,
    autodetect_mouse_event,
    autodetect_udc_state_path,
    clamp_s8,
    is_mouse_event_path,
    prefer_stable_event_path as prefer_stable_mouse_event_path,
)

INPUT_PRIORITY_LOCAL = "local"
INPUT_PRIORITY_NETWORK = "network"
INPUT_PRIORITY_AUTO = "auto"

NET_ROLE_CLIENT = "client"
NET_ROLE_SERVER = "server"

FRAME_MAGIC = b"UMS1"
FRAME_VERSION = 1
FRAME_TYPE_MOUSE = 1
FRAME_TYPE_KEYBOARD = 2
FRAME_HEADER = struct.Struct("!4sBBHI")

DEFAULT_NETWORK_PORT = 5566
DEFAULT_NETWORK_RETRY_MS = 1000
DEFAULT_NETWORK_CONNECT_TIMEOUT_MS = 2000
DEFAULT_NETWORK_QUEUE_SIZE = 512
DEFAULT_LOCAL_IDLE_TIMEOUT_MS = 3000
DEFAULT_ACTION_TCP_HOST = "0.0.0.0"
DEFAULT_ACTION_TCP_PORT = 5567
DEFAULT_ACTION_TCP_MAX_LINE_BYTES = 16384
DEFAULT_ACTION_TCP_QUEUE_SIZE = 32
DEFAULT_ACTION_UDP_HOST = "0.0.0.0"
DEFAULT_ACTION_UDP_PORT = 5568
DEFAULT_ACTION_UDP_MAX_DATAGRAM_BYTES = 16384
DEFAULT_ACTIONS_CONFIG_PATH = "/etc/usb-mouse-sync/actions.json"
DEFAULT_HID_LOCK_PATH = "/run/lock/usb-mouse-sync-hid.lock"


def build_zero_mouse_report(hid_profile: str) -> bytes:
    if hid_profile == "boot3":
        return bytes([0, 0, 0])
    return bytes([0, 0, 0, 0, 0])


def configure_stream_socket(sock: socket.socket) -> None:
    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
    sock.settimeout(0.5)


class ServiceThread(threading.Thread):
    def __init__(self, name: str, service) -> None:
        super().__init__(name=name)
        self.service = service
        self.failure: Optional[BaseException] = None

    def run(self) -> None:
        try:
            self.service.run()
        except BaseException as exc:  # pragma: no cover - defensive top-level logging
            self.failure = exc
            logging.exception("%s thread crashed", self.name)

    def stop(self) -> None:
        self.service.stop()


class TcpConnectionManager:
    def __init__(self, role: str, host: str, port: int, retry_interval: float, connect_timeout: float) -> None:
        self.role = role
        self.host = host
        self.port = port
        self.retry_interval = retry_interval
        self.connect_timeout = connect_timeout
        self.listen_sock: Optional[socket.socket] = None
        self.last_error_log = 0.0

    def close(self) -> None:
        if self.listen_sock is not None:
            try:
                self.listen_sock.close()
            except OSError:
                pass
            self.listen_sock = None

    def _throttled_warning(self, fmt: str, *args) -> None:
        now = time.time()
        if now - self.last_error_log < 3.0:
            return
        self.last_error_log = now
        logging.warning(fmt, *args)

    def _ensure_listen_socket(self) -> socket.socket:
        if self.listen_sock is not None:
            return self.listen_sock
        listen_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        listen_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        listen_sock.bind((self.host, self.port))
        listen_sock.listen(1)
        listen_sock.settimeout(1.0)
        self.listen_sock = listen_sock
        logging.info("Network server listening on %s:%d", self.host, self.port)
        return listen_sock

    def open_connection(self, stop_event: threading.Event, log_prefix: str) -> Optional[socket.socket]:
        while not stop_event.is_set():
            try:
                if self.role == NET_ROLE_SERVER:
                    listen_sock = self._ensure_listen_socket()
                    try:
                        conn, addr = listen_sock.accept()
                    except socket.timeout:
                        continue
                    configure_stream_socket(conn)
                    logging.info("%s accepted connection from %s:%d", log_prefix, addr[0], addr[1])
                    return conn

                conn = socket.create_connection((self.host, self.port), timeout=self.connect_timeout)
                configure_stream_socket(conn)
                logging.info("%s connected to %s:%d", log_prefix, self.host, self.port)
                return conn
            except OSError as exc:
                self._throttled_warning("%s connection failed (%s), retry", log_prefix, exc)
                if stop_event.wait(self.retry_interval):
                    return None
        return None


class MouseHidWriter:
    def __init__(
        self,
        hidg_path: str,
        udc_state_path: str,
        hid_profile: str,
        home_on_connect: bool,
        home_steps: int,
        start_bias_x: int,
        start_bias_y: int,
        home_rounds: int,
        connect_settle_ms: int,
        hid_lock_path: str,
    ) -> None:
        self.hidg_path = hidg_path
        self.udc_state_path = udc_state_path
        self.hid_profile = hid_profile
        self.home_on_connect = home_on_connect
        self.home_steps = max(1, home_steps)
        self.start_bias_x = start_bias_x
        self.start_bias_y = start_bias_y
        self.home_rounds = max(1, home_rounds)
        self.connect_settle = max(0.0, float(connect_settle_ms) / 1000.0)
        self.hid_lock_path = hid_lock_path
        self.zero_report = build_zero_mouse_report(hid_profile)
        self.expected_length = len(self.zero_report)
        self.hidg_fd: Optional[int] = None
        self.last_link_down_log = 0.0

    def close(self) -> None:
        if self.hidg_fd is not None:
            try:
                import os

                os.close(self.hidg_fd)
            except OSError:
                pass
            self.hidg_fd = None

    def _read_udc_state(self) -> str:
        if not self.udc_state_path:
            return ""
        try:
            with open(self.udc_state_path, "r", encoding="utf-8", errors="ignore") as f:
                return f.read().strip().lower()
        except OSError:
            return ""

    def _udc_ready_for_io(self) -> bool:
        state = self._read_udc_state()
        return not state or state == "configured"

    def _throttled_link_log(self, fmt: str, *args) -> None:
        now = time.time()
        if now - self.last_link_down_log < 3.0:
            return
        self.last_link_down_log = now
        logging.warning(fmt, *args)

    def _maybe_close_on_link_down(self) -> None:
        if self.hidg_fd is None:
            return
        state = self._read_udc_state()
        if state and state != "configured":
            self._throttled_link_log("Mouse HID link down, close fd (udc_state=%s)", state)
            self.close()

    def _write_raw(self, report: bytes) -> None:
        if self.hidg_fd is None:
            return
        try:
            import os

            os.write(self.hidg_fd, report)
        except BlockingIOError:
            return
        except OSError as exc:
            if exc.errno in HID_TRANSIENT_ERRNOS:
                self._throttled_link_log("Mouse HID write failed (%s), reopen", exc)
                self.close()
                return
            if exc.errno in {11}:
                return
            raise

    def _sync_cursor_origin(self) -> None:
        if self.hid_profile == "boot3":
            step = bytes([0, (-127) & 0xFF, (-127) & 0xFF])
        else:
            step = bytes([0, (-127) & 0xFF, (-127) & 0xFF, 0, 0])
        for _ in range(self.home_rounds):
            for _ in range(self.home_steps):
                self._write_raw(step)
            self._write_raw(self.zero_report)
            time.sleep(0.01)
        dx = self.start_bias_x
        dy = self.start_bias_y
        while dx or dy:
            step_dx = clamp_s8(dx)
            step_dy = clamp_s8(dy)
            if self.hid_profile == "boot3":
                report = bytes([0, step_dx & 0xFF, step_dy & 0xFF])
            else:
                report = bytes([0, step_dx & 0xFF, step_dy & 0xFF, 0, 0])
            self._write_raw(report)
            dx -= step_dx
            dy -= step_dy
        self._write_raw(self.zero_report)

    def _ensure_open(self) -> bool:
        self._maybe_close_on_link_down()
        if self.hidg_fd is not None:
            return True
        if not self._udc_ready_for_io():
            return False
        try:
            import os

            self.hidg_fd = os.open(self.hidg_path, os.O_RDWR | os.O_CLOEXEC | os.O_NONBLOCK)
        except FileNotFoundError:
            logging.warning("Mouse HID gadget missing: %s", self.hidg_path)
            return False
        except PermissionError:
            logging.error("Permission denied for mouse HID gadget: %s", self.hidg_path)
            return False
        logging.info("Opened mouse HID gadget: %s", self.hidg_path)
        if self.connect_settle > 0:
            time.sleep(self.connect_settle)
        if self.home_on_connect:
            self._sync_cursor_origin()
        return True

    def write_report(self, report: bytes) -> None:
        if len(report) != self.expected_length:
            logging.warning("Mouse network report length mismatch: expected=%d got=%d", self.expected_length, len(report))
            return
        with HidOutputLock(self.hid_lock_path):
            if not self._ensure_open():
                return
            self._write_raw(report)

    def clear_state(self) -> None:
        with HidOutputLock(self.hid_lock_path):
            if self.hidg_fd is None:
                return
            self._write_raw(self.zero_report)


class KeyboardHidWriter:
    def __init__(self, hidg_path: str, udc_state_path: str, hid_lock_path: str) -> None:
        self.hidg_path = hidg_path
        self.udc_state_path = udc_state_path
        self.hid_lock_path = hid_lock_path
        self.zero_report = bytes([0] * 8)
        self.hidg_fd: Optional[int] = None
        self.last_link_down_log = 0.0

    def close(self) -> None:
        if self.hidg_fd is not None:
            try:
                import os

                os.close(self.hidg_fd)
            except OSError:
                pass
            self.hidg_fd = None

    def _read_udc_state(self) -> str:
        if not self.udc_state_path:
            return ""
        try:
            with open(self.udc_state_path, "r", encoding="utf-8", errors="ignore") as f:
                return f.read().strip().lower()
        except OSError:
            return ""

    def _udc_ready_for_io(self) -> bool:
        state = self._read_udc_state()
        return not state or state == "configured"

    def _throttled_link_log(self, fmt: str, *args) -> None:
        now = time.time()
        if now - self.last_link_down_log < 3.0:
            return
        self.last_link_down_log = now
        logging.warning(fmt, *args)

    def _maybe_close_on_link_down(self) -> None:
        if self.hidg_fd is None:
            return
        state = self._read_udc_state()
        if state and state != "configured":
            self._throttled_link_log("Keyboard HID link down, close fd (udc_state=%s)", state)
            self.close()

    def _ensure_open(self) -> bool:
        self._maybe_close_on_link_down()
        if self.hidg_fd is not None:
            return True
        if not self._udc_ready_for_io():
            return False
        try:
            import os

            self.hidg_fd = os.open(self.hidg_path, os.O_RDWR | os.O_CLOEXEC | os.O_NONBLOCK)
        except FileNotFoundError:
            logging.warning("Keyboard HID gadget missing: %s", self.hidg_path)
            return False
        except PermissionError:
            logging.error("Permission denied for keyboard HID gadget: %s", self.hidg_path)
            return False
        logging.info("Opened keyboard HID gadget: %s", self.hidg_path)
        self._write_raw(self.zero_report)
        return True

    def _write_raw(self, report: bytes) -> None:
        if self.hidg_fd is None:
            return
        try:
            import os

            os.write(self.hidg_fd, report)
        except BlockingIOError:
            return
        except OSError as exc:
            if exc.errno in HID_TRANSIENT_ERRNOS:
                self._throttled_link_log("Keyboard HID write failed (%s), reopen", exc)
                self.close()
                return
            if exc.errno in {11}:
                return
            raise

    def write_report(self, report: bytes) -> None:
        if len(report) != len(self.zero_report):
            logging.warning("Keyboard network report length mismatch: expected=%d got=%d", len(self.zero_report), len(report))
            return
        with HidOutputLock(self.hid_lock_path):
            if not self._ensure_open():
                return
            self._write_raw(report)

    def clear_state(self) -> None:
        with HidOutputLock(self.hid_lock_path):
            if self.hidg_fd is None:
                return
            self._write_raw(self.zero_report)


class BridgeRouter:
    def __init__(
        self,
        enable_hid_output: bool,
        enable_network: bool,
        input_priority: str,
        local_idle_timeout_ms: int,
        mouse_writer: Optional[MouseHidWriter],
        keyboard_writer: Optional[KeyboardHidWriter],
    ) -> None:
        self.enable_hid_output = enable_hid_output
        self.enable_network = enable_network
        self.input_priority = input_priority
        self.local_idle_timeout = max(0.0, float(local_idle_timeout_ms) / 1000.0)
        self.mouse_writer = mouse_writer
        self.keyboard_writer = keyboard_writer
        self.network_peer: Optional["NetworkPeer"] = None
        self.lock = threading.Lock()
        self.last_local_activity = 0.0
        self.last_network_activity = 0.0
        self.current_source = ""

    def attach_network_peer(self, peer: "NetworkPeer") -> None:
        self.network_peer = peer

    def _network_connected_unlocked(self) -> bool:
        return self.network_peer is not None and self.network_peer.is_connected()

    def _apply_hid(self, frame_type: int, payload: bytes) -> None:
        if not self.enable_hid_output:
            return
        if frame_type == FRAME_TYPE_MOUSE and self.mouse_writer is not None:
            self.mouse_writer.write_report(payload)
        elif frame_type == FRAME_TYPE_KEYBOARD and self.keyboard_writer is not None:
            self.keyboard_writer.write_report(payload)

    def _clear_hid_state(self) -> None:
        if not self.enable_hid_output:
            return
        if self.mouse_writer is not None:
            self.mouse_writer.clear_state()
        if self.keyboard_writer is not None:
            self.keyboard_writer.clear_state()

    def _should_apply_local_unlocked(self, now: float) -> bool:
        if not self.enable_hid_output:
            return False
        if self.input_priority == INPUT_PRIORITY_NETWORK and self._network_connected_unlocked():
            return False
        self.current_source = "local"
        return True

    def _should_apply_network_unlocked(self, now: float) -> bool:
        if not self.enable_hid_output:
            return False
        if self.input_priority == INPUT_PRIORITY_NETWORK:
            self.current_source = "network"
            return True
        if self.input_priority == INPUT_PRIORITY_LOCAL:
            if now - self.last_local_activity <= self.local_idle_timeout:
                return False
            self.current_source = "network"
            return True
        if self.current_source == "local" and now - self.last_local_activity <= self.local_idle_timeout:
            return False
        self.current_source = "network"
        return True

    def handle_local_report(self, frame_type: int, payload: bytes) -> None:
        now = time.monotonic()
        with self.lock:
            self.last_local_activity = now
            apply_hid = self._should_apply_local_unlocked(now)
        if apply_hid:
            self._apply_hid(frame_type, payload)
        if self.enable_network and self.network_peer is not None:
            self.network_peer.submit_local_report(frame_type, payload)

    def handle_network_report(self, frame_type: int, payload: bytes) -> None:
        now = time.monotonic()
        with self.lock:
            self.last_network_activity = now
            apply_hid = self._should_apply_network_unlocked(now)
        if apply_hid:
            self._apply_hid(frame_type, payload)

    def on_network_disconnect(self) -> None:
        with self.lock:
            clear_state = self.current_source == "network"
            if clear_state:
                self.current_source = ""
        if clear_state:
            self._clear_hid_state()


class NetworkPeer(threading.Thread):
    def __init__(
        self,
        connection: TcpConnectionManager,
        router: BridgeRouter,
        enable_send: bool,
        initial_reports: Dict[int, bytes],
        queue_size: int,
    ) -> None:
        super().__init__(name="network-peer")
        self.connection = connection
        self.router = router
        self.enable_send = enable_send
        self.stop_event = threading.Event()
        self.failure: Optional[BaseException] = None
        self.latest_reports = dict(initial_reports)
        self.pending_queue: "queue.Queue[Tuple[int, bytes]]" = queue.Queue(maxsize=max(8, queue_size))
        self.send_lock = threading.Lock()
        self.state_lock = threading.Lock()
        self.sock: Optional[socket.socket] = None
        self.connected = False
        self.last_drop_log = 0.0
        self.last_io_log = 0.0
        self.sequence = 0

    def stop(self) -> None:
        self.stop_event.set()
        self.connection.close()
        self._close_socket(notify=False)

    def is_connected(self) -> bool:
        with self.state_lock:
            return self.connected and self.sock is not None

    def _set_socket(self, sock: Optional[socket.socket]) -> None:
        with self.state_lock:
            self.sock = sock
            self.connected = sock is not None

    def _close_socket(self, notify: bool = True) -> None:
        sock = None
        with self.state_lock:
            sock = self.sock
            self.sock = None
            was_connected = self.connected
            self.connected = False
        if sock is not None:
            try:
                sock.close()
            except OSError:
                pass
        if notify and was_connected:
            self.router.on_network_disconnect()

    def _throttled_drop_log(self, msg: str) -> None:
        now = time.time()
        if now - self.last_drop_log < 3.0:
            return
        self.last_drop_log = now
        logging.warning(msg)

    def _throttled_io_log(self, fmt: str, *args) -> None:
        now = time.time()
        if now - self.last_io_log < 3.0:
            return
        self.last_io_log = now
        logging.warning(fmt, *args)

    def _encode_frame(self, frame_type: int, payload: bytes) -> bytes:
        self.sequence = (self.sequence + 1) & 0xFFFFFFFF
        header = FRAME_HEADER.pack(FRAME_MAGIC, FRAME_VERSION, frame_type, len(payload), self.sequence)
        return header + payload

    def submit_local_report(self, frame_type: int, payload: bytes) -> None:
        self.latest_reports[frame_type] = payload
        if not self.enable_send:
            return
        try:
            self.pending_queue.put_nowait((frame_type, payload))
        except queue.Full:
            try:
                self.pending_queue.get_nowait()
            except queue.Empty:
                pass
            try:
                self.pending_queue.put_nowait((frame_type, payload))
            except queue.Full:
                self._throttled_drop_log("Network send queue full, drop report")
                return
        self._flush_pending()

    def _send_frame(self, sock: socket.socket, frame_type: int, payload: bytes) -> None:
        sock.sendall(self._encode_frame(frame_type, payload))

    def _flush_pending(self) -> None:
        if not self.enable_send:
            return
        with self.send_lock:
            sock = self.sock
            if sock is None:
                return
            try:
                while True:
                    frame_type, payload = self.pending_queue.get_nowait()
                    self._send_frame(sock, frame_type, payload)
            except queue.Empty:
                return
            except OSError as exc:
                self._throttled_io_log("Network stream dropped while sending (%s), reconnect", exc)
                self._close_socket(notify=True)

    def _send_snapshot(self, sock: socket.socket) -> None:
        if not self.enable_send:
            return
        for frame_type in sorted(self.latest_reports.keys()):
            self._send_frame(sock, frame_type, self.latest_reports[frame_type])

    def _process_incoming_buffer(self, buffer: bytearray) -> None:
        while True:
            if len(buffer) < FRAME_HEADER.size:
                return
            magic, version, frame_type, payload_len, _seq = FRAME_HEADER.unpack(buffer[: FRAME_HEADER.size])
            if magic != FRAME_MAGIC or version != FRAME_VERSION:
                raise ValueError("Invalid frame header")
            if payload_len < 0 or payload_len > 64:
                raise ValueError(f"Invalid payload length: {payload_len}")
            total_len = FRAME_HEADER.size + payload_len
            if len(buffer) < total_len:
                return
            payload = bytes(buffer[FRAME_HEADER.size:total_len])
            del buffer[:total_len]
            self.router.handle_network_report(frame_type, payload)

    def run(self) -> None:
        try:
            while not self.stop_event.is_set():
                sock = self.connection.open_connection(self.stop_event, "Network peer")
                if sock is None:
                    return
                self._set_socket(sock)
                try:
                    self._send_snapshot(sock)
                    self._flush_pending()
                    recv_buffer = bytearray()
                    while not self.stop_event.is_set():
                        try:
                            chunk = sock.recv(4096)
                        except socket.timeout:
                            self._flush_pending()
                            continue
                        if not chunk:
                            raise ConnectionError("peer closed connection")
                        recv_buffer.extend(chunk)
                        self._process_incoming_buffer(recv_buffer)
                        self._flush_pending()
                except (ConnectionError, OSError) as exc:
                    self._throttled_io_log("Network stream dropped (%s), reconnect", exc)
                except ValueError as exc:
                    self._throttled_io_log("Network frame error (%s), reconnect", exc)
                finally:
                    self._close_socket(notify=True)
        except BaseException as exc:  # pragma: no cover - defensive top-level logging
            self.failure = exc
            logging.exception("network-peer thread crashed")


def action_error_response(request_id: Any, message: str) -> Dict[str, Any]:
    response: Dict[str, Any] = {"ok": False, "error": message}
    if request_id is not None:
        response["request_id"] = request_id
    return response


def validate_action_request(payload: Any) -> Tuple[Optional[Dict[str, Any]], Optional[Dict[str, Any]]]:
    if not isinstance(payload, dict):
        return None, action_error_response(None, "request must be a JSON object")
    request_id = payload.get("request_id")
    name = payload.get("name")
    params = payload.get("params", {})
    if not isinstance(name, str) or not name.strip():
        return None, action_error_response(request_id, "name must be a non-empty string")
    if not isinstance(params, dict):
        return None, action_error_response(request_id, "params must be an object")
    return {
        "name": name,
        "params": params,
        "request_id": request_id,
    }, None


class ActionDispatcher(threading.Thread):
    """Execute TCP and UDP action requests through one bounded FIFO queue."""

    def __init__(self, queue_size: int, action_settings: HidActionSettings) -> None:
        super().__init__(name="action-worker")
        self.request_queue: "queue.Queue[Optional[Tuple[str, Dict[str, Any], Optional[queue.Queue[Dict[str, Any]]]]]]" = (
            queue.Queue(maxsize=max(1, queue_size))
        )
        self.action_settings = action_settings
        self.stop_event = threading.Event()
        self.failure: Optional[BaseException] = None

    def stop(self) -> None:
        self.stop_event.set()
        try:
            self.request_queue.put_nowait(None)
        except queue.Full:
            pass

    def submit(
        self,
        transport: str,
        request: Dict[str, Any],
        response_queue: Optional["queue.Queue[Dict[str, Any]]"] = None,
        timeout: float = 0.0,
    ) -> bool:
        try:
            if timeout > 0:
                self.request_queue.put((transport, request, response_queue), timeout=timeout)
            else:
                self.request_queue.put_nowait((transport, request, response_queue))
            return True
        except queue.Full:
            return False

    def _execute_request(self, transport: str, request: Dict[str, Any]) -> Dict[str, Any]:
        request_id = request.get("request_id")
        try:
            with HidActionExecutor(self.action_settings) as executor:
                result = executor.run_named_action(request["name"], request["params"])
            if request_id is not None:
                result["request_id"] = request_id
            logging.info(
                "Action %s executed name=%s request_id=%s steps=%s",
                transport,
                request["name"],
                request_id,
                result.get("steps"),
            )
            return result
        except (ActionError, OSError, ValueError, json.JSONDecodeError) as exc:
            logging.warning(
                "Action %s failed name=%s request_id=%s error=%s",
                transport,
                request.get("name"),
                request_id,
                exc,
            )
            return action_error_response(request_id, str(exc))
        except Exception as exc:  # pragma: no cover - defensive action boundary
            logging.exception("%s HID action failed", transport)
            return action_error_response(request_id, str(exc))

    def run(self) -> None:
        try:
            while not self.stop_event.is_set():
                try:
                    item = self.request_queue.get(timeout=0.2)
                except queue.Empty:
                    continue
                if item is None:
                    return
                transport, request, response_queue = item
                response = self._execute_request(transport, request)
                if response_queue is not None:
                    response_queue.put(response)
        except BaseException as exc:  # pragma: no cover - defensive top-level logging
            self.failure = exc
            logging.exception("action-worker thread crashed")


class ActionTcpServer(threading.Thread):
    """Accept JSON action requests and submit them to the shared dispatcher."""

    def __init__(
        self,
        host: str,
        port: int,
        max_line_bytes: int,
        dispatcher: ActionDispatcher,
    ) -> None:
        super().__init__(name="action-tcp")
        self.host = host
        self.port = port
        self.max_line_bytes = max(256, max_line_bytes)
        self.dispatcher = dispatcher
        self.stop_event = threading.Event()
        self.failure: Optional[BaseException] = None
        self.listen_sock: Optional[socket.socket] = None
        self.client_threads: List[threading.Thread] = []
        self.client_sockets: List[socket.socket] = []
        self.clients_lock = threading.Lock()

    def stop(self) -> None:
        self.stop_event.set()
        if self.listen_sock is not None:
            try:
                self.listen_sock.close()
            except OSError:
                pass
            self.listen_sock = None
        with self.clients_lock:
            sockets = list(self.client_sockets)
        for sock in sockets:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                sock.close()
            except OSError:
                pass

    def close(self) -> None:
        self.stop()
        for client in self.client_threads:
            client.join(timeout=1.0)

    def _write_response(self, sock: socket.socket, payload: Dict[str, Any]) -> None:
        body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8") + b"\n"
        sock.sendall(body)

    def _pop_json_message(self, buffer: bytearray) -> Tuple[Optional[bytes], Optional[Dict[str, Any]]]:
        start = 0
        while start < len(buffer) and chr(buffer[start]).isspace():
            start += 1
        if start:
            del buffer[:start]
        if not buffer:
            return None, None
        if buffer[0] != ord("{"):
            newline = buffer.find(b"\n")
            if newline >= 0:
                del buffer[: newline + 1]
            else:
                buffer.clear()
            return None, action_error_response(None, "request must be a JSON object")

        depth = 0
        in_string = False
        escaped = False
        for idx, byte in enumerate(buffer):
            if in_string:
                if escaped:
                    escaped = False
                elif byte == ord("\\"):
                    escaped = True
                elif byte == ord('"'):
                    in_string = False
                continue
            if byte == ord('"'):
                in_string = True
            elif byte == ord("{"):
                depth += 1
            elif byte == ord("}"):
                depth -= 1
                if depth == 0:
                    end = idx + 1
                    message = bytes(buffer[:end])
                    del buffer[:end]
                    return message, None
        return None, None

    def _handle_client(self, sock: socket.socket, address: Tuple[str, int]) -> None:
        with self.clients_lock:
            self.client_sockets.append(sock)
        logging.info("Action TCP client connected from %s:%d", address[0], address[1])
        recv_buffer = bytearray()
        try:
            while not self.stop_event.is_set():
                try:
                    raw = sock.recv(4096)
                except socket.timeout:
                    continue
                if not raw:
                    return
                recv_buffer.extend(raw)
                if len(recv_buffer) > self.max_line_bytes:
                    self._write_response(sock, action_error_response(None, "request line too large"))
                    return

                while recv_buffer:
                    message, pop_error = self._pop_json_message(recv_buffer)
                    if pop_error is not None:
                        self._write_response(sock, pop_error)
                        continue
                    if message is None:
                        break
                    if len(message) > self.max_line_bytes:
                        self._write_response(sock, action_error_response(None, "request line too large"))
                        return
                    try:
                        payload = json.loads(message.decode("utf-8"))
                    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                        self._write_response(sock, action_error_response(None, f"invalid JSON: {exc}"))
                        continue
                    request, error = validate_action_request(payload)
                    if error is not None:
                        self._write_response(sock, error)
                        continue
                    assert request is not None
                    response_queue: "queue.Queue[Dict[str, Any]]" = queue.Queue(maxsize=1)
                    if not self.dispatcher.submit("TCP", request, response_queue=response_queue, timeout=1.0):
                        self._write_response(
                            sock,
                            action_error_response(request.get("request_id"), "action queue full"),
                        )
                        continue
                    while not self.stop_event.is_set():
                        try:
                            response = response_queue.get(timeout=0.2)
                            break
                        except queue.Empty:
                            continue
                    else:
                        return
                    self._write_response(sock, response)
        except (ConnectionError, OSError):
            return
        finally:
            with self.clients_lock:
                if sock in self.client_sockets:
                    self.client_sockets.remove(sock)
            try:
                sock.close()
            except OSError:
                pass
            logging.info("Action TCP client disconnected from %s:%d", address[0], address[1])

    def run(self) -> None:
        try:
            listen_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            listen_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            listen_sock.bind((self.host, self.port))
            listen_sock.listen(16)
            listen_sock.settimeout(1.0)
            self.listen_sock = listen_sock
            logging.info("Action TCP listening on %s:%d", self.host, self.port)

            while not self.stop_event.is_set():
                try:
                    client, address = listen_sock.accept()
                except socket.timeout:
                    continue
                client.settimeout(1.0)
                self.client_threads = [thread for thread in self.client_threads if thread.is_alive()]
                thread = threading.Thread(
                    target=self._handle_client,
                    args=(client, address),
                    name=f"action-client-{address[0]}:{address[1]}",
                    daemon=True,
                )
                self.client_threads.append(thread)
                thread.start()
        except OSError as exc:
            if not self.stop_event.is_set():
                self.failure = exc
                logging.exception("Action TCP server failed")
        except BaseException as exc:  # pragma: no cover - defensive top-level logging
            self.failure = exc
            logging.exception("Action TCP server crashed")
        finally:
            self.stop()


class ActionUdpServer(threading.Thread):
    """Accept one fire-and-forget JSON action request per UDP datagram."""

    def __init__(
        self,
        host: str,
        port: int,
        max_datagram_bytes: int,
        dispatcher: ActionDispatcher,
    ) -> None:
        super().__init__(name="action-udp")
        self.host = host
        self.port = port
        self.max_datagram_bytes = min(65507, max(256, max_datagram_bytes))
        self.dispatcher = dispatcher
        self.stop_event = threading.Event()
        self.failure: Optional[BaseException] = None
        self.sock: Optional[socket.socket] = None

    def stop(self) -> None:
        self.stop_event.set()
        if self.sock is not None:
            try:
                self.sock.close()
            except OSError:
                pass
            self.sock = None

    def run(self) -> None:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind((self.host, self.port))
            sock.settimeout(1.0)
            self.sock = sock
            logging.info("Action UDP listening on %s:%d", self.host, self.port)

            while not self.stop_event.is_set():
                try:
                    raw, address = sock.recvfrom(self.max_datagram_bytes + 1)
                except socket.timeout:
                    continue
                if len(raw) > self.max_datagram_bytes:
                    logging.warning(
                        "Action UDP datagram too large from %s:%d bytes=%d limit=%d",
                        address[0],
                        address[1],
                        len(raw),
                        self.max_datagram_bytes,
                    )
                    continue
                try:
                    payload = json.loads(raw.decode("utf-8"))
                except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                    logging.warning("Action UDP invalid JSON from %s:%d error=%s", address[0], address[1], exc)
                    continue
                request, error = validate_action_request(payload)
                if error is not None:
                    logging.warning(
                        "Action UDP invalid request from %s:%d error=%s",
                        address[0],
                        address[1],
                        error["error"],
                    )
                    continue
                assert request is not None
                if not self.dispatcher.submit("UDP", request):
                    logging.warning(
                        "Action UDP queue full; drop name=%s from %s:%d",
                        request["name"],
                        address[0],
                        address[1],
                    )
        except OSError as exc:
            if not self.stop_event.is_set():
                self.failure = exc
                logging.exception("Action UDP server failed")
        except BaseException as exc:  # pragma: no cover - defensive top-level logging
            self.failure = exc
            logging.exception("Action UDP server crashed")
        finally:
            self.stop()


class UnifiedBridge:
    def __init__(self, workers: List[threading.Thread]) -> None:
        self.workers = workers
        self.running = True
        self.exit_code = 0

    def stop(self) -> None:
        if not self.running:
            return
        self.running = False
        for worker in self.workers:
            stop_fn = getattr(worker, "stop", None)
            if callable(stop_fn):
                stop_fn()

    def run(self) -> int:
        for worker in self.workers:
            worker.start()
        try:
            while self.running:
                for worker in self.workers:
                    if worker.is_alive():
                        continue
                    if self.running:
                        failure = getattr(worker, "failure", None)
                        if failure is None:
                            logging.error("%s thread exited unexpectedly", worker.name)
                        self.exit_code = 1
                        self.stop()
                    break
                time.sleep(0.2)
        finally:
            for worker in self.workers:
                worker.join(timeout=2.0)
            for worker in self.workers:
                close_fn = getattr(worker, "close", None)
                if callable(close_fn):
                    close_fn()
        return self.exit_code


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Unified local/network USB mouse-keyboard bridge service")

    parser.add_argument("--enable-hid-output", action="store_true", default=True)
    parser.add_argument("--disable-hid-output", action="store_false", dest="enable_hid_output")
    parser.add_argument("--enable-network", action="store_true", default=True)
    parser.add_argument("--disable-network", action="store_false", dest="enable_network")
    parser.add_argument(
        "--input-priority",
        default=INPUT_PRIORITY_LOCAL,
        choices=[INPUT_PRIORITY_LOCAL, INPUT_PRIORITY_NETWORK, INPUT_PRIORITY_AUTO],
    )
    parser.add_argument("--local-idle-timeout-ms", type=int, default=DEFAULT_LOCAL_IDLE_TIMEOUT_MS)

    parser.add_argument("--event", help="Mouse input event device path (e.g. /dev/input/event3)")
    parser.add_argument("--hidg", default="/dev/hidg0", help="Mouse HID gadget device path")
    parser.add_argument("--move-scale", type=float, default=1.0, help="Mouse move scaling")
    parser.add_argument("--wheel-scale", type=float, default=1.0, help="Wheel scaling")
    parser.add_argument("--read-chunk-events", type=int, default=64, help="How many input_event records to read per syscall")
    parser.add_argument("--udc-state-path", default="", help="Optional path like /sys/class/udc/<name>/state")
    parser.add_argument("--hid-profile", default="extended5", choices=["extended5", "boot3"], help="Mouse HID report profile")
    parser.add_argument("--home-on-connect", action="store_true", default=True, help="Move cursor to top-left after HID connect")
    parser.add_argument("--no-home-on-connect", action="store_false", dest="home_on_connect", help="Disable connect-time homing")
    parser.add_argument("--home-steps", type=int, default=24, help="How many -127/-127 reports to send when homing")
    parser.add_argument("--start-bias-x", type=int, default=0, help="After homing, move right by this relative amount")
    parser.add_argument("--start-bias-y", type=int, default=0, help="After homing, move down by this relative amount")
    parser.add_argument("--mouse-mode", default="relative", choices=["relative", "absolute-map"], help="relative passthrough or absolute-map")
    parser.add_argument("--src-width", type=int, default=1920, help="Source desktop width for absolute-map")
    parser.add_argument("--src-height", type=int, default=1080, help="Source desktop height for absolute-map")
    parser.add_argument("--dst-width", type=int, default=1280, help="Target device width for absolute-map")
    parser.add_argument("--dst-height", type=int, default=720, help="Target device height for absolute-map")
    parser.add_argument("--dst-offset-x", type=int, default=0, help="Target active area X offset")
    parser.add_argument("--dst-offset-y", type=int, default=0, help="Target active area Y offset")
    parser.add_argument("--dst-active-width", type=int, default=0, help="Target active area width (0 means dst-width)")
    parser.add_argument("--dst-active-height", type=int, default=0, help="Target active area height (0 means dst-height)")
    parser.add_argument("--src-offset-x", type=int, default=0, help="Source X offset")
    parser.add_argument("--src-offset-y", type=int, default=0, help="Source Y offset")
    parser.add_argument("--use-cursor-query", action="store_true", default=True, help="Use xdotool cursor position in absolute-map mode")
    parser.add_argument("--no-cursor-query", action="store_false", dest="use_cursor_query", help="Disable cursor query; use rel integration")
    parser.add_argument("--cursor-query-cmd", default="xdotool", help="Command used for cursor query")
    parser.add_argument("--cursor-query-user", default="", help="Run cursor query command as this user")
    parser.add_argument("--cursor-display", default="", help="DISPLAY override for cursor query")
    parser.add_argument("--cursor-xauthority", default="", help="XAUTHORITY override for cursor query")
    parser.add_argument("--cursor-xdg-runtime-dir", default="", help="XDG_RUNTIME_DIR override for cursor query")
    parser.add_argument("--cursor-timeout-ms", type=int, default=120, help="Cursor query timeout in milliseconds")
    parser.add_argument("--align-on-connect", action="store_true", default=True, help="Align target cursor to source cursor after HID connects")
    parser.add_argument("--no-align-on-connect", action="store_false", dest="align_on_connect", help="Disable connect-time alignment")
    parser.add_argument("--connect-settle-ms", type=int, default=DEFAULT_CONNECT_SETTLE_MS, help="Wait after opening /dev/hidg0 before first reports")
    parser.add_argument("--home-rounds", type=int, default=2, help="How many homing rounds to send on connect")
    parser.add_argument("--align-retries", type=int, default=DEFAULT_ALIGN_RETRIES, help="How many times to retry source cursor query during connect align")
    parser.add_argument("--align-retry-interval-ms", type=int, default=DEFAULT_ALIGN_RETRY_INTERVAL_MS, help="Retry interval for connect align")
    parser.add_argument("--align-step-max", type=int, default=DEFAULT_ALIGN_STEP_MAX, help="Max per-report movement used during connect align")
    parser.add_argument("--align-step-sleep-ms", type=int, default=DEFAULT_ALIGN_STEP_SLEEP_MS, help="Sleep between connect-align reports")
    parser.add_argument("--source-home-on-connect", action="store_true", default=False, help="Move source desktop cursor to (0,0) on connect before align")
    parser.add_argument("--strict-absolute-query", action="store_true", default=True, help="In absolute-map mode, drop movement when cursor query fails")
    parser.add_argument("--no-strict-absolute-query", action="store_false", dest="strict_absolute_query", help="Allow relative fallback when cursor query fails")
    parser.add_argument("--auto-rebind-event", action="store_true", default=True, help="Auto detect new event node on mouse unplug/replug")
    parser.add_argument("--no-auto-rebind-event", action="store_false", dest="auto_rebind_event", help="Disable mouse event auto rebind")

    parser.add_argument("--enable-keyboard", action="store_true", default=True, help="Enable keyboard sync")
    parser.add_argument("--disable-keyboard", action="store_false", dest="enable_keyboard", help="Disable keyboard sync")
    parser.add_argument("--keyboard-event", default="", help="Keyboard input event path")
    parser.add_argument("--keyboard-hidg", default="/dev/hidg1", help="Keyboard HID gadget path")
    parser.add_argument("--keyboard-auto-rebind-event", action="store_true", default=True, help="Auto detect new event node on keyboard unplug/replug")
    parser.add_argument("--no-keyboard-auto-rebind-event", action="store_false", dest="keyboard_auto_rebind_event", help="Disable keyboard event auto rebind")

    parser.add_argument("--network-role", default=NET_ROLE_CLIENT, choices=[NET_ROLE_CLIENT, NET_ROLE_SERVER])
    parser.add_argument("--network-host", default="127.0.0.1", help="Server bind host or client peer host")
    parser.add_argument("--network-port", type=int, default=DEFAULT_NETWORK_PORT)
    parser.add_argument("--network-retry-ms", type=int, default=DEFAULT_NETWORK_RETRY_MS)
    parser.add_argument("--network-connect-timeout-ms", type=int, default=DEFAULT_NETWORK_CONNECT_TIMEOUT_MS)
    parser.add_argument("--network-queue-size", type=int, default=DEFAULT_NETWORK_QUEUE_SIZE)

    parser.add_argument("--action-only", action="store_true", help="Run only the TCP/UDP action servers")
    parser.add_argument("--disable-action-tcp", action="store_true", help="Disable the TCP action server")
    parser.add_argument("--action-tcp-host", default=DEFAULT_ACTION_TCP_HOST)
    parser.add_argument("--action-tcp-port", type=int, default=DEFAULT_ACTION_TCP_PORT)
    parser.add_argument("--action-tcp-max-line-bytes", type=int, default=DEFAULT_ACTION_TCP_MAX_LINE_BYTES)
    parser.add_argument("--action-tcp-queue-size", type=int, default=DEFAULT_ACTION_TCP_QUEUE_SIZE)
    parser.add_argument("--disable-action-udp", action="store_true", help="Disable the UDP action server")
    parser.add_argument("--action-udp-host", default=DEFAULT_ACTION_UDP_HOST)
    parser.add_argument("--action-udp-port", type=int, default=DEFAULT_ACTION_UDP_PORT)
    parser.add_argument("--action-udp-max-datagram-bytes", type=int, default=DEFAULT_ACTION_UDP_MAX_DATAGRAM_BYTES)
    parser.add_argument("--actions-config", default=DEFAULT_ACTIONS_CONFIG_PATH)
    parser.add_argument("--hid-lock-path", default=DEFAULT_HID_LOCK_PATH)

    parser.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    return parser.parse_args()


def build_mouse_service(args: argparse.Namespace, report_callback) -> MouseSyncService:
    if args.event:
        configured_event_path, _ = prefer_stable_mouse_event_path(
            args.event,
            ["/dev/input/by-id/*-event-mouse", "/dev/input/by-path/*-event-mouse"],
        )
        if is_mouse_event_path(configured_event_path):
            event_path = configured_event_path
        else:
            logging.warning(
                "Configured mouse EVENT_DEVICE does not look like a mouse anymore: %s, falling back to autodetect",
                configured_event_path,
            )
            event_path, _ = autodetect_mouse_event()
    else:
        event_path, _ = autodetect_mouse_event()
    logging.info("Using input device: %s", event_path)

    return MouseSyncService(
        event_path=event_path,
        hidg_path=args.hidg,
        move_scale=args.move_scale,
        wheel_scale=args.wheel_scale,
        read_chunk_events=args.read_chunk_events,
        udc_state_path="",
        hid_profile=args.hid_profile,
        home_on_connect=args.home_on_connect,
        home_steps=args.home_steps,
        start_bias_x=args.start_bias_x,
        start_bias_y=args.start_bias_y,
        mouse_mode=args.mouse_mode,
        src_width=args.src_width,
        src_height=args.src_height,
        dst_width=args.dst_width,
        dst_height=args.dst_height,
        autodetect_event=args.auto_rebind_event,
        src_offset_x=args.src_offset_x,
        src_offset_y=args.src_offset_y,
        dst_offset_x=args.dst_offset_x,
        dst_offset_y=args.dst_offset_y,
        dst_active_width=args.dst_active_width,
        dst_active_height=args.dst_active_height,
        use_cursor_query=args.use_cursor_query,
        cursor_query_cmd=args.cursor_query_cmd,
        cursor_query_user=args.cursor_query_user,
        cursor_display=args.cursor_display,
        cursor_xauthority=args.cursor_xauthority,
        cursor_xdg_runtime_dir=args.cursor_xdg_runtime_dir,
        cursor_timeout_ms=args.cursor_timeout_ms,
        align_on_connect=args.align_on_connect,
        connect_settle_ms=args.connect_settle_ms,
        home_rounds=args.home_rounds,
        align_retries=args.align_retries,
        align_retry_interval_ms=args.align_retry_interval_ms,
        align_step_max=args.align_step_max,
        align_step_sleep_ms=args.align_step_sleep_ms,
        source_home_on_connect=args.source_home_on_connect,
        strict_absolute_query=args.strict_absolute_query,
        enable_hid_output=False,
        report_callback=report_callback,
    )


def build_keyboard_service(args: argparse.Namespace, report_callback) -> Optional[KeyboardSyncService]:
    if not args.enable_keyboard:
        logging.info("Keyboard sync disabled by configuration")
        return None
    if args.keyboard_event:
        event_path, _ = prefer_stable_keyboard_event_path(
            args.keyboard_event,
            ["/dev/input/by-id/*-event-kbd", "/dev/input/by-path/*-event-kbd"],
        )
    else:
        event_path = autodetect_keyboard_event()
    logging.info("Using keyboard input device: %s", event_path)
    return KeyboardSyncService(
        event_path=event_path,
        hidg_path=args.keyboard_hidg,
        auto_rebind_event=args.keyboard_auto_rebind_event,
        udc_state_path="",
        enable_hid_output=False,
        report_callback=report_callback,
    )


def build_workers(args: argparse.Namespace, udc_state_path: str) -> List[threading.Thread]:
    mouse_writer = None
    keyboard_writer = None
    if args.enable_hid_output:
        mouse_writer = MouseHidWriter(
            hidg_path=args.hidg,
            udc_state_path=udc_state_path,
            hid_profile=args.hid_profile,
            home_on_connect=args.home_on_connect,
            home_steps=args.home_steps,
            start_bias_x=args.start_bias_x,
            start_bias_y=args.start_bias_y,
            home_rounds=args.home_rounds,
            connect_settle_ms=args.connect_settle_ms,
            hid_lock_path=args.hid_lock_path,
        )
        if args.enable_keyboard:
            keyboard_writer = KeyboardHidWriter(args.keyboard_hidg, udc_state_path, args.hid_lock_path)

    router = BridgeRouter(
        enable_hid_output=args.enable_hid_output,
        enable_network=args.enable_network,
        input_priority=args.input_priority,
        local_idle_timeout_ms=args.local_idle_timeout_ms,
        mouse_writer=mouse_writer,
        keyboard_writer=keyboard_writer,
    )

    workers: List[threading.Thread] = []
    if not args.disable_action_tcp or not args.disable_action_udp:
        action_settings = HidActionSettings(
            config_path=args.actions_config,
            mouse_hidg_path=args.hidg,
            keyboard_hidg_path=args.keyboard_hidg,
            hid_profile=args.hid_profile,
            hid_lock_path=args.hid_lock_path,
            udc_state_path=udc_state_path,
        )
        dispatcher = ActionDispatcher(
            queue_size=args.action_tcp_queue_size,
            action_settings=action_settings,
        )
        workers.append(dispatcher)

        if not args.disable_action_tcp:
            workers.append(
                ActionTcpServer(
                    host=args.action_tcp_host,
                    port=args.action_tcp_port,
                    max_line_bytes=args.action_tcp_max_line_bytes,
                    dispatcher=dispatcher,
                )
            )

        if not args.disable_action_udp:
            workers.append(
                ActionUdpServer(
                    host=args.action_udp_host,
                    port=args.action_udp_port,
                    max_datagram_bytes=args.action_udp_max_datagram_bytes,
                    dispatcher=dispatcher,
                )
            )

    if args.action_only:
        return workers

    if args.enable_network:
        initial_reports = {
            FRAME_TYPE_MOUSE: build_zero_mouse_report(args.hid_profile),
        }
        if args.enable_keyboard:
            initial_reports[FRAME_TYPE_KEYBOARD] = bytes([0] * 8)
        network = TcpConnectionManager(
            role=args.network_role,
            host=args.network_host,
            port=args.network_port,
            retry_interval=max(0.1, float(args.network_retry_ms) / 1000.0),
            connect_timeout=max(0.2, float(args.network_connect_timeout_ms) / 1000.0),
        )
        peer = NetworkPeer(
            connection=network,
            router=router,
            enable_send=True,
            initial_reports=initial_reports,
            queue_size=args.network_queue_size,
        )
        router.attach_network_peer(peer)
        workers.append(peer)

    mouse_service = build_mouse_service(
        args,
        report_callback=lambda report: router.handle_local_report(FRAME_TYPE_MOUSE, report),
    )
    workers.append(ServiceThread("mouse-sync", mouse_service))

    keyboard_service = build_keyboard_service(
        args,
        report_callback=lambda report: router.handle_local_report(FRAME_TYPE_KEYBOARD, report),
    )
    if keyboard_service is not None:
        workers.append(ServiceThread("keyboard-sync", keyboard_service))

    return workers


def main() -> int:
    args = parse_args()
    logging.basicConfig(level=getattr(logging, args.log_level), format="%(asctime)s %(levelname)s %(message)s")

    if args.action_only and args.disable_action_tcp and args.disable_action_udp:
        logging.error("--action-only requires at least one action server to be enabled")
        return 2

    udc_state_path = ""
    if args.enable_hid_output:
        udc_state_path = args.udc_state_path or autodetect_udc_state_path() or ""
        if udc_state_path:
            logging.info("Using UDC state path: %s", udc_state_path)

    logging.info(
        "Capabilities: hid_output=%s network=%s keyboard=%s input_priority=%s local_idle_timeout_ms=%d",
        args.enable_hid_output,
        args.enable_network,
        args.enable_keyboard,
        args.input_priority,
        args.local_idle_timeout_ms,
    )
    logging.info(
        "Action TCP: enabled=%s host=%s port=%d queue_size=%d actions=%s",
        not args.disable_action_tcp,
        args.action_tcp_host,
        args.action_tcp_port,
        args.action_tcp_queue_size,
        args.actions_config,
    )
    logging.info(
        "Action UDP: enabled=%s host=%s port=%d max_datagram_bytes=%d",
        not args.disable_action_udp,
        args.action_udp_host,
        args.action_udp_port,
        args.action_udp_max_datagram_bytes,
    )
    if args.enable_network:
        logging.info(
            "Network cfg: role=%s host=%s port=%d retry_ms=%d",
            args.network_role,
            args.network_host,
            args.network_port,
            args.network_retry_ms,
        )

    workers = build_workers(args, udc_state_path)
    bridge = UnifiedBridge(workers)
    signal.signal(signal.SIGTERM, lambda _s, _f: bridge.stop())
    signal.signal(signal.SIGINT, lambda _s, _f: bridge.stop())
    return bridge.run()


if __name__ == "__main__":
    raise SystemExit(main())
