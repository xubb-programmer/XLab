#!/usr/bin/env python3
"""Mirror a Linux mouse (/dev/input/eventX) to a USB HID gadget mouse (/dev/hidg0)."""

import argparse
import errno
import glob
import logging
import math
import os
import pwd
import grp
import select
import signal
import struct
import subprocess
import time
from typing import Callable, Dict, List, Optional, Tuple

from usb_hid_actions import HidOutputLock

EV_SYN = 0x00
EV_KEY = 0x01
EV_REL = 0x02

SYN_REPORT = 0

REL_X = 0x00
REL_Y = 0x01
REL_HWHEEL = 0x06
REL_WHEEL = 0x08
REL_WHEEL_HI_RES = 0x0B
REL_HWHEEL_HI_RES = 0x0C

BTN_LEFT = 272
BTN_RIGHT = 273
BTN_MIDDLE = 274
BTN_SIDE = 275
BTN_EXTRA = 276

BUTTON_BITS = {
    BTN_LEFT: 0,
    BTN_RIGHT: 1,
    BTN_MIDDLE: 2,
    BTN_SIDE: 3,
    BTN_EXTRA: 4,
}

# Linux input_event: struct timeval + type(u16) + code(u16) + value(s32)
INPUT_EVENT = struct.Struct("llHHi")
HID_TRANSIENT_ERRNOS = {
    errno.ESHUTDOWN,
    errno.EPIPE,
    errno.ENOTCONN,
    errno.ENODEV,
    errno.ECONNRESET,
    errno.ECONNABORTED,
}
CURSOR_ENV_KEYS = ("DISPLAY", "XAUTHORITY", "XDG_RUNTIME_DIR")
SESSION_PROCESS_HINTS = {
    "gnome-shell",
    "Xorg",
    "Xwayland",
    "mutter",
    "weston",
    "kwin_wayland",
    "sway",
}
DEFAULT_CONNECT_SETTLE_MS = 220
DEFAULT_ALIGN_RETRIES = 8
DEFAULT_ALIGN_RETRY_INTERVAL_MS = 60
DEFAULT_ALIGN_STEP_MAX = 12
DEFAULT_ALIGN_STEP_SLEEP_MS = 1
EVENT_PRIORITY_BY_ID = 300
EVENT_PRIORITY_BY_PATH = 200
EVENT_PRIORITY_HEURISTIC = 100
EVENT_PRIORITY_FALLBACK = 10


class MouseState:
    def __init__(self) -> None:
        self.buttons = 0
        self.dx = 0
        self.dy = 0
        self.wheel = 0
        self.hwheel = 0
        self.wheel_hires_remainder = 0
        self.hwheel_hires_remainder = 0
        self.dirty = False


class CursorMapper:
    def __init__(
        self,
        mode: str,
        src_w: int,
        src_h: int,
        dst_w: int,
        dst_h: int,
        src_offset_x: int = 0,
        src_offset_y: int = 0,
        dst_offset_x: int = 0,
        dst_offset_y: int = 0,
        dst_active_w: int = 0,
        dst_active_h: int = 0,
    ) -> None:
        self.mode = mode
        self.src_w = max(1, src_w)
        self.src_h = max(1, src_h)
        self.dst_w = max(1, dst_w)
        self.dst_h = max(1, dst_h)
        self.src_offset_x = src_offset_x
        self.src_offset_y = src_offset_y
        self.dst_offset_x = max(0, min(dst_offset_x, self.dst_w - 1))
        self.dst_offset_y = max(0, min(dst_offset_y, self.dst_h - 1))
        self.dst_active_w = max(1, dst_active_w or self.dst_w)
        self.dst_active_h = max(1, dst_active_h or self.dst_h)
        self.dst_active_w = min(self.dst_active_w, self.dst_w - self.dst_offset_x)
        self.dst_active_h = min(self.dst_active_h, self.dst_h - self.dst_offset_y)
        self.src_x = self.src_w / 2.0
        self.src_y = self.src_h / 2.0
        self.dst_x = self.dst_w / 2.0
        self.dst_y = self.dst_h / 2.0

    def recenter(self) -> None:
        self.src_x = self.src_w / 2.0
        self.src_y = self.src_h / 2.0
        self.dst_x = self.dst_w / 2.0
        self.dst_y = self.dst_h / 2.0

    def apply_relative(self, dx: int, dy: int) -> Tuple[int, int]:
        if self.mode == "relative":
            return dx, dy

        self.src_x += dx
        self.src_y += dy
        self.src_x = clamp_float(self.src_x, 0.0, float(self.src_w - 1))
        self.src_y = clamp_float(self.src_y, 0.0, float(self.src_h - 1))

        target_x = self.src_x * (self.dst_w - 1) / max(1, self.src_w - 1)
        target_y = self.src_y * (self.dst_h - 1) / max(1, self.src_h - 1)

        out_dx = int(round(target_x - self.dst_x))
        out_dy = int(round(target_y - self.dst_y))

        self.dst_x += out_dx
        self.dst_y += out_dy
        self.dst_x = clamp_float(self.dst_x, 0.0, float(self.dst_w - 1))
        self.dst_y = clamp_float(self.dst_y, 0.0, float(self.dst_h - 1))
        return out_dx, out_dy

    def apply_absolute(self, abs_x: int, abs_y: int) -> Tuple[int, int]:
        src_x = clamp_float(float(abs_x - self.src_offset_x), 0.0, float(self.src_w - 1))
        src_y = clamp_float(float(abs_y - self.src_offset_y), 0.0, float(self.src_h - 1))
        self.src_x = src_x
        self.src_y = src_y

        target_x = self.dst_offset_x + src_x * (self.dst_active_w - 1) / max(1, self.src_w - 1)
        target_y = self.dst_offset_y + src_y * (self.dst_active_h - 1) / max(1, self.src_h - 1)

        out_dx = int(round(target_x - self.dst_x))
        out_dy = int(round(target_y - self.dst_y))
        self.dst_x += out_dx
        self.dst_y += out_dy
        self.dst_x = clamp_float(self.dst_x, 0.0, float(self.dst_w - 1))
        self.dst_y = clamp_float(self.dst_y, 0.0, float(self.dst_h - 1))
        return out_dx, out_dy


class MouseSyncService:
    def __init__(
        self,
        event_path: str,
        hidg_path: str,
        move_scale: float,
        wheel_scale: float,
        read_chunk_events: int,
        udc_state_path: Optional[str] = None,
        hid_profile: str = "extended5",
        home_on_connect: bool = True,
        home_steps: int = 24,
        start_bias_x: int = 0,
        start_bias_y: int = 0,
        mouse_mode: str = "relative",
        src_width: int = 1920,
        src_height: int = 1080,
        dst_width: int = 1280,
        dst_height: int = 720,
        autodetect_event: bool = True,
        src_offset_x: int = 0,
        src_offset_y: int = 0,
        dst_offset_x: int = 0,
        dst_offset_y: int = 0,
        dst_active_width: int = 0,
        dst_active_height: int = 0,
        use_cursor_query: bool = True,
        cursor_query_cmd: str = "xdotool",
        cursor_query_user: str = "",
        cursor_display: str = "",
        cursor_xauthority: str = "",
        cursor_xdg_runtime_dir: str = "",
        cursor_timeout_ms: int = 120,
        align_on_connect: bool = True,
        connect_settle_ms: int = DEFAULT_CONNECT_SETTLE_MS,
        home_rounds: int = 2,
        align_retries: int = DEFAULT_ALIGN_RETRIES,
        align_retry_interval_ms: int = DEFAULT_ALIGN_RETRY_INTERVAL_MS,
        source_home_on_connect: bool = False,
        strict_absolute_query: bool = True,
        align_step_max: int = DEFAULT_ALIGN_STEP_MAX,
        align_step_sleep_ms: int = DEFAULT_ALIGN_STEP_SLEEP_MS,
        enable_hid_output: bool = True,
        report_callback: Optional[Callable[[bytes], None]] = None,
    ) -> None:
        self.event_path = event_path
        self.preferred_event_identity = read_event_identity(event_path)
        self.event_priority = score_event_candidate(event_path, self.preferred_event_identity)
        self.hidg_path = hidg_path
        self.move_scale = move_scale
        self.wheel_scale = wheel_scale
        self.read_chunk_events = max(1, read_chunk_events)
        self.udc_state_path = udc_state_path
        self.hid_profile = hid_profile
        self.home_on_connect = home_on_connect
        self.home_steps = max(1, home_steps)
        self.start_bias_x = start_bias_x
        self.start_bias_y = start_bias_y
        self.mouse_mode = mouse_mode
        self.autodetect_event = autodetect_event
        self.src_offset_x = src_offset_x
        self.src_offset_y = src_offset_y
        self.use_cursor_query = use_cursor_query and mouse_mode == "absolute-map"
        self.cursor_query_cmd = cursor_query_cmd
        self.cursor_query_user = cursor_query_user.strip()
        self.cursor_display = cursor_display.strip()
        self.cursor_xauthority = cursor_xauthority.strip()
        self.cursor_xdg_runtime_dir = cursor_xdg_runtime_dir.strip()
        self.cursor_timeout = max(0.03, float(cursor_timeout_ms) / 1000.0)
        self.cursor_user_uid: Optional[int] = None
        self.cursor_user_gid: Optional[int] = None
        self.cursor_user_home: str = ""
        self.align_on_connect = align_on_connect and self.use_cursor_query and mouse_mode == "absolute-map"
        self.connect_settle = max(0.0, float(connect_settle_ms) / 1000.0)
        self.home_rounds = max(1, home_rounds)
        self.align_retries = max(1, align_retries)
        self.align_retry_interval = max(0.0, float(align_retry_interval_ms) / 1000.0)
        self.source_home_on_connect = source_home_on_connect and mouse_mode == "absolute-map"
        self.strict_absolute_query = strict_absolute_query and mouse_mode == "absolute-map"
        self.align_step_max = max(1, align_step_max)
        self.align_step_sleep = max(0.0, float(align_step_sleep_ms) / 1000.0)
        self.enable_hid_output = enable_hid_output
        self.report_callback = report_callback

        self.state = MouseState()
        self.mapper = CursorMapper(
            mouse_mode,
            src_width,
            src_height,
            dst_width,
            dst_height,
            src_offset_x=src_offset_x,
            src_offset_y=src_offset_y,
            dst_offset_x=dst_offset_x,
            dst_offset_y=dst_offset_y,
            dst_active_w=dst_active_width,
            dst_active_h=dst_active_height,
        )

        self.event_fd: Optional[int] = None
        self.hidg_fd: Optional[int] = None
        self.running = True
        self.last_link_down_log = 0.0
        self.last_event_open_log = 0.0
        self.last_cursor_query_log = 0.0
        self.last_align_log = 0.0
        self.last_event_drop_log = 0.0
        self.cursor_query_disabled = False
        self.connect_align_pending = self.align_on_connect
        self._resolve_cursor_user_identity()
        self.cursor_query_env, self.cursor_query_env_source = self._build_cursor_query_env()
        self.cursor_query_argv = [self.cursor_query_cmd, "getmouselocation", "--shell"]

    def stop(self) -> None:
        self.running = False

    def run(self) -> None:
        while self.running:
            try:
                self._maybe_close_event_on_source_drop()
                self._maybe_reopen_event_on_source_change()
                self._maybe_close_hidg_on_link_down()
                if not self._ensure_open():
                    time.sleep(0.5)
                    continue

                self._maybe_align_pending()
                if self.autodetect_event:
                    self._maybe_switch_event_device()
                    if self.event_fd is None:
                        time.sleep(0.05)
                        continue
                ready, _, _ = select.select([self.event_fd], [], [], 1.0)
                if not ready:
                    self._maybe_close_event_on_source_drop()
                    self._maybe_reopen_event_on_source_change()
                    self._maybe_close_hidg_on_link_down()
                    self._maybe_align_pending()
                    continue

                raw = os.read(self.event_fd, INPUT_EVENT.size * self.read_chunk_events)
                if not raw:
                    raise OSError(errno.ENODEV, "input device disconnected")

                usable = (len(raw) // INPUT_EVENT.size) * INPUT_EVENT.size
                for off in range(0, usable, INPUT_EVENT.size):
                    _, _, ev_type, code, value = INPUT_EVENT.unpack_from(raw, off)
                    self._handle_event(ev_type, code, value)
            except OSError as exc:
                if exc.errno in HID_TRANSIENT_ERRNOS:
                    self._log_link_down(exc)
                    self._close_hidg_fd()
                    time.sleep(0.2)
                    continue
                if exc.errno in {errno.ENODEV, errno.ENXIO, errno.EIO, errno.EBADF}:
                    logging.warning("Input device dropped (%s), reopen", exc)
                    self._clear_input_state()
                    self._close_event_fd()
                    if self.autodetect_event:
                        self._maybe_switch_event_device()
                    time.sleep(0.2)
                    continue
                logging.warning("I/O error (%s), reopen devices", exc)
                self._close_fds()
                time.sleep(0.5)
            except BlockingIOError:
                time.sleep(0.01)
                continue
            except InterruptedError:
                continue
            except Exception as exc:
                logging.warning("I/O error (%s), reopen devices", exc)
                self._close_fds()
                time.sleep(0.5)

        self._close_fds()

    def _ensure_open(self) -> bool:
        if self.event_fd is None:
            if self.autodetect_event:
                self._maybe_switch_event_device()
            try:
                self.event_fd = os.open(self.event_path, os.O_RDONLY | os.O_CLOEXEC | os.O_NONBLOCK)
                logging.info("Opened input device: %s", self.event_path)
            except FileNotFoundError:
                self._throttled_log_event_missing("Input device missing: %s", self.event_path)
                return False
            except PermissionError:
                logging.error("Permission denied for input device: %s", self.event_path)
                return False

        if self.enable_hid_output and self.hidg_fd is None:
            if not self._udc_ready_for_io():
                return False
            try:
                # Use non-blocking fd so service stop won't hang on a blocked HID write.
                self.hidg_fd = os.open(self.hidg_path, os.O_RDWR | os.O_CLOEXEC | os.O_NONBLOCK)
                logging.info("Opened HID gadget device: %s", self.hidg_path)
                self.mapper.recenter()
                if self.connect_settle > 0:
                    time.sleep(self.connect_settle)
                if self.home_on_connect:
                    self._sync_cursor_origin()
                if self.align_on_connect:
                    self.connect_align_pending = not self._align_target_to_source()
            except FileNotFoundError:
                logging.warning("HID gadget device missing: %s", self.hidg_path)
                return False
            except PermissionError:
                logging.error("Permission denied for HID gadget device: %s", self.hidg_path)
                return False

        return True

    def _maybe_switch_event_device(self) -> None:
        try:
            new_event = autodetect_mouse_event(self.preferred_event_identity)
        except FileNotFoundError:
            return
        new_path, new_priority = new_event
        current_available = os.path.exists(self.event_path)
        should_switch = False
        if new_path == self.event_path:
            self.event_priority = new_priority
            return
        if not current_available:
            should_switch = True
        elif new_priority > self.event_priority:
            should_switch = True
        if should_switch:
            logging.info("Switch input device: %s -> %s", self.event_path, new_path)
            self.event_path = new_path
            self.event_priority = new_priority
            self._close_event_fd()

    def _throttled_log_event_missing(self, fmt: str, *args) -> None:
        now = time.time()
        if now - self.last_event_open_log < 3.0:
            return
        self.last_event_open_log = now
        logging.warning(fmt, *args)

    def _udc_ready_for_io(self) -> bool:
        state = self._read_udc_state()
        return not state or state == "configured"

    def _read_udc_state(self) -> str:
        if not self.udc_state_path:
            return ""
        try:
            with open(self.udc_state_path, "r", encoding="utf-8", errors="ignore") as f:
                return f.read().strip().lower()
        except FileNotFoundError:
            return ""
        except OSError:
            return ""

    def _maybe_close_hidg_on_link_down(self) -> None:
        if self.hidg_fd is None:
            return
        state = self._read_udc_state()
        if state and state != "configured":
            self._log_link_down_state(state)
            self._close_hidg_fd()

    def _close_fds(self) -> None:
        self._close_event_fd()
        self._close_hidg_fd()

    def _close_event_fd(self) -> None:
        if self.event_fd is not None:
            os.close(self.event_fd)
            self.event_fd = None

    def _maybe_close_event_on_source_drop(self) -> None:
        if self.event_fd is None:
            return
        if os.path.exists(self.event_path):
            return
        self._throttled_event_drop_log("Input source disappeared: %s", self.event_path)
        self._clear_input_state()
        self._close_event_fd()

    def _maybe_reopen_event_on_source_change(self) -> None:
        if self.event_fd is None:
            return
        try:
            current_target = os.path.realpath(self.event_path)
            current_stat = os.stat(current_target)
            fd_stat = os.fstat(self.event_fd)
        except FileNotFoundError:
            return
        except OSError:
            return
        if fd_stat.st_ino == current_stat.st_ino and fd_stat.st_dev == current_stat.st_dev:
            return
        self._throttled_event_drop_log(
            "Input source changed behind stable path: %s -> %s, reopen",
            self.event_path,
            current_target,
        )
        self._clear_input_state()
        self._close_event_fd()

    def _clear_input_state(self) -> None:
        self.state = MouseState()
        if self.hidg_fd is None and self.report_callback is None:
            return
        try:
            self._write_report(0, 0, 0, 0, 0)
        except OSError:
            if self.enable_hid_output:
                self._close_hidg_fd()

    def _throttled_event_drop_log(self, fmt: str, *args) -> None:
        now = time.time()
        if now - self.last_event_drop_log < 2.0:
            return
        self.last_event_drop_log = now
        logging.warning(fmt, *args)

    def _close_hidg_fd(self) -> None:
        if self.hidg_fd is not None:
            os.close(self.hidg_fd)
            self.hidg_fd = None
        if self.align_on_connect:
            self.connect_align_pending = True

    def _handle_event(self, ev_type: int, code: int, value: int) -> None:
        if ev_type == EV_KEY and code in BUTTON_BITS:
            bit = 1 << BUTTON_BITS[code]
            if value:
                self.state.buttons |= bit
            else:
                self.state.buttons &= ~bit
            self.state.dirty = True
            return

        if ev_type == EV_REL:
            if code == REL_X:
                self.state.dx += scaled_int(value, self.move_scale)
                self.state.dirty = True
            elif code == REL_Y:
                self.state.dy += scaled_int(value, self.move_scale)
                self.state.dirty = True
            elif code == REL_WHEEL:
                self.state.wheel += scaled_int(value, self.wheel_scale)
                self.state.dirty = True
            elif code == REL_HWHEEL:
                self.state.hwheel += scaled_int(value, self.wheel_scale)
                self.state.dirty = True
            elif code == REL_WHEEL_HI_RES:
                self._ingest_hires_wheel(value, horizontal=False)
            elif code == REL_HWHEEL_HI_RES:
                self._ingest_hires_wheel(value, horizontal=True)
            return

        if ev_type == EV_SYN and code == SYN_REPORT:
            self._flush_state()

    def _ingest_hires_wheel(self, value: int, horizontal: bool) -> None:
        if horizontal:
            total = self.state.hwheel_hires_remainder + value
            steps = math.trunc(total / 120)
            self.state.hwheel_hires_remainder = total - steps * 120
            if steps:
                self.state.hwheel += scaled_int(steps, self.wheel_scale)
                self.state.dirty = True
        else:
            total = self.state.wheel_hires_remainder + value
            steps = math.trunc(total / 120)
            self.state.wheel_hires_remainder = total - steps * 120
            if steps:
                self.state.wheel += scaled_int(steps, self.wheel_scale)
                self.state.dirty = True

    def _flush_state(self) -> None:
        if not self.state.dirty:
            return

        if self.mouse_mode == "absolute-map":
            cursor = self._query_cursor_position()
            if cursor is not None:
                mapped_dx, mapped_dy = self.mapper.apply_absolute(cursor[0], cursor[1])
                if self.align_on_connect:
                    self.connect_align_pending = False
            else:
                if self.align_on_connect:
                    self.connect_align_pending = True
                if self.strict_absolute_query:
                    self.state.dx = 0
                    self.state.dy = 0
                    self.state.wheel = 0
                    self.state.hwheel = 0
                    self.state.dirty = False
                    return
                mapped_dx, mapped_dy = self.mapper.apply_relative(self.state.dx, self.state.dy)
        else:
            mapped_dx, mapped_dy = self.mapper.apply_relative(self.state.dx, self.state.dy)
        dx = mapped_dx
        dy = mapped_dy
        wheel = self.state.wheel
        hwheel = self.state.hwheel

        while dx or dy or wheel or hwheel:
            step_dx = clamp_s8(dx)
            step_dy = clamp_s8(dy)
            step_wheel = clamp_s8(wheel)
            step_hwheel = clamp_s8(hwheel)
            self._write_report(self.state.buttons, step_dx, step_dy, step_wheel, step_hwheel)
            dx -= step_dx
            dy -= step_dy
            wheel -= step_wheel
            hwheel -= step_hwheel

        self._write_report(self.state.buttons, 0, 0, 0, 0)

        self.state.dx = 0
        self.state.dy = 0
        self.state.wheel = 0
        self.state.hwheel = 0
        self.state.dirty = False

    def _write_report(self, buttons: int, dx: int, dy: int, wheel: int, hwheel: int) -> None:
        if self.hid_profile == "boot3":
            report = bytes(
                [
                    buttons & 0x07,
                    dx & 0xFF,
                    dy & 0xFF,
                ]
            )
        else:
            report = bytes(
                [
                    buttons & 0x1F,
                    dx & 0xFF,
                    dy & 0xFF,
                    wheel & 0xFF,
                    hwheel & 0xFF,
                ]
            )
        if self.report_callback is not None:
            self.report_callback(report)
        if not self.enable_hid_output or self.hidg_fd is None:
            return
        try:
            with HidOutputLock(os.environ.get("HID_LOCK_PATH", "/run/lock/usb-mouse-sync-hid.lock")):
                os.write(self.hidg_fd, report)
        except BlockingIOError:
            # Non-blocking hidg0 may transiently return would-block.
            # Drop this report and let subsequent sync reports catch up.
            return
        except OSError as exc:
            if exc.errno in {errno.EAGAIN, errno.EWOULDBLOCK}:
                return
            raise

    def _log_link_down(self, exc: OSError) -> None:
        now = time.time()
        if now - self.last_link_down_log < 3.0:
            return
        self.last_link_down_log = now
        state = self._read_udc_state()
        if self.udc_state_path and not state:
            state = "unknown"
        if state:
            logging.warning("HID endpoint down (%s), udc_state=%s", exc, state)
        else:
            logging.warning("HID endpoint down (%s)", exc)

    def _log_link_down_state(self, state: str) -> None:
        now = time.time()
        if now - self.last_link_down_log < 3.0:
            return
        self.last_link_down_log = now
        logging.warning("USB link not configured, closing HID gadget fd (udc_state=%s)", state)

    def _sync_cursor_origin(self) -> None:
        for _ in range(self.home_rounds):
            for _ in range(self.home_steps):
                self._write_report(0, -127, -127, 0, 0)
            self._write_report(0, 0, 0, 0, 0)
            time.sleep(0.01)
        if self.start_bias_x or self.start_bias_y:
            dx = self.start_bias_x
            dy = self.start_bias_y
            while dx or dy:
                step_dx = clamp_s8(dx)
                step_dy = clamp_s8(dy)
                self._write_report(0, step_dx, step_dy, 0, 0)
                dx -= step_dx
                dy -= step_dy
        self._write_report(0, 0, 0, 0, 0)
        self.mapper.dst_x = 0.0
        self.mapper.dst_y = 0.0

    def _align_target_to_source(self) -> bool:
        if self.mouse_mode != "absolute-map":
            return True
        if self.source_home_on_connect:
            self._home_source_cursor()

        last_cursor = None
        for idx in range(self.align_retries):
            cursor = self._query_cursor_position()
            if cursor is not None:
                last_cursor = cursor
                dx, dy = self.mapper.apply_absolute(cursor[0], cursor[1])
                self._emit_movement(dx, dy)
                self._write_report(self.state.buttons, 0, 0, 0, 0)
                logging.info(
                    "Aligned target cursor on connect: src=(%d,%d) delta=(%d,%d) try=%d",
                    cursor[0],
                    cursor[1],
                    dx,
                    dy,
                    idx + 1,
                )
                return True
            if self.align_retry_interval > 0:
                time.sleep(self.align_retry_interval)
        self._throttled_align_log(
            "Connect align failed (no source cursor query), strict_absolute_query=%s last_cursor=%s",
            self.strict_absolute_query,
            repr(last_cursor),
        )
        return False

    def _maybe_align_pending(self) -> None:
        if not self.connect_align_pending:
            return
        if self.hidg_fd is None:
            return
        if not self.align_on_connect:
            self.connect_align_pending = False
            return
        if self._align_target_to_source():
            self.connect_align_pending = False

    def _emit_movement(self, dx: int, dy: int) -> None:
        while dx or dy:
            step_dx = clamp_int(dx, -self.align_step_max, self.align_step_max)
            step_dy = clamp_int(dy, -self.align_step_max, self.align_step_max)
            self._write_report(self.state.buttons, step_dx, step_dy, 0, 0)
            dx -= step_dx
            dy -= step_dy
            if self.align_step_sleep > 0:
                time.sleep(self.align_step_sleep)

    def _build_cursor_control_prefix(self) -> list:
        return []

    def _home_source_cursor(self) -> None:
        move_cmd = [self.cursor_query_cmd, "mousemove", "0", "0"]
        preexec = self._cursor_preexec_fn()
        try:
            proc = subprocess.run(
                move_cmd,
                env=self.cursor_query_env,
                capture_output=True,
                text=True,
                timeout=max(self.cursor_timeout, 0.2),
                check=False,
                preexec_fn=preexec,
            )
        except Exception as exc:
            self._throttled_align_log("Source home command failed (%s)", exc)
            return
        if proc.returncode != 0:
            self._throttled_align_log(
                "Source home returned code %d stderr=%r",
                proc.returncode,
                proc.stderr.strip(),
            )
            return
        time.sleep(0.02)

    def _resolve_cursor_user_identity(self) -> None:
        if not self.cursor_query_user:
            return
        try:
            pw = pwd.getpwnam(self.cursor_query_user)
        except KeyError:
            self._throttled_align_log("Cursor query user not found: %s", self.cursor_query_user)
            return
        self.cursor_user_uid = pw.pw_uid
        self.cursor_user_gid = pw.pw_gid
        self.cursor_user_home = pw.pw_dir

    def _cursor_preexec_fn(self):
        if os.geteuid() != 0:
            return None
        if self.cursor_user_uid is None or self.cursor_user_gid is None:
            return None

        target_uid = self.cursor_user_uid
        target_gid = self.cursor_user_gid
        target_user = self.cursor_query_user

        def _drop_privileges():
            try:
                groups = [g.gr_gid for g in grp.getgrall() if target_user in g.gr_mem]
            except Exception:
                groups = []
            if target_gid not in groups:
                groups.append(target_gid)
            try:
                os.setgroups(groups)
            except Exception:
                pass
            os.setgid(target_gid)
            os.setuid(target_uid)

        return _drop_privileges

    def _throttled_align_log(self, fmt: str, *args) -> None:
        now = time.time()
        if now - self.last_align_log < 3.0:
            return
        self.last_align_log = now
        logging.warning(fmt, *args)

    def _query_cursor_position(self) -> Optional[Tuple[int, int]]:
        if not self.use_cursor_query or self.cursor_query_disabled:
            return None
        cmd = self._build_cursor_query_command()
        preexec = self._cursor_preexec_fn()
        try:
            proc = subprocess.run(
                cmd,
                env=self.cursor_query_env,
                capture_output=True,
                text=True,
                timeout=self.cursor_timeout,
                check=False,
                preexec_fn=preexec,
            )
        except FileNotFoundError:
            self._throttled_cursor_log(
                "Cursor query cmd not found (%s), fallback to relative mapping",
                self.cursor_query_cmd,
            )
            self.cursor_query_disabled = True
            return None
        except Exception as exc:
            self._throttled_cursor_log("Cursor query failed (%s), fallback to relative mapping", exc)
            return None

        if proc.returncode != 0:
            self._throttled_cursor_log(
                "Cursor query returned code %d env=%s stderr=%r, fallback to relative mapping",
                proc.returncode,
                self._short_cursor_env(),
                proc.stderr.strip(),
            )
            return None

        x = None
        y = None
        for line in proc.stdout.splitlines():
            if line.startswith("X="):
                try:
                    x = int(line.split("=", 1)[1].strip())
                except ValueError:
                    x = None
            elif line.startswith("Y="):
                try:
                    y = int(line.split("=", 1)[1].strip())
                except ValueError:
                    y = None
        if x is None or y is None:
            self._throttled_cursor_log("Cursor query parse failed, fallback to relative mapping")
            return None
        return (x, y)

    def _build_cursor_query_command(self) -> list:
        return list(self.cursor_query_argv)

    def _build_cursor_query_env(self) -> Tuple[dict, str]:
        env = dict(os.environ)
        source = "process-env"

        if self.cursor_display:
            env["DISPLAY"] = self.cursor_display
            source = "config"
        if self.cursor_xauthority:
            env["XAUTHORITY"] = self.cursor_xauthority
            source = "config"
        if self.cursor_xdg_runtime_dir:
            env["XDG_RUNTIME_DIR"] = self.cursor_xdg_runtime_dir
            source = "config"

        if not env.get("DISPLAY"):
            env["DISPLAY"] = ":0"

        auto_env = {}
        auto_source = ""
        if not self.cursor_display or not env.get("XAUTHORITY"):
            auto_env, auto_source = autodetect_x11_env(self.cursor_query_user)
            for k, v in auto_env.items():
                if v and not env.get(k):
                    env[k] = v
            if auto_source:
                source = auto_source

        if not env.get("XAUTHORITY"):
            xauth = guess_xauthority_path(self.cursor_query_user, env.get("XDG_RUNTIME_DIR", ""))
            if xauth:
                env["XAUTHORITY"] = xauth
                if source == "process-env":
                    source = "guess-xauthority"

        return env, source

    def _short_cursor_env(self) -> str:
        parts = []
        for key in CURSOR_ENV_KEYS:
            value = self.cursor_query_env.get(key, "")
            if value:
                parts.append(f"{key}={value}")
        if not parts:
            return "none"
        return ",".join(parts)

    def _throttled_cursor_log(self, fmt: str, *args) -> None:
        now = time.time()
        if now - self.last_cursor_query_log < 5.0:
            return
        self.last_cursor_query_log = now
        logging.warning(fmt, *args)


def clamp_s8(value: int) -> int:
    return max(-127, min(127, value))


def clamp_int(value: int, low: int, high: int) -> int:
    if value < low:
        return low
    if value > high:
        return high
    return value


def clamp_float(value: float, low: float, high: float) -> float:
    if value < low:
        return low
    if value > high:
        return high
    return value


def scaled_int(value: int, scale: float) -> int:
    return int(round(value * scale))


def read_proc_environ(pid: str) -> dict:
    env = {}
    path = f"/proc/{pid}/environ"
    try:
        data = open(path, "rb").read()
    except OSError:
        return env
    for item in data.split(b"\0"):
        if not item or b"=" not in item:
            continue
        key_b, value_b = item.split(b"=", 1)
        try:
            key = key_b.decode("utf-8", errors="ignore")
            value = value_b.decode("utf-8", errors="ignore")
        except Exception:
            continue
        if key:
            env[key] = value
    return env


def guess_xauthority_path(preferred_user: str, xdg_runtime_dir: str) -> str:
    paths = []
    uid = None
    home = ""
    if preferred_user:
        try:
            pw = pwd.getpwnam(preferred_user)
            uid = pw.pw_uid
            home = pw.pw_dir
        except KeyError:
            pass
    if xdg_runtime_dir:
        paths.append(os.path.join(xdg_runtime_dir, "gdm", "Xauthority"))
        for p in sorted(glob.glob(os.path.join(xdg_runtime_dir, ".mutter-Xwaylandauth.*"))):
            paths.append(p)
        paths.append(os.path.join(xdg_runtime_dir, "Xauthority"))
    if uid is not None:
        runtime = f"/run/user/{uid}"
        paths.append(os.path.join(runtime, "gdm", "Xauthority"))
        for p in sorted(glob.glob(os.path.join(runtime, ".mutter-Xwaylandauth.*"))):
            paths.append(p)
        paths.append(os.path.join(runtime, "Xauthority"))
    if home:
        paths.append(os.path.join(home, ".Xauthority"))
    for p in paths:
        if p and os.path.exists(p):
            return p
    return ""


def autodetect_x11_env(preferred_user: str = "") -> Tuple[dict, str]:
    preferred_uid = None
    if preferred_user:
        try:
            preferred_uid = pwd.getpwnam(preferred_user).pw_uid
        except KeyError:
            preferred_uid = None

    best_score = -1
    best_env = {}
    best_src = ""
    for proc_dir in glob.glob("/proc/[0-9]*"):
        pid = os.path.basename(proc_dir)
        try:
            st = os.stat(proc_dir)
        except OSError:
            continue
        if preferred_uid is not None and st.st_uid != preferred_uid:
            continue

        env = read_proc_environ(pid)
        display = env.get("DISPLAY", "")
        if not display:
            continue

        score = 0
        comm = ""
        try:
            comm = open(f"/proc/{pid}/comm", "r", encoding="utf-8", errors="ignore").read().strip()
        except OSError:
            comm = ""
        if comm in SESSION_PROCESS_HINTS:
            score += 8
        if env.get("XAUTHORITY"):
            score += 16
        if env.get("XDG_RUNTIME_DIR"):
            score += 6
        if preferred_uid is not None and st.st_uid == preferred_uid:
            score += 12

        if score > best_score:
            best_score = score
            best_env = {
                "DISPLAY": display,
                "XAUTHORITY": env.get("XAUTHORITY", ""),
                "XDG_RUNTIME_DIR": env.get("XDG_RUNTIME_DIR", ""),
            }
            best_src = f"/proc/{pid}/environ({comm or 'unknown'})"

    if not best_env:
        return {}, ""

    if not best_env.get("XAUTHORITY"):
        best_env["XAUTHORITY"] = guess_xauthority_path(preferred_user, best_env.get("XDG_RUNTIME_DIR", ""))
    return best_env, best_src


def autodetect_mouse_event(preferred_identity: Optional[Dict[str, str]] = None) -> Tuple[str, int]:
    candidates = enumerate_mouse_candidates()
    if not candidates:
        raise FileNotFoundError("No /dev/input/event* device found")
    best_path = ""
    best_score = -1
    for path, base_priority in candidates:
        score = base_priority
        if base_priority > EVENT_PRIORITY_FALLBACK:
            score += identity_match_score(read_event_identity(path), preferred_identity)
        if score > best_score:
            best_path = path
            best_score = score
    return best_path, best_score


def prefer_stable_event_path(path: str, stable_patterns: List[str]) -> Tuple[str, int]:
    if is_stable_event_path(path):
        return path, score_event_candidate(path)
    real_path = os.path.realpath(path)
    for pattern in stable_patterns:
        for candidate in sorted(glob.glob(pattern)):
            try:
                if os.path.realpath(candidate) == real_path:
                    return candidate, score_event_candidate(candidate)
            except OSError:
                continue
    return path, score_event_candidate(path)


def is_stable_event_path(path: str) -> bool:
    return path.startswith("/dev/input/by-id/") or path.startswith("/dev/input/by-path/")


def event_priority(path: str) -> int:
    if path.startswith("/dev/input/by-id/"):
        return EVENT_PRIORITY_BY_ID
    if path.startswith("/dev/input/by-path/"):
        return EVENT_PRIORITY_BY_PATH
    if path.startswith("/dev/input/event"):
        return EVENT_PRIORITY_HEURISTIC
    return EVENT_PRIORITY_FALLBACK


def score_event_candidate(path: str, preferred_identity: Optional[Dict[str, str]] = None) -> int:
    return event_priority(path) + identity_match_score(read_event_identity(path), preferred_identity)


def identity_match_score(candidate_identity: Dict[str, str], preferred_identity: Optional[Dict[str, str]]) -> int:
    if not preferred_identity:
        return 0
    score = 0
    if preferred_identity.get("name") and candidate_identity.get("name") == preferred_identity.get("name"):
        score += 120
    if preferred_identity.get("phys") and candidate_identity.get("phys") == preferred_identity.get("phys"):
        score += 80
    if preferred_identity.get("uniq") and candidate_identity.get("uniq") == preferred_identity.get("uniq"):
        score += 80
    for key in ("bustype", "vendor", "product", "version"):
        pref = preferred_identity.get(key, "")
        if pref and candidate_identity.get(key) == pref:
            score += 30
    return score


def read_event_identity(path: str) -> Dict[str, str]:
    real_path = os.path.realpath(path)
    event_name = os.path.basename(real_path)
    if not event_name.startswith("event"):
        return {}
    device_dir = f"/sys/class/input/{event_name}/device"
    return {
        "name": read_text_file(os.path.join(device_dir, "name")),
        "phys": read_text_file(os.path.join(device_dir, "phys")),
        "uniq": read_text_file(os.path.join(device_dir, "uniq")),
        "bustype": read_text_file(os.path.join(device_dir, "id", "bustype")),
        "vendor": read_text_file(os.path.join(device_dir, "id", "vendor")),
        "product": read_text_file(os.path.join(device_dir, "id", "product")),
        "version": read_text_file(os.path.join(device_dir, "id", "version")),
    }


def read_text_file(path: str) -> str:
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read().strip()
    except OSError:
        return ""


def enumerate_mouse_candidates(include_fallback: bool = True) -> List[Tuple[str, int]]:
    candidates: Dict[str, Tuple[str, int]] = {}

    def register(path: str, priority: int) -> None:
        try:
            key = os.path.realpath(path)
        except OSError:
            key = path
        existing = candidates.get(key)
        if existing is None or priority > existing[1]:
            candidates[key] = (path, priority)

    for path in sorted(glob.glob("/dev/input/by-id/*-event-mouse")):
        register(path, EVENT_PRIORITY_BY_ID)
    for path in sorted(glob.glob("/dev/input/by-path/*-event-mouse")):
        register(path, EVENT_PRIORITY_BY_PATH)
    for path in detect_mouse_candidates_from_proc_bus_input():
        register(prefer_stable_event_path(path, ["/dev/input/by-id/*-event-mouse", "/dev/input/by-path/*-event-mouse"])[0], EVENT_PRIORITY_HEURISTIC)
    if include_fallback and not candidates:
        for path in sorted(glob.glob("/dev/input/event*")):
            register(path, EVENT_PRIORITY_FALLBACK)
    return sorted(candidates.values(), key=lambda item: item[1], reverse=True)


def is_mouse_event_path(path: str) -> bool:
    if not path:
        return False
    real_path = os.path.realpath(path)
    primary_candidates = enumerate_mouse_candidates(include_fallback=False)
    if not primary_candidates:
        return os.path.exists(real_path)
    for candidate, _priority in primary_candidates:
        try:
            if os.path.realpath(candidate) == real_path:
                return True
        except OSError:
            continue
    return False


def autodetect_udc_state_path() -> Optional[str]:
    candidates = sorted(glob.glob("/sys/class/udc/*/state"))
    if len(candidates) == 1:
        return candidates[0]
    return None


def detect_mouse_candidates_from_proc_bus_input() -> List[str]:
    path = "/proc/bus/input/devices"
    if not os.path.exists(path):
        return []

    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        blocks = f.read().split("\n\n")

    candidates: List[str] = []
    for block in blocks:
        handlers_line = None
        for line in block.splitlines():
            if line.startswith("H: Handlers="):
                handlers_line = line
                break
        if not handlers_line:
            continue

        handlers = handlers_line.split("=", 1)[1].split()
        has_mouse = any(h.startswith("mouse") for h in handlers)
        event_handlers = [h for h in handlers if h.startswith("event")]
        if has_mouse and event_handlers:
            candidate = "/dev/input/" + event_handlers[0]
            if os.path.exists(candidate):
                candidates.append(candidate)

    return candidates


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="USB HID mouse sync service")
    parser.add_argument("--event", help="Input event device path (e.g. /dev/input/event3)")
    parser.add_argument("--hidg", default="/dev/hidg0", help="HID gadget device path")
    parser.add_argument("--move-scale", type=float, default=1.0, help="Mouse move scaling")
    parser.add_argument("--wheel-scale", type=float, default=1.0, help="Wheel scaling")
    parser.add_argument("--read-chunk-events", type=int, default=64, help="How many input_event records to read per syscall")
    parser.add_argument("--udc-state-path", default="", help="Optional path like /sys/class/udc/<name>/state")
    parser.add_argument("--hid-profile", default="extended5", choices=["extended5", "boot3"], help="HID report profile")
    parser.add_argument("--home-on-connect", action="store_true", default=True, help="Move cursor to top-left after HID connect")
    parser.add_argument("--no-home-on-connect", action="store_false", dest="home_on_connect", help="Disable connect-time homing")
    parser.add_argument("--home-steps", type=int, default=24, help="How many -127/-127 reports to send when homing")
    parser.add_argument("--start-bias-x", type=int, default=0, help="After homing, move right by this relative amount")
    parser.add_argument("--start-bias-y", type=int, default=0, help="After homing, move down by this relative amount")
    parser.add_argument("--mouse-mode", default="relative", choices=["relative", "absolute-map"], help="relative passthrough or absolute-map")
    parser.add_argument("--src-width", type=int, default=1920, help="Source desktop width for absolute-map")
    parser.add_argument("--src-height", type=int, default=1080, help="Source desktop height for absolute-map")
    parser.add_argument("--dst-width", type=int, default=1280, help="Target device width for absolute-map")
    parser.add_argument("--dst-height", type=int, default=720, help="Target device height for absolute-map")
    parser.add_argument("--dst-offset-x", type=int, default=0, help="Target active area X offset")
    parser.add_argument("--dst-offset-y", type=int, default=0, help="Target active area Y offset")
    parser.add_argument("--dst-active-width", type=int, default=0, help="Target active area width (0 means dst-width)")
    parser.add_argument("--dst-active-height", type=int, default=0, help="Target active area height (0 means dst-height)")
    parser.add_argument("--src-offset-x", type=int, default=0, help="Source X offset (for partial-screen mapping)")
    parser.add_argument("--src-offset-y", type=int, default=0, help="Source Y offset (for partial-screen mapping)")
    parser.add_argument("--use-cursor-query", action="store_true", default=True, help="Use xdotool cursor position in absolute-map mode")
    parser.add_argument("--no-cursor-query", action="store_false", dest="use_cursor_query", help="Disable cursor query; use rel integration")
    parser.add_argument("--cursor-query-cmd", default="xdotool", help="Command used for cursor query")
    parser.add_argument("--cursor-query-user", default="", help="Run cursor query command as this user (via runuser)")
    parser.add_argument("--cursor-display", default="", help="DISPLAY override for cursor query, e.g. :0")
    parser.add_argument("--cursor-xauthority", default="", help="XAUTHORITY override for cursor query")
    parser.add_argument("--cursor-xdg-runtime-dir", default="", help="XDG_RUNTIME_DIR override for cursor query")
    parser.add_argument("--cursor-timeout-ms", type=int, default=120, help="Cursor query timeout in milliseconds")
    parser.add_argument("--align-on-connect", action="store_true", default=True, help="Align target cursor to source cursor after HID connects")
    parser.add_argument("--no-align-on-connect", action="store_false", dest="align_on_connect", help="Disable connect-time alignment")
    parser.add_argument("--connect-settle-ms", type=int, default=DEFAULT_CONNECT_SETTLE_MS, help="Wait after opening /dev/hidg0 before first reports")
    parser.add_argument("--home-rounds", type=int, default=2, help="How many homing rounds to send on connect")
    parser.add_argument("--align-retries", type=int, default=DEFAULT_ALIGN_RETRIES, help="How many times to retry source cursor query during connect align")
    parser.add_argument("--align-retry-interval-ms", type=int, default=DEFAULT_ALIGN_RETRY_INTERVAL_MS, help="Retry interval for connect align")
    parser.add_argument("--align-step-max", type=int, default=DEFAULT_ALIGN_STEP_MAX, help="Max per-report movement used during connect align")
    parser.add_argument("--align-step-sleep-ms", type=int, default=DEFAULT_ALIGN_STEP_SLEEP_MS, help="Sleep between connect-align reports")
    parser.add_argument("--source-home-on-connect", action="store_true", default=False, help="Move source desktop cursor to (0,0) on connect before align")
    parser.add_argument("--strict-absolute-query", action="store_true", default=True, help="In absolute-map mode, drop movement when cursor query fails")
    parser.add_argument("--no-strict-absolute-query", action="store_false", dest="strict_absolute_query", help="Allow relative fallback when cursor query fails")
    parser.add_argument("--auto-rebind-event", action="store_true", default=True, help="Auto detect new event node on mouse unplug/replug")
    parser.add_argument("--no-auto-rebind-event", action="store_false", dest="auto_rebind_event", help="Disable event auto rebind")
    parser.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(levelname)s %(message)s",
    )

    if args.event:
        event_path, _ = prefer_stable_event_path(
            args.event,
            ["/dev/input/by-id/*-event-mouse", "/dev/input/by-path/*-event-mouse"],
        )
    else:
        event_path, _ = autodetect_mouse_event()
    logging.info("Using input device: %s", event_path)

    udc_state_path = args.udc_state_path or autodetect_udc_state_path()
    if udc_state_path:
        logging.info("Using UDC state path: %s", udc_state_path)
    logging.info("Using HID profile: %s", args.hid_profile)
    logging.info(
        "Homing: enabled=%s steps=%d bias=(%d,%d)",
        args.home_on_connect,
        args.home_steps,
        args.start_bias_x,
        args.start_bias_y,
    )
    logging.info(
        "Mouse mode: %s src=%dx%d@(%d,%d) dst=%dx%d active=%dx%d@(%d,%d) auto_rebind_event=%s cursor_query=%s",
        args.mouse_mode,
        args.src_width,
        args.src_height,
        args.src_offset_x,
        args.src_offset_y,
        args.dst_width,
        args.dst_height,
        args.dst_active_width or args.dst_width,
        args.dst_active_height or args.dst_height,
        args.dst_offset_x,
        args.dst_offset_y,
        args.auto_rebind_event,
        args.use_cursor_query,
    )
    if args.use_cursor_query:
        logging.info(
            "Cursor query cfg: cmd=%s user=%s display=%s xauthority=%s xdg_runtime_dir=%s timeout_ms=%d",
            args.cursor_query_cmd,
            args.cursor_query_user or "-",
            args.cursor_display or "-",
            args.cursor_xauthority or "-",
            args.cursor_xdg_runtime_dir or "-",
            args.cursor_timeout_ms,
        )
    logging.info(
        "Connect align: enabled=%s settle_ms=%d home_rounds=%d retries=%d retry_interval_ms=%d step_max=%d step_sleep_ms=%d source_home=%s strict_abs=%s",
        args.align_on_connect,
        args.connect_settle_ms,
        args.home_rounds,
        args.align_retries,
        args.align_retry_interval_ms,
        args.align_step_max,
        args.align_step_sleep_ms,
        args.source_home_on_connect,
        args.strict_absolute_query,
    )

    svc = MouseSyncService(
        event_path=event_path,
        hidg_path=args.hidg,
        move_scale=args.move_scale,
        wheel_scale=args.wheel_scale,
        read_chunk_events=args.read_chunk_events,
        udc_state_path=udc_state_path,
        hid_profile=args.hid_profile,
        home_on_connect=args.home_on_connect,
        home_steps=args.home_steps,
        start_bias_x=args.start_bias_x,
        start_bias_y=args.start_bias_y,
        mouse_mode=args.mouse_mode,
        src_width=args.src_width,
        src_height=args.src_height,
        dst_width=args.dst_width,
        dst_height=args.dst_height,
        autodetect_event=args.auto_rebind_event,
        src_offset_x=args.src_offset_x,
        src_offset_y=args.src_offset_y,
        dst_offset_x=args.dst_offset_x,
        dst_offset_y=args.dst_offset_y,
        dst_active_width=args.dst_active_width,
        dst_active_height=args.dst_active_height,
        use_cursor_query=args.use_cursor_query,
        cursor_query_cmd=args.cursor_query_cmd,
        cursor_query_user=args.cursor_query_user,
        cursor_display=args.cursor_display,
        cursor_xauthority=args.cursor_xauthority,
        cursor_xdg_runtime_dir=args.cursor_xdg_runtime_dir,
        cursor_timeout_ms=args.cursor_timeout_ms,
        align_on_connect=args.align_on_connect,
        connect_settle_ms=args.connect_settle_ms,
        home_rounds=args.home_rounds,
        align_retries=args.align_retries,
        align_retry_interval_ms=args.align_retry_interval_ms,
        align_step_max=args.align_step_max,
        align_step_sleep_ms=args.align_step_sleep_ms,
        source_home_on_connect=args.source_home_on_connect,
        strict_absolute_query=args.strict_absolute_query,
    )
    if args.use_cursor_query:
        logging.info(
            "Cursor query env: source=%s values=%s",
            svc.cursor_query_env_source or "unknown",
            svc._short_cursor_env(),
        )

    signal.signal(signal.SIGTERM, lambda _s, _f: svc.stop())
    signal.signal(signal.SIGINT, lambda _s, _f: svc.stop())

    svc.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
