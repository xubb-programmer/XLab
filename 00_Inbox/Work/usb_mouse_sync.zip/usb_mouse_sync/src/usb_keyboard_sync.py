#!/usr/bin/env python3
"""Mirror Linux keyboard input (/dev/input/eventX) to USB HID keyboard gadget (/dev/hidg1)."""

import argparse
import errno
import glob
import logging
import os
import select
import signal
import struct
import time
from typing import Callable, Dict, List, Optional, Set, Tuple

from usb_hid_actions import HidOutputLock

EV_SYN = 0x00
EV_KEY = 0x01
SYN_REPORT = 0

INPUT_EVENT = struct.Struct("llHHi")
EVENT_PRIORITY_BY_ID = 300
EVENT_PRIORITY_BY_PATH = 200
EVENT_PRIORITY_HEURISTIC = 100
EVENT_PRIORITY_FALLBACK = 10

HID_TRANSIENT_ERRNOS = {
    errno.ESHUTDOWN,
    errno.EPIPE,
    errno.ENOTCONN,
    errno.ENODEV,
    errno.ECONNRESET,
    errno.ECONNABORTED,
}

# Linux input key code -> HID usage
MODIFIER_MAP: Dict[int, int] = {
    29: 0x01,   # KEY_LEFTCTRL
    42: 0x02,   # KEY_LEFTSHIFT
    56: 0x04,   # KEY_LEFTALT
    125: 0x08,  # KEY_LEFTMETA
    97: 0x10,   # KEY_RIGHTCTRL
    54: 0x20,   # KEY_RIGHTSHIFT
    100: 0x40,  # KEY_RIGHTALT
    126: 0x80,  # KEY_RIGHTMETA
}

KEY_MAP: Dict[int, int] = {
    2: 0x1E, 3: 0x1F, 4: 0x20, 5: 0x21, 6: 0x22, 7: 0x23, 8: 0x24, 9: 0x25, 10: 0x26, 11: 0x27,
    12: 0x2D, 13: 0x2E, 14: 0x2A, 15: 0x2B, 16: 0x14, 17: 0x1A, 18: 0x08, 19: 0x15, 20: 0x17,
    21: 0x1C, 22: 0x18, 23: 0x0C, 24: 0x12, 25: 0x13, 26: 0x2F, 27: 0x30, 28: 0x28, 30: 0x04,
    31: 0x16, 32: 0x07, 33: 0x09, 34: 0x0A, 35: 0x0B, 36: 0x0D, 37: 0x0E, 38: 0x0F, 39: 0x33,
    40: 0x34, 41: 0x35, 43: 0x31, 44: 0x1D, 45: 0x1B, 46: 0x06, 47: 0x19, 48: 0x05, 49: 0x11,
    50: 0x10, 51: 0x36, 52: 0x37, 53: 0x38, 57: 0x2C, 58: 0x39, 59: 0x3A, 60: 0x3B, 61: 0x3C,
    62: 0x3D, 63: 0x3E, 64: 0x3F, 65: 0x40, 66: 0x41, 67: 0x42, 68: 0x43, 69: 0x53, 70: 0x47,
    71: 0x5F, 72: 0x60, 73: 0x61, 74: 0x56, 75: 0x5C, 76: 0x5D, 77: 0x5E, 78: 0x57, 79: 0x59,
    80: 0x5A, 81: 0x5B, 82: 0x62, 83: 0x63, 86: 0x64, 87: 0x44, 88: 0x45, 96: 0x58, 98: 0x54,
    99: 0x46, 102: 0x4A, 103: 0x52, 104: 0x4B, 105: 0x50, 106: 0x4D, 107: 0x4F, 108: 0x51,
    109: 0x4E, 110: 0x49, 111: 0x4C, 117: 0x48, 119: 0x7F, 127: 0x65,
}


def autodetect_keyboard_event() -> str:
    # Prefer by-path/by-id entries that look like keyboards.
    for p in sorted(glob.glob("/dev/input/by-id/*-event-kbd")):
        return p
    for p in sorted(glob.glob("/dev/input/by-path/*-event-kbd")):
        return p

    path = "/proc/bus/input/devices"
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            blocks = f.read().split("\n\n")
        for block in blocks:
            lines = block.splitlines()
            handlers = ""
            key_line = ""
            for line in lines:
                if line.startswith("H: Handlers="):
                    handlers = line
                elif line.startswith("B: KEY="):
                    key_line = line
            if not handlers:
                continue
            hs = handlers.split("=", 1)[1].split()
            ev = next((h for h in hs if h.startswith("event")), "")
            if not ev:
                continue
            # Heuristic: has kbd handler and key capability line.
            if "kbd" in hs and key_line:
                candidate = f"/dev/input/{ev}"
                if os.path.exists(candidate):
                    stable, _ = prefer_stable_event_path(
                        candidate,
                        ["/dev/input/by-id/*-event-kbd", "/dev/input/by-path/*-event-kbd"],
                    )
                    return stable

    for p in sorted(glob.glob("/dev/input/event*")):
        return p
    raise FileNotFoundError("No keyboard event device found")


def prefer_stable_event_path(path: str, stable_patterns: List[str]) -> Tuple[str, int]:
    if is_stable_event_path(path):
        return path, event_priority(path)
    real_path = os.path.realpath(path)
    for pattern in stable_patterns:
        for candidate in sorted(glob.glob(pattern)):
            try:
                if os.path.realpath(candidate) == real_path:
                    return candidate, event_priority(candidate)
            except OSError:
                continue
    return path, EVENT_PRIORITY_HEURISTIC


def is_stable_event_path(path: str) -> bool:
    return path.startswith("/dev/input/by-id/") or path.startswith("/dev/input/by-path/")


def event_priority(path: str) -> int:
    if path.startswith("/dev/input/by-id/"):
        return EVENT_PRIORITY_BY_ID
    if path.startswith("/dev/input/by-path/"):
        return EVENT_PRIORITY_BY_PATH
    if path.startswith("/dev/input/event"):
        return EVENT_PRIORITY_HEURISTIC
    return EVENT_PRIORITY_FALLBACK


class KeyboardSyncService:
    def __init__(
        self,
        event_path: str,
        hidg_path: str,
        auto_rebind_event: bool = True,
        udc_state_path: str = "",
        enable_hid_output: bool = True,
        report_callback: Optional[Callable[[bytes], None]] = None,
    ) -> None:
        self.event_path = event_path
        self.event_priority = event_priority(event_path)
        self.hidg_path = hidg_path
        self.auto_rebind_event = auto_rebind_event
        self.udc_state_path = udc_state_path
        self.enable_hid_output = enable_hid_output
        self.report_callback = report_callback
        self.event_fd: Optional[int] = None
        self.hidg_fd: Optional[int] = None
        self.running = True
        self.modifiers = 0
        self.keys: Set[int] = set()
        self.last_event_open_log = 0.0
        self.last_link_down_log = 0.0
        self.last_event_drop_log = 0.0

    def stop(self) -> None:
        self.running = False

    def run(self) -> None:
        while self.running:
            try:
                self._maybe_close_event_on_source_drop()
                self._maybe_reopen_event_on_source_change()
                self._maybe_close_hidg_on_link_down()
                if not self._ensure_open():
                    time.sleep(0.3)
                    continue
                if self.auto_rebind_event:
                    self._maybe_switch_event_device()
                    if self.event_fd is None:
                        time.sleep(0.05)
                        continue
                ready, _, _ = select.select([self.event_fd], [], [], 1.0)
                if not ready:
                    self._maybe_close_event_on_source_drop()
                    self._maybe_reopen_event_on_source_change()
                    self._maybe_close_hidg_on_link_down()
                    continue
                raw = os.read(self.event_fd, INPUT_EVENT.size * 64)
                if not raw:
                    raise OSError(errno.ENODEV, "input device disconnected")
                usable = (len(raw) // INPUT_EVENT.size) * INPUT_EVENT.size
                for off in range(0, usable, INPUT_EVENT.size):
                    _, _, ev_type, code, value = INPUT_EVENT.unpack_from(raw, off)
                    self._handle_event(ev_type, code, value)
            except OSError as exc:
                if exc.errno in HID_TRANSIENT_ERRNOS:
                    self._close_hidg_fd()
                    time.sleep(0.1)
                    continue
                if exc.errno in {errno.ENODEV, errno.ENXIO, errno.EIO, errno.EBADF}:
                    logging.warning("Keyboard input dropped (%s), reopen", exc)
                    self._clear_input_state()
                    self._close_event_fd()
                    if self.auto_rebind_event:
                        self._maybe_switch_event_device()
                    time.sleep(0.2)
                    continue
                logging.warning("Keyboard I/O error (%s), reopen", exc)
                self._close_fds()
                time.sleep(0.3)
            except BlockingIOError:
                time.sleep(0.01)
            except InterruptedError:
                continue
            except Exception as exc:
                logging.warning("Keyboard service exception (%s), reopen", exc)
                self._close_fds()
                time.sleep(0.3)

        self._close_fds()

    def _ensure_open(self) -> bool:
        if self.event_fd is None:
            if self.auto_rebind_event:
                self._maybe_switch_event_device()
            try:
                self.event_fd = os.open(self.event_path, os.O_RDONLY | os.O_CLOEXEC | os.O_NONBLOCK)
                logging.info("Opened keyboard input device: %s", self.event_path)
            except FileNotFoundError:
                self._throttled_event_missing("Keyboard input missing: %s", self.event_path)
                return False
            except PermissionError:
                logging.error("Permission denied for keyboard input: %s", self.event_path)
                return False

        if self.enable_hid_output and self.hidg_fd is None:
            if not self._udc_ready_for_io():
                return False
            try:
                self.hidg_fd = os.open(self.hidg_path, os.O_RDWR | os.O_CLOEXEC | os.O_NONBLOCK)
                logging.info("Opened keyboard HID gadget: %s", self.hidg_path)
                self._write_report()
            except FileNotFoundError:
                logging.warning("Keyboard HID gadget missing: %s", self.hidg_path)
                return False
            except PermissionError:
                logging.error("Permission denied for keyboard HID gadget: %s", self.hidg_path)
                return False
        return True

    def _throttled_event_missing(self, fmt: str, *args) -> None:
        now = time.time()
        if now - self.last_event_open_log < 2.0:
            return
        self.last_event_open_log = now
        logging.warning(fmt, *args)

    def _maybe_switch_event_device(self) -> None:
        try:
            new_event = autodetect_keyboard_event()
        except FileNotFoundError:
            return
        new_path, new_priority = prefer_stable_event_path(
            new_event,
            ["/dev/input/by-id/*-event-kbd", "/dev/input/by-path/*-event-kbd"],
        )
        current_available = os.path.exists(self.event_path)
        should_switch = False
        if new_path == self.event_path:
            self.event_priority = new_priority
            return
        if not current_available:
            should_switch = new_priority >= self.event_priority
        elif new_priority > self.event_priority:
            should_switch = True
        if should_switch:
            logging.info("Switch keyboard input: %s -> %s", self.event_path, new_path)
            self.event_path = new_path
            self.event_priority = new_priority
            self._clear_input_state()
            self._close_event_fd()

    def _udc_ready_for_io(self) -> bool:
        state = self._read_udc_state()
        return not state or state == "configured"

    def _read_udc_state(self) -> str:
        if not self.udc_state_path:
            return ""
        try:
            with open(self.udc_state_path, "r", encoding="utf-8", errors="ignore") as f:
                return f.read().strip().lower()
        except FileNotFoundError:
            return ""
        except OSError:
            return ""

    def _maybe_close_hidg_on_link_down(self) -> None:
        if self.hidg_fd is None:
            return
        state = self._read_udc_state()
        if state and state != "configured":
            self._log_link_down_state(state)
            self._close_hidg_fd()

    def _maybe_close_event_on_source_drop(self) -> None:
        if self.event_fd is None:
            return
        if not is_stable_event_path(self.event_path):
            return
        if os.path.exists(self.event_path):
            return
        self._throttled_event_drop_log("Keyboard source disappeared: %s", self.event_path)
        self._clear_input_state()
        self._close_event_fd()

    def _maybe_reopen_event_on_source_change(self) -> None:
        if self.event_fd is None:
            return
        if not is_stable_event_path(self.event_path):
            return
        try:
            current_target = os.path.realpath(self.event_path)
            current_stat = os.stat(current_target)
            fd_stat = os.fstat(self.event_fd)
        except FileNotFoundError:
            return
        except OSError:
            return
        if fd_stat.st_ino == current_stat.st_ino and fd_stat.st_dev == current_stat.st_dev:
            return
        self._throttled_event_drop_log(
            "Keyboard source changed behind stable path: %s -> %s, reopen",
            self.event_path,
            current_target,
        )
        self._clear_input_state()
        self._close_event_fd()

    def _close_event_fd(self) -> None:
        if self.event_fd is not None:
            os.close(self.event_fd)
            self.event_fd = None

    def _close_hidg_fd(self) -> None:
        if self.hidg_fd is not None:
            os.close(self.hidg_fd)
            self.hidg_fd = None

    def _close_fds(self) -> None:
        self._close_event_fd()
        self._close_hidg_fd()

    def _clear_input_state(self) -> None:
        self.modifiers = 0
        self.keys.clear()
        if self.hidg_fd is None and self.report_callback is None:
            return
        try:
            self._write_report()
        except OSError:
            if self.enable_hid_output:
                self._close_hidg_fd()

    def _handle_event(self, ev_type: int, code: int, value: int) -> None:
        if ev_type != EV_KEY:
            return

        if code in MODIFIER_MAP:
            bit = MODIFIER_MAP[code]
            if value:
                self.modifiers |= bit
            else:
                self.modifiers &= ~bit
            self._write_report()
            return

        hid_key = KEY_MAP.get(code)
        if hid_key is None:
            return
        if value:  # press or autorepeat
            if len(self.keys) < 6 or hid_key in self.keys:
                self.keys.add(hid_key)
        else:
            self.keys.discard(hid_key)
        self._write_report()

    def _write_report(self) -> None:
        key_list = sorted(self.keys)[:6]
        while len(key_list) < 6:
            key_list.append(0)
        report = bytes([self.modifiers & 0xFF, 0] + key_list)
        if self.report_callback is not None:
            self.report_callback(report)
        if not self.enable_hid_output or self.hidg_fd is None:
            return
        try:
            with HidOutputLock(os.environ.get("HID_LOCK_PATH", "/run/lock/usb-mouse-sync-hid.lock")):
                os.write(self.hidg_fd, report)
        except BlockingIOError:
            return
        except OSError as exc:
            if exc.errno in {errno.EAGAIN, errno.EWOULDBLOCK}:
                return
            raise

    def _log_link_down_state(self, state: str) -> None:
        now = time.time()
        if now - self.last_link_down_log < 3.0:
            return
        self.last_link_down_log = now
        logging.warning("USB link not configured, closing keyboard HID fd (udc_state=%s)", state)

    def _throttled_event_drop_log(self, fmt: str, *args) -> None:
        now = time.time()
        if now - self.last_event_drop_log < 2.0:
            return
        self.last_event_drop_log = now
        logging.warning(fmt, *args)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="USB HID keyboard sync service")
    p.add_argument("--event", default="", help="Keyboard input event path")
    p.add_argument("--hidg", default="/dev/hidg1", help="Keyboard HID gadget path")
    p.add_argument("--udc-state-path", default="", help="Optional path like /sys/class/udc/<name>/state")
    p.add_argument("--auto-rebind-event", action="store_true", default=True)
    p.add_argument("--no-auto-rebind-event", action="store_false", dest="auto_rebind_event")
    p.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    return p.parse_args()


def main() -> int:
    args = parse_args()
    logging.basicConfig(level=getattr(logging, args.log_level), format="%(asctime)s %(levelname)s %(message)s")
    if args.event:
        event_path, _ = prefer_stable_event_path(
            args.event,
            ["/dev/input/by-id/*-event-kbd", "/dev/input/by-path/*-event-kbd"],
        )
    else:
        event_path = autodetect_keyboard_event()
    logging.info("Using keyboard input device: %s", event_path)
    if args.udc_state_path:
        logging.info("Using keyboard UDC state path: %s", args.udc_state_path)
    svc = KeyboardSyncService(
        event_path,
        args.hidg,
        auto_rebind_event=args.auto_rebind_event,
        udc_state_path=args.udc_state_path,
    )
    signal.signal(signal.SIGTERM, lambda _s, _f: svc.stop())
    signal.signal(signal.SIGINT, lambda _s, _f: svc.stop())
    svc.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
