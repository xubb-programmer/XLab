#!/usr/bin/env bash
set -euo pipefail

PREFIX="${PREFIX:-/opt/usb-mouse-sync}"
SRC_DIR="$(cd "$(dirname "$0")/.." && pwd)"

if [[ $EUID -ne 0 ]]; then
  echo "[ERROR] Run as root" >&2
  exit 1
fi

mkdir -p "$PREFIX"
mkdir -p "$PREFIX/scripts" "$PREFIX/src"

cp "$SRC_DIR/src/usb_mouse_sync.py" "$PREFIX/src/"
cp "$SRC_DIR/src/usb_keyboard_sync.py" "$PREFIX/src/"
cp "$SRC_DIR/src/usb_input_bridge.py" "$PREFIX/src/"
cp "$SRC_DIR/src/usb_mouse_sync_api.py" "$PREFIX/src/"
cp "$SRC_DIR/src/usb_hid_actions.py" "$PREFIX/src/"
cp "$SRC_DIR/scripts/setup_usb_mouse_gadget.sh" "$PREFIX/scripts/"
cp "$SRC_DIR/scripts/teardown_usb_mouse_gadget.sh" "$PREFIX/scripts/"
cp "$SRC_DIR/scripts/restore_otg_host_mode.sh" "$PREFIX/scripts/"
cp "$SRC_DIR/scripts/start_usb_input_bridge.sh" "$PREFIX/scripts/"
cp "$SRC_DIR/scripts/check_usb_mouse_sync_health.sh" "$PREFIX/scripts/"

chmod +x "$PREFIX/src/usb_mouse_sync.py"
chmod +x "$PREFIX/src/usb_keyboard_sync.py"
chmod +x "$PREFIX/src/usb_input_bridge.py"
chmod +x "$PREFIX/src/usb_mouse_sync_api.py"
chmod +x "$PREFIX/src/usb_hid_actions.py"
chmod +x "$PREFIX/scripts/setup_usb_mouse_gadget.sh" "$PREFIX/scripts/teardown_usb_mouse_gadget.sh" "$PREFIX/scripts/restore_otg_host_mode.sh" "$PREFIX/scripts/start_usb_input_bridge.sh" "$PREFIX/scripts/check_usb_mouse_sync_health.sh"

install -m 0644 "$SRC_DIR/systemd/usb-mouse-sync.service" /etc/systemd/system/usb-mouse-sync.service
install -m 0644 "$SRC_DIR/systemd/usb-mouse-sync-api.service" /etc/systemd/system/usb-mouse-sync-api.service
install -m 0644 "$SRC_DIR/systemd/usb-mouse-sync-healthcheck.service" /etc/systemd/system/usb-mouse-sync-healthcheck.service
install -m 0644 "$SRC_DIR/systemd/usb-mouse-sync-healthcheck.timer" /etc/systemd/system/usb-mouse-sync-healthcheck.timer

rm -f "$PREFIX/scripts/start_usb_mouse_sync.sh" "$PREFIX/scripts/start_usb_keyboard_sync.sh"
systemctl disable --now usb-mouse-gadget.service usb-keyboard-sync.service 2>/dev/null || true
systemctl disable --now usb-mouse-sync-boot-restart.timer 2>/dev/null || true
rm -f /etc/systemd/system/usb-mouse-gadget.service /etc/systemd/system/usb-keyboard-sync.service
rm -f /etc/systemd/system/usb-mouse-sync-boot-restart.service /etc/systemd/system/usb-mouse-sync-boot-restart.timer

if [[ ! -f /etc/default/usb-mouse-sync ]]; then
  install -m 0666 "$SRC_DIR/config/usb-mouse-sync.env.example" /etc/default/usb-mouse-sync
fi
if [[ ! -f /etc/default/usb-mouse-sync-api ]]; then
  install -m 0644 "$SRC_DIR/config/usb-mouse-sync-api.env.example" /etc/default/usb-mouse-sync-api
fi
mkdir -p /etc/usb-mouse-sync
if [[ ! -f /etc/usb-mouse-sync/actions.json ]]; then
  install -m 0644 "$SRC_DIR/config/actions.json.example" /etc/usb-mouse-sync/actions.json
fi

systemctl daemon-reload
systemctl enable --now usb-mouse-sync.service usb-mouse-sync-api.service
systemctl enable --now usb-mouse-sync-healthcheck.timer

echo "[OK] Installed to $PREFIX"
echo "[OK] Services enabled for boot and started:"
systemctl --no-pager --full --plain status usb-mouse-sync.service usb-mouse-sync-api.service usb-mouse-sync-healthcheck.timer || true
echo "[NEXT] If you edit /etc/default/usb-mouse-sync, restart the services:"
echo "       systemctl restart usb-mouse-sync.service usb-mouse-sync-api.service"
