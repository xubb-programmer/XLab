#!/usr/bin/env bash
set -euo pipefail

GADGET_NAME="${GADGET_NAME:-g1}"
GADGET_DIR="/sys/kernel/config/usb_gadget/${GADGET_NAME}"
DEBUG_MODE_PATH="/sys/kernel/debug/usb/fc000000.usb/mode"
SKIP_STOP_SERVICES=0
ROLE_SWITCH_CANDIDATES=(
  "/sys/devices/platform/fd5d0000.syscon/fd5d0000.syscon:usb2-phy@0/otg_mode"
)

if [[ "${1:-}" == "--no-stop" ]]; then
  SKIP_STOP_SERVICES=1
fi

if [[ $EUID -ne 0 ]]; then
  echo "[ERROR] Run as root" >&2
  exit 1
fi

show_runtime_hint() {
  if [[ -f "${DEBUG_MODE_PATH}" ]]; then
    echo "[INFO] ${DEBUG_MODE_PATH}=$(cat "${DEBUG_MODE_PATH}" 2>/dev/null || true)"
  fi

  for path in "${ROLE_SWITCH_CANDIDATES[@]}"; do
    [[ -f "${path}" ]] || continue
    echo "[INFO] ${path}=$(cat "${path}" 2>/dev/null || true)"
  done

  if [[ -d /sys/class/udc ]]; then
    echo "[INFO] UDC list: $(ls /sys/class/udc 2>/dev/null | tr '\n' ' ')"
  fi
  if [[ -e /sys/bus/platform/drivers/xhci-hcd/fc000000.usb ]]; then
    echo "[INFO] fc000000.usb is bound to xhci-hcd"
  fi
}

stop_gadget_services() {
  if [[ "${SKIP_STOP_SERVICES}" == "1" ]]; then
    return
  fi
  echo "[STEP] Stop USB gadget services..."
  systemctl stop usb-mouse-sync.service 2>/dev/null || true
  systemctl stop usb-keyboard-sync.service 2>/dev/null || true
  systemctl stop usb-mouse-gadget.service 2>/dev/null || true
}

teardown_gadget() {
  if [[ -x "$(cd "$(dirname "$0")" && pwd)/teardown_usb_mouse_gadget.sh" ]]; then
    echo "[STEP] Teardown HID gadget..."
    "$(cd "$(dirname "$0")" && pwd)/teardown_usb_mouse_gadget.sh" || true
    return
  fi

  if [[ -f "${GADGET_DIR}/UDC" ]]; then
    echo "" > "${GADGET_DIR}/UDC" || true
  fi
}

ensure_debugfs() {
  if ! mountpoint -q /sys/kernel/debug; then
    mount -t debugfs none /sys/kernel/debug 2>/dev/null || true
  fi
}

force_host_role() {
  local changed=0
  local path

  ensure_debugfs

  if [[ -w "${DEBUG_MODE_PATH}" ]]; then
    if echo host > "${DEBUG_MODE_PATH}" 2>/dev/null; then
      echo "[INFO] Forced USB role by ${DEBUG_MODE_PATH}=host"
      changed=1
    fi
  fi

  for path in "${ROLE_SWITCH_CANDIDATES[@]}"; do
    [[ -w "${path}" ]] || continue
    if echo host > "${path}" 2>/dev/null; then
      echo "[INFO] Forced USB role by ${path}=host"
      changed=1
      continue
    fi
    if echo otg > "${path}" 2>/dev/null; then
      echo "[INFO] Forced USB role by ${path}=otg"
      changed=1
      continue
    fi
  done

  if [[ ${changed} -eq 0 ]]; then
    echo "[WARN] No writable host-role switch node found; board may need replug or reboot"
  fi
}

wait_for_host_mode() {
  local timeout_s="${1:-8}"
  local end_ts=$(( $(date +%s) + timeout_s ))

  while (( $(date +%s) <= end_ts )); do
    if [[ -e /sys/bus/platform/drivers/xhci-hcd/fc000000.usb ]]; then
      return 0
    fi
    sleep 1
  done
  return 1
}

stop_gadget_services
teardown_gadget
force_host_role

echo "[STEP] Wait for OTG port to return to host mode..."
if wait_for_host_mode 8; then
  echo "[OK] OTG port switched back to host mode"
else
  echo "[WARN] Host mode not confirmed within timeout"
fi

show_runtime_hint
echo "[DONE] You can now unplug the Android cable and connect a USB mouse/keyboard to the OTG port."
