#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'EOF'
Usage: deploy_local_board.sh [options]

Local RK3588 deployment helper.
Must run as root.

Options:
  --config <mode>   current | example | keep (default: keep)
  --skip-deps       Skip apt dependency installation
  -h, --help        Show this help
EOF
}

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
  usage
  exit 0
fi

if [[ $EUID -ne 0 ]]; then
  echo "[ERROR] Run as root" >&2
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

CONFIG_MODE="keep"
SKIP_DEPS=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --config)
      CONFIG_MODE="${2:-}"
      shift 2
      ;;
    --skip-deps)
      SKIP_DEPS=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "[ERROR] Unknown arg: $1" >&2
      usage
      exit 1
      ;;
  esac
done

case "$CONFIG_MODE" in
  current|example|keep) ;;
  *)
    echo "[ERROR] --config must be one of: current | example | keep" >&2
    exit 1
    ;;
esac

echo "[STEP] Running one-click installer..."
echo "[INFO] UDC reclaim policy: RECLAIM_UDC=${RECLAIM_UDC:-1}"
if [[ $SKIP_DEPS -eq 1 ]]; then
  "$ROOT_DIR/scripts/one_click_setup.sh" --config "$CONFIG_MODE" --skip-deps
else
  "$ROOT_DIR/scripts/one_click_setup.sh" --config "$CONFIG_MODE"
fi

echo "[STEP] Service status:"
systemctl status usb-mouse-sync.service usb-mouse-sync-api.service usb-mouse-sync-healthcheck.timer --no-pager || true

echo "[STEP] Last logs:"
journalctl -u usb-mouse-sync.service -u usb-mouse-sync-api.service -u usb-mouse-sync-healthcheck.service -n 120 --no-pager -l || true

echo "[STEP] Runtime device checks:"
ls -l /dev/hidg0 2>/dev/null || echo "[WARN] /dev/hidg0 missing"
ls -l /dev/hidg1 2>/dev/null || echo "[WARN] /dev/hidg1 missing (keyboard may be disabled)"
if [[ -f /sys/class/udc/fc000000.usb/state ]]; then
  echo "[INFO] /sys/class/udc/fc000000.usb/state=$(cat /sys/class/udc/fc000000.usb/state)"
else
  echo "[WARN] /sys/class/udc/fc000000.usb/state missing"
fi

echo "[DONE] Local board deployment flow finished."
