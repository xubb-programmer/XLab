#!/usr/bin/env bash
set -euo pipefail

pass() { echo "[PASS] $*"; }
warn() { echo "[WARN] $*"; }
fail() { echo "[FAIL] $*"; }

has_pattern() {
  local pattern="$1"
  local file="$2"
  if command -v rg >/dev/null 2>&1; then
    rg -q "$pattern" "$file"
  else
    grep -qE "$pattern" "$file"
  fi
}

echo "== Basic =="
uname -a || true
cat /proc/device-tree/model 2>/dev/null | tr -d '\0' || true
echo

echo "== Device tree dr_mode =="
for f in \
  /sys/firmware/devicetree/base/usbdrd3_0/usb@fc000000/dr_mode \
  /sys/firmware/devicetree/base/usbdrd3_1/usb@fc400000/dr_mode; do
  if [[ -f "$f" ]]; then
    mode="$(cat "$f" | tr -d '\0')"
    echo "$(basename "$(dirname "$f")") : $mode"
  fi
done

echo "== Kernel config =="
if zcat /proc/config.gz >/tmp/.usb_mouse_cfg.$$ 2>/dev/null; then
  cfg=/tmp/.usb_mouse_cfg.$$
elif [[ -f /boot/config-$(uname -r) ]]; then
  cfg=/boot/config-$(uname -r)
else
  cfg=""
fi

if [[ -n "$cfg" ]]; then
  for k in CONFIG_USB_GADGET CONFIG_USB_LIBCOMPOSITE CONFIG_USB_CONFIGFS CONFIG_USB_F_HID CONFIG_USB_DWC3_DUAL_ROLE; do
    if has_pattern "^${k}=y" "$cfg"; then
      pass "$k=y"
    else
      fail "$k is not enabled"
    fi
  done
else
  warn "cannot read kernel config"
fi
rm -f /tmp/.usb_mouse_cfg.$$ 2>/dev/null || true

echo "== Runtime status =="
if mount | grep -qE ' on /sys/kernel/config type configfs '; then
  pass "configfs mounted"
else
  warn "configfs not mounted"
fi

if [[ -d /sys/class/udc ]]; then
  udc_list="$(ls /sys/class/udc 2>/dev/null || true)"
  if [[ -n "$udc_list" ]]; then
    pass "UDC found: $(echo "$udc_list" | tr '\n' ' ')"
  else
    warn "No UDC in /sys/class/udc (possibly host mode now)"
  fi
else
  fail "/sys/class/udc missing"
fi

if [[ -e /sys/bus/platform/drivers/xhci-hcd/fc000000.usb ]]; then
  warn "fc000000.usb currently bound to xhci-hcd (host mode)"
fi

echo "== Summary hint =="
echo "If kernel checks PASS and dr_mode=otg exists, board supports USB HID gadget in principle."
echo "Runtime No UDC usually means role/cable/port state not in peripheral at this moment."
