#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'EOF'
Usage: one_click_setup.sh [options]

One-click installer for a new board.
Must run as root.

Options:
  --prefix <dir>         Install prefix, default: /opt/usb-mouse-sync
  --config <mode>        Config mode: current | example | keep
                         default: keep
  --skip-deps            Skip apt dependency installation
  --skip-check           Skip hardware support check script
  --no-start             Do not restart services after install
  -h, --help             Show this help
EOF
}

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
  usage
  exit 0
fi

if [[ $EUID -ne 0 ]]; then
  echo "[ERROR] Run as root" >&2
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

PREFIX="/opt/usb-mouse-sync"
CONFIG_MODE="keep"
DO_DEPS=1
DO_CHECK=1
DO_START=1

while [[ $# -gt 0 ]]; do
  case "$1" in
    --prefix)
      PREFIX="${2:-}"
      shift 2
      ;;
    --config)
      CONFIG_MODE="${2:-}"
      shift 2
      ;;
    --skip-deps)
      DO_DEPS=0
      shift
      ;;
    --skip-check)
      DO_CHECK=0
      shift
      ;;
    --no-start)
      DO_START=0
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "[ERROR] Unknown arg: $1" >&2
      usage
      exit 1
      ;;
  esac
done

case "$CONFIG_MODE" in
  current|example|keep) ;;
  *)
    echo "[ERROR] --config must be one of: current | example | keep" >&2
    exit 1
    ;;
esac

install_deps_apt() {
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -y
  # xdotool is needed for absolute-map cursor query mode.
  apt-get install -y python3 xdotool kmod util-linux
}

if [[ $DO_DEPS -eq 1 ]]; then
  if command -v apt-get >/dev/null 2>&1; then
    echo "[INFO] Installing dependencies by apt..."
    install_deps_apt
  else
    echo "[WARN] apt-get not found, skip dependency installation"
  fi
fi

if [[ $DO_CHECK -eq 1 ]]; then
  if [[ -x "$ROOT_DIR/scripts/check_usb_gadget_support.sh" ]]; then
    echo "[INFO] Running support check..."
    "$ROOT_DIR/scripts/check_usb_gadget_support.sh" || true
  fi
fi

echo "[INFO] Installing project to $PREFIX ..."
PREFIX="$PREFIX" "$ROOT_DIR/scripts/install.sh"

CURRENT_CFG="$ROOT_DIR/config/usb-mouse-sync.env.current"
EXAMPLE_CFG="$ROOT_DIR/config/usb-mouse-sync.env.example"
TARGET_CFG="/etc/default/usb-mouse-sync"

pick_config_file() {
  if [[ "$CONFIG_MODE" == "current" ]]; then
    if [[ -f "$CURRENT_CFG" ]]; then
      echo "$CURRENT_CFG"
      return 0
    fi
    if [[ -f "$EXAMPLE_CFG" ]]; then
      echo "$EXAMPLE_CFG"
      return 0
    fi
    return 1
  fi

  if [[ "$CONFIG_MODE" == "example" ]]; then
    if [[ -f "$EXAMPLE_CFG" ]]; then
      echo "$EXAMPLE_CFG"
      return 0
    fi
    return 1
  fi

  # keep mode
  if [[ -f "$TARGET_CFG" ]]; then
    return 1
  fi
  if [[ -f "$CURRENT_CFG" ]]; then
    echo "$CURRENT_CFG"
    return 0
  fi
  if [[ -f "$EXAMPLE_CFG" ]]; then
    echo "$EXAMPLE_CFG"
    return 0
  fi
  return 1
}

if cfg_src="$(pick_config_file)"; then
  install -m 0644 "$cfg_src" "$TARGET_CFG"
  echo "[OK] Wrote config: $TARGET_CFG (from $(basename "$cfg_src"))"
else
  echo "[INFO] Keep existing config: $TARGET_CFG"
fi

if [[ $DO_START -eq 1 ]]; then
  systemctl daemon-reload
  systemctl restart usb-mouse-sync.service usb-mouse-sync-api.service
  echo "[OK] Services restarted"
  systemctl status usb-mouse-sync.service usb-mouse-sync-api.service usb-mouse-sync-healthcheck.timer --no-pager || true
else
  echo "[INFO] Install finished, services not restarted (--no-start)"
fi

echo "[DONE] New board setup completed."
echo "[NEXT] Verify cable/OTG role and check status:"
echo "       systemctl status usb-mouse-sync.service usb-mouse-sync-api.service usb-mouse-sync-healthcheck.timer --no-pager"
echo "       journalctl -u usb-mouse-sync.service -u usb-mouse-sync-api.service -u usb-mouse-sync-healthcheck.service -n 80 --no-pager"
