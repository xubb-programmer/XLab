#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'EOF'
Usage: package_release.sh [options]

Create a migration package for new board one-click setup.

Options:
  --out-dir <dir>        Output dir, default: /home/ztl/mousectl/dist
  --name <name>          Package base name, default: usb_mouse_sync_bundle
  --with-current-config  Include /etc/default/usb-mouse-sync as
                         config/usb-mouse-sync.env.current (if exists)
  -h, --help             Show this help
EOF
}

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
  usage
  exit 0
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

OUT_DIR="/home/ztl/mousectl/dist"
PKG_NAME="usb_mouse_sync_bundle"
WITH_CURRENT_CONFIG=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --out-dir)
      OUT_DIR="${2:-}"
      shift 2
      ;;
    --name)
      PKG_NAME="${2:-}"
      shift 2
      ;;
    --with-current-config)
      WITH_CURRENT_CONFIG=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "[ERROR] Unknown arg: $1" >&2
      usage
      exit 1
      ;;
  esac
done

STAMP="$(date +%Y%m%d_%H%M%S)"
BUILD_ROOT="${OUT_DIR}/${PKG_NAME}_${STAMP}"
PAYLOAD_DIR="${BUILD_ROOT}/usb_mouse_sync"
ARCHIVE_PATH="${OUT_DIR}/${PKG_NAME}_${STAMP}.tar.gz"

mkdir -p "$BUILD_ROOT" "$OUT_DIR"

rsync -a \
  --delete \
  --exclude '__pycache__/' \
  --exclude '*.pyc' \
  --exclude '.git/' \
  "$ROOT_DIR/" "$PAYLOAD_DIR/"

if [[ $WITH_CURRENT_CONFIG -eq 1 ]]; then
  if [[ -f /etc/default/usb-mouse-sync ]]; then
    install -m 0644 /etc/default/usb-mouse-sync "$PAYLOAD_DIR/config/usb-mouse-sync.env.current"
    echo "[INFO] Included current config as config/usb-mouse-sync.env.current"
  else
    echo "[WARN] /etc/default/usb-mouse-sync not found, skip --with-current-config"
  fi
fi

cat > "${PAYLOAD_DIR}/INSTALL_NEW_BOARD.md" <<'EOF'
# USB Mouse Sync - New Board Quick Install

## 1) Copy and extract

```bash
mkdir -p ~/deploy
tar -xzf usb_mouse_sync_bundle_*.tar.gz -C ~/deploy
cd ~/deploy/usb_mouse_sync_bundle_*/usb_mouse_sync
```

## 2) One-click setup (root)

Recommended: keep existing `/etc/default/usb-mouse-sync` if already tuned.

```bash
sudo ./scripts/one_click_setup.sh --config keep
```

If you want to force this package's current config:

```bash
sudo ./scripts/one_click_setup.sh --config current
```

If you want to force example template:

```bash
sudo ./scripts/one_click_setup.sh --config example
```

## 3) Check

```bash
systemctl status usb-mouse-sync.service usb-mouse-sync-api.service --no-pager
systemctl status usb-mouse-sync-healthcheck.timer --no-pager
journalctl -u usb-mouse-sync.service -u usb-mouse-sync-api.service -u usb-mouse-sync-healthcheck.service -n 100 --no-pager
```
EOF

cat > "${PAYLOAD_DIR}/scripts/run_new_board_setup.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

if [[ $EUID -ne 0 ]]; then
  echo "[ERROR] Run as root: sudo $0" >&2
  exit 1
fi

"$ROOT_DIR/scripts/one_click_setup.sh" --config keep
EOF
chmod +x "${PAYLOAD_DIR}/scripts/run_new_board_setup.sh"

(
  cd "$OUT_DIR"
  tar -czf "$(basename "$ARCHIVE_PATH")" "$(basename "$BUILD_ROOT")"
)

echo "[OK] Package created:"
echo "     $ARCHIVE_PATH"
echo
echo "[HOWTO]"
echo "1) Copy archive to new board"
echo "2) tar -xzf $(basename "$ARCHIVE_PATH")"
echo "3) cd $(basename "$BUILD_ROOT")/usb_mouse_sync"
echo "4) sudo ./scripts/one_click_setup.sh --config keep"
