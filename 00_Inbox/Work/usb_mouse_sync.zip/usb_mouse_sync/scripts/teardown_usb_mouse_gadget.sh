#!/usr/bin/env bash
set -euo pipefail

GADGET_NAME="${GADGET_NAME:-g1}"
GADGET_DIR="/sys/kernel/config/usb_gadget/${GADGET_NAME}"
CONFIG_NAME="c.1"
MOUSE_FUNC_NAME="hid.usb0"
KEYBOARD_FUNC_NAME="hid.usb1"

if [[ $EUID -ne 0 ]]; then
  echo "[ERROR] Run as root" >&2
  exit 1
fi

if [[ ! -d "$GADGET_DIR" ]]; then
  echo "[INFO] Gadget $GADGET_NAME not found, nothing to do"
  exit 0
fi

if [[ -f "$GADGET_DIR/UDC" ]]; then
  echo "" > "$GADGET_DIR/UDC" || true
fi

rm -f "$GADGET_DIR/configs/${CONFIG_NAME}/${MOUSE_FUNC_NAME}" || true
rm -f "$GADGET_DIR/configs/${CONFIG_NAME}/${KEYBOARD_FUNC_NAME}" || true
rmdir "$GADGET_DIR/functions/${MOUSE_FUNC_NAME}" 2>/dev/null || true
rmdir "$GADGET_DIR/functions/${KEYBOARD_FUNC_NAME}" 2>/dev/null || true
rmdir "$GADGET_DIR/configs/${CONFIG_NAME}/strings/0x409" 2>/dev/null || true
rmdir "$GADGET_DIR/configs/${CONFIG_NAME}" 2>/dev/null || true
rmdir "$GADGET_DIR/strings/0x409" 2>/dev/null || true
rmdir "$GADGET_DIR" 2>/dev/null || true

echo "[OK] USB HID mouse gadget stopped"
