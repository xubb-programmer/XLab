#!/usr/bin/env bash
set -euo pipefail

EVENT_DEVICE="${EVENT_DEVICE:-}"
HIDG_DEVICE="${HIDG_DEVICE:-/dev/hidg0}"
ENABLE_HID_OUTPUT="${ENABLE_HID_OUTPUT:-1}"
ENABLE_INPUT_BRIDGE="${ENABLE_INPUT_BRIDGE:-1}"
ENABLE_NETWORK="${ENABLE_NETWORK:-1}"
INPUT_PRIORITY="${INPUT_PRIORITY:-local}"
LOCAL_IDLE_TIMEOUT_MS="${LOCAL_IDLE_TIMEOUT_MS:-3000}"
MOVE_SCALE="${MOVE_SCALE:-1.0}"
WHEEL_SCALE="${WHEEL_SCALE:-1.0}"
LOG_LEVEL="${LOG_LEVEL:-INFO}"
READ_CHUNK_EVENTS="${READ_CHUNK_EVENTS:-64}"
UDC_STATE_PATH="${UDC_STATE_PATH:-}"
HID_PROFILE="${HID_PROFILE:-extended5}"
HOME_ON_CONNECT="${HOME_ON_CONNECT:-1}"
HOME_STEPS="${HOME_STEPS:-24}"
START_BIAS_X="${START_BIAS_X:-0}"
START_BIAS_Y="${START_BIAS_Y:-0}"
MOUSE_MODE="${MOUSE_MODE:-relative}"
SRC_WIDTH="${SRC_WIDTH:-1920}"
SRC_HEIGHT="${SRC_HEIGHT:-1080}"
DST_WIDTH="${DST_WIDTH:-1280}"
DST_HEIGHT="${DST_HEIGHT:-720}"
DST_OFFSET_X="${DST_OFFSET_X:-0}"
DST_OFFSET_Y="${DST_OFFSET_Y:-0}"
DST_ACTIVE_WIDTH="${DST_ACTIVE_WIDTH:-0}"
DST_ACTIVE_HEIGHT="${DST_ACTIVE_HEIGHT:-0}"
AUTO_REBIND_EVENT="${AUTO_REBIND_EVENT:-1}"
SRC_OFFSET_X="${SRC_OFFSET_X:-0}"
SRC_OFFSET_Y="${SRC_OFFSET_Y:-0}"
USE_CURSOR_QUERY="${USE_CURSOR_QUERY:-1}"
CURSOR_QUERY_CMD="${CURSOR_QUERY_CMD:-xdotool}"
CURSOR_QUERY_USER="${CURSOR_QUERY_USER:-}"
CURSOR_DISPLAY="${CURSOR_DISPLAY:-}"
CURSOR_XAUTHORITY="${CURSOR_XAUTHORITY:-}"
CURSOR_XDG_RUNTIME_DIR="${CURSOR_XDG_RUNTIME_DIR:-}"
CURSOR_TIMEOUT_MS="${CURSOR_TIMEOUT_MS:-120}"
ALIGN_ON_CONNECT="${ALIGN_ON_CONNECT:-1}"
CONNECT_SETTLE_MS="${CONNECT_SETTLE_MS:-220}"
HOME_ROUNDS="${HOME_ROUNDS:-2}"
ALIGN_RETRIES="${ALIGN_RETRIES:-8}"
ALIGN_RETRY_INTERVAL_MS="${ALIGN_RETRY_INTERVAL_MS:-60}"
ALIGN_STEP_MAX="${ALIGN_STEP_MAX:-12}"
ALIGN_STEP_SLEEP_MS="${ALIGN_STEP_SLEEP_MS:-1}"
SOURCE_HOME_ON_CONNECT="${SOURCE_HOME_ON_CONNECT:-0}"
STRICT_ABSOLUTE_QUERY="${STRICT_ABSOLUTE_QUERY:-1}"

ENABLE_KEYBOARD_SYNC="${ENABLE_KEYBOARD_SYNC:-1}"
KEYBOARD_EVENT_DEVICE="${KEYBOARD_EVENT_DEVICE:-}"
KEYBOARD_HIDG_DEVICE="${KEYBOARD_HIDG_DEVICE:-/dev/hidg1}"
AUTO_REBIND_KEYBOARD_EVENT="${AUTO_REBIND_KEYBOARD_EVENT:-1}"

NETWORK_ROLE="${NETWORK_ROLE:-client}"
NETWORK_HOST="${NETWORK_HOST:-127.0.0.1}"
NETWORK_PORT="${NETWORK_PORT:-5566}"
NETWORK_RETRY_MS="${NETWORK_RETRY_MS:-1000}"
NETWORK_CONNECT_TIMEOUT_MS="${NETWORK_CONNECT_TIMEOUT_MS:-2000}"
NETWORK_QUEUE_SIZE="${NETWORK_QUEUE_SIZE:-512}"
ENABLE_ACTION_TCP="${ENABLE_ACTION_TCP:-1}"
ACTION_TCP_HOST="${ACTION_TCP_HOST:-0.0.0.0}"
ACTION_TCP_PORT="${ACTION_TCP_PORT:-5567}"
ACTION_TCP_MAX_LINE_BYTES="${ACTION_TCP_MAX_LINE_BYTES:-16384}"
ACTION_TCP_QUEUE_SIZE="${ACTION_TCP_QUEUE_SIZE:-32}"
ENABLE_ACTION_UDP="${ENABLE_ACTION_UDP:-1}"
ACTION_UDP_HOST="${ACTION_UDP_HOST:-0.0.0.0}"
ACTION_UDP_PORT="${ACTION_UDP_PORT:-5568}"
ACTION_UDP_MAX_DATAGRAM_BYTES="${ACTION_UDP_MAX_DATAGRAM_BYTES:-16384}"
ACTIONS_CONFIG_PATH="${ACTIONS_CONFIG_PATH:-/etc/usb-mouse-sync/actions.json}"
HID_LOCK_PATH="${HID_LOCK_PATH:-/run/lock/usb-mouse-sync-hid.lock}"

ARGS=(
  --hidg "$HIDG_DEVICE"
  --input-priority "$INPUT_PRIORITY"
  --local-idle-timeout-ms "$LOCAL_IDLE_TIMEOUT_MS"
  --move-scale "$MOVE_SCALE"
  --wheel-scale "$WHEEL_SCALE"
  --read-chunk-events "$READ_CHUNK_EVENTS"
  --hid-profile "$HID_PROFILE"
  --home-steps "$HOME_STEPS"
  --start-bias-x "$START_BIAS_X"
  --start-bias-y "$START_BIAS_Y"
  --mouse-mode "$MOUSE_MODE"
  --src-width "$SRC_WIDTH"
  --src-height "$SRC_HEIGHT"
  --dst-width "$DST_WIDTH"
  --dst-height "$DST_HEIGHT"
  --dst-offset-x "$DST_OFFSET_X"
  --dst-offset-y "$DST_OFFSET_Y"
  --dst-active-width "$DST_ACTIVE_WIDTH"
  --dst-active-height "$DST_ACTIVE_HEIGHT"
  --src-offset-x "$SRC_OFFSET_X"
  --src-offset-y "$SRC_OFFSET_Y"
  --cursor-query-cmd "$CURSOR_QUERY_CMD"
  --cursor-query-user "$CURSOR_QUERY_USER"
  --cursor-timeout-ms "$CURSOR_TIMEOUT_MS"
  --connect-settle-ms "$CONNECT_SETTLE_MS"
  --home-rounds "$HOME_ROUNDS"
  --align-retries "$ALIGN_RETRIES"
  --align-retry-interval-ms "$ALIGN_RETRY_INTERVAL_MS"
  --align-step-max "$ALIGN_STEP_MAX"
  --align-step-sleep-ms "$ALIGN_STEP_SLEEP_MS"
  --keyboard-hidg "$KEYBOARD_HIDG_DEVICE"
  --network-role "$NETWORK_ROLE"
  --network-host "$NETWORK_HOST"
  --network-port "$NETWORK_PORT"
  --network-retry-ms "$NETWORK_RETRY_MS"
  --network-connect-timeout-ms "$NETWORK_CONNECT_TIMEOUT_MS"
  --network-queue-size "$NETWORK_QUEUE_SIZE"
  --action-tcp-host "$ACTION_TCP_HOST"
  --action-tcp-port "$ACTION_TCP_PORT"
  --action-tcp-max-line-bytes "$ACTION_TCP_MAX_LINE_BYTES"
  --action-tcp-queue-size "$ACTION_TCP_QUEUE_SIZE"
  --action-udp-host "$ACTION_UDP_HOST"
  --action-udp-port "$ACTION_UDP_PORT"
  --action-udp-max-datagram-bytes "$ACTION_UDP_MAX_DATAGRAM_BYTES"
  --actions-config "$ACTIONS_CONFIG_PATH"
  --hid-lock-path "$HID_LOCK_PATH"
  --log-level "$LOG_LEVEL"
)

if [[ "$ENABLE_HID_OUTPUT" == "0" ]]; then
  ARGS+=(--disable-hid-output)
fi
if [[ "$ENABLE_NETWORK" == "0" ]]; then
  ARGS+=(--disable-network)
fi
if [[ "$ENABLE_ACTION_TCP" == "0" ]]; then
  ARGS+=(--disable-action-tcp)
fi
if [[ "$ENABLE_ACTION_UDP" == "0" ]]; then
  ARGS+=(--disable-action-udp)
fi

if [[ -n "$EVENT_DEVICE" ]]; then
  ARGS+=(--event "$EVENT_DEVICE")
fi

if [[ "$HOME_ON_CONNECT" == "0" ]]; then
  ARGS+=(--no-home-on-connect)
fi
if [[ "$AUTO_REBIND_EVENT" == "0" ]]; then
  ARGS+=(--no-auto-rebind-event)
fi
if [[ "$USE_CURSOR_QUERY" == "0" ]]; then
  ARGS+=(--no-cursor-query)
fi
if [[ "$ALIGN_ON_CONNECT" == "0" ]]; then
  ARGS+=(--no-align-on-connect)
fi
if [[ "$SOURCE_HOME_ON_CONNECT" == "1" ]]; then
  ARGS+=(--source-home-on-connect)
fi
if [[ "$STRICT_ABSOLUTE_QUERY" == "0" ]]; then
  ARGS+=(--no-strict-absolute-query)
fi
if [[ -n "$CURSOR_DISPLAY" ]]; then
  ARGS+=(--cursor-display "$CURSOR_DISPLAY")
fi
if [[ -n "$CURSOR_XAUTHORITY" ]]; then
  ARGS+=(--cursor-xauthority "$CURSOR_XAUTHORITY")
fi
if [[ -n "$CURSOR_XDG_RUNTIME_DIR" ]]; then
  ARGS+=(--cursor-xdg-runtime-dir "$CURSOR_XDG_RUNTIME_DIR")
fi

if [[ "$ENABLE_KEYBOARD_SYNC" == "0" ]]; then
  ARGS+=(--disable-keyboard)
else
  if [[ -n "$KEYBOARD_EVENT_DEVICE" ]]; then
    ARGS+=(--keyboard-event "$KEYBOARD_EVENT_DEVICE")
  fi
  if [[ "$AUTO_REBIND_KEYBOARD_EVENT" == "0" ]]; then
    ARGS+=(--no-keyboard-auto-rebind-event)
  fi
fi

if [[ -z "$UDC_STATE_PATH" && -n "${UDC_NAME:-}" && -f "/sys/class/udc/${UDC_NAME}/state" ]]; then
  UDC_STATE_PATH="/sys/class/udc/${UDC_NAME}/state"
fi
if [[ -n "$UDC_STATE_PATH" && -f "$UDC_STATE_PATH" ]]; then
  ARGS+=(--udc-state-path "$UDC_STATE_PATH")
elif [[ -n "$UDC_STATE_PATH" ]]; then
  echo "[WARN] UDC_STATE_PATH not found: $UDC_STATE_PATH, ignore" >&2
fi

if [[ "$ENABLE_HID_OUTPUT" == "1" ]]; then
  /opt/usb-mouse-sync/scripts/setup_usb_mouse_gadget.sh
  for _ in {1..20}; do
    if [[ -e "$HIDG_DEVICE" && ( "$ENABLE_KEYBOARD_SYNC" == "0" || -e "$KEYBOARD_HIDG_DEVICE" ) ]]; then
      break
    fi
    sleep 0.1
  done
  if [[ ! -e "$HIDG_DEVICE" || ( "$ENABLE_KEYBOARD_SYNC" != "0" && ! -e "$KEYBOARD_HIDG_DEVICE" ) ]]; then
    echo "[WARN] HID nodes missing after setup, retry gadget setup" >&2
    /opt/usb-mouse-sync/scripts/setup_usb_mouse_gadget.sh
  fi
fi

if [[ "$ENABLE_INPUT_BRIDGE" == "0" ]]; then
  echo "[INFO] ENABLE_INPUT_BRIDGE=0, running action TCP/UDP servers without continuous input bridge"
  ARGS+=(--action-only)
fi

exec /usr/bin/python3 /opt/usb-mouse-sync/src/usb_input_bridge.py "${ARGS[@]}"
