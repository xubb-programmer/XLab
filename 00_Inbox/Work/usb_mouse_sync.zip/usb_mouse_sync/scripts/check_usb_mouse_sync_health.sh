#!/usr/bin/env bash
set -euo pipefail

CONFIG_PATH="${CONFIG_PATH:-/etc/default/usb-mouse-sync}"
SERVICE_NAME="${SERVICE_NAME:-usb-mouse-sync.service}"
SETUP_SCRIPT="${SETUP_SCRIPT:-/opt/usb-mouse-sync/scripts/setup_usb_mouse_gadget.sh}"
STATE_DIR="${STATE_DIR:-/run/usb-mouse-sync}"
RESTART_COOLDOWN_SEC="${RESTART_COOLDOWN_SEC:-20}"
TCP_START_GRACE_SEC="${TCP_START_GRACE_SEC:-15}"
UDP_START_GRACE_SEC="${UDP_START_GRACE_SEC:-15}"
UDC_CONFIG_TIMEOUT_SEC="${UDC_CONFIG_TIMEOUT_SEC:-10}"
UDC_REBIND_COOLDOWN_SEC="${UDC_REBIND_COOLDOWN_SEC:-20}"

config_value() {
  local key="$1"
  [[ -f "$CONFIG_PATH" ]] || return 1
  awk -F= -v key="$key" '
    $0 ~ /^[[:space:]]*#/ { next }
    $1 == key {
      sub(/^[^=]*=/, "")
      print
      exit
    }
  ' "$CONFIG_PATH"
}

cfg() {
  local key="$1"
  local default_value="$2"
  local value
  value="$(config_value "$key" 2>/dev/null || true)"
  if [[ -n "$value" ]]; then
    printf '%s\n' "$value"
  else
    printf '%s\n' "$default_value"
  fi
}

is_enabled_value() {
  case "${1:-}" in
    1|true|TRUE|yes|YES|on|ON) return 0 ;;
    *) return 1 ;;
  esac
}

log() {
  echo "[healthcheck] $*"
}

restart_service() {
  local reason="$1"
  local stamp="${STATE_DIR}/last-health-restart"
  local now last

  mkdir -p "$STATE_DIR"
  now="$(date +%s)"
  last="$(cat "$stamp" 2>/dev/null || echo 0)"
  if (( now - last < RESTART_COOLDOWN_SEC )); then
    log "skip restart during cooldown (${reason})"
    return 0
  fi

  echo "$now" > "$stamp"
  log "restart ${SERVICE_NAME}: ${reason}"
  systemctl restart "$SERVICE_NAME"
}

port_listening() {
  local port="$1"
  command -v ss >/dev/null 2>&1 || return 0
  ss -H -ltn 2>/dev/null | awk '{print $4}' | grep -Eq "(^|:)${port}$"
}

udp_port_listening() {
  local port="$1"
  command -v ss >/dev/null 2>&1 || return 0
  ss -H -lun 2>/dev/null | awk '{print $4}' | grep -Eq "(^|:)${port}$"
}

check_action_tcp_port() {
  local port="$1"
  local now since
  local stamp="${STATE_DIR}/action-tcp-missing-since"

  if port_listening "$port"; then
    rm -f "$stamp"
    return 0
  fi

  mkdir -p "$STATE_DIR"
  now="$(date +%s)"
  since="$(cat "$stamp" 2>/dev/null || echo 0)"
  if (( since <= 0 )); then
    echo "$now" > "$stamp"
    log "action TCP port ${port} is not listening; wait for service startup"
    return 0
  fi
  if (( now - since < TCP_START_GRACE_SEC )); then
    return 0
  fi
  return 1
}

check_action_udp_port() {
  local port="$1"
  local now since
  local stamp="${STATE_DIR}/action-udp-missing-since"

  if udp_port_listening "$port"; then
    rm -f "$stamp"
    return 0
  fi

  mkdir -p "$STATE_DIR"
  now="$(date +%s)"
  since="$(cat "$stamp" 2>/dev/null || echo 0)"
  if (( since <= 0 )); then
    echo "$now" > "$stamp"
    log "action UDP port ${port} is not listening; wait for service startup"
    return 0
  fi
  if (( now - since < UDP_START_GRACE_SEC )); then
    return 0
  fi
  return 1
}

has_udc() {
  compgen -G "/sys/class/udc/*" >/dev/null
}

read_first_existing() {
  local path
  for path in "$@"; do
    [[ -r "$path" ]] || continue
    cat "$path" 2>/dev/null || true
    return 0
  done
  return 1
}

hid_nodes_ready() {
  local hidg_device="$1"
  local keyboard_enabled="$2"
  local keyboard_hidg_device="$3"

  [[ -c "$hidg_device" ]] || return 1
  if is_enabled_value "$keyboard_enabled"; then
    [[ -c "$keyboard_hidg_device" ]] || return 1
  fi
}

gadget_bound() {
  local gadget_name="$1"
  local udc_file="/sys/kernel/config/usb_gadget/${gadget_name}/UDC"
  [[ -s "$udc_file" ]]
}

udc_state() {
  local state_file
  for state_file in /sys/class/udc/*/state; do
    [[ -r "$state_file" ]] || continue
    cat "$state_file" 2>/dev/null || true
    return 0
  done
  return 1
}

repair_nonconfigured_udc() {
  local state="$1"
  local now since last_rebind previous_state
  local since_file="${STATE_DIR}/udc-nonconfigured-since"
  local rebind_file="${STATE_DIR}/last-udc-rebind"
  local state_file="${STATE_DIR}/last-udc-state"

  mkdir -p "$STATE_DIR"
  now="$(date +%s)"
  previous_state="$(cat "$state_file" 2>/dev/null || true)"
  if [[ "$previous_state" != "$state" ]]; then
    printf '%s\n' "$state" > "$state_file"
    echo "$now" > "$since_file"
    log "UDC state changed to ${state:-unknown}; wait for host enumeration"
    return 0
  fi

  since="$(cat "$since_file" 2>/dev/null || echo 0)"
  if (( since <= 0 )); then
    echo "$now" > "$since_file"
    log "UDC state is ${state:-unknown}; wait for host enumeration"
    return 0
  fi

  if (( now - since < UDC_CONFIG_TIMEOUT_SEC )); then
    return 0
  fi

  last_rebind="$(cat "$rebind_file" 2>/dev/null || echo 0)"
  if (( now - last_rebind < UDC_REBIND_COOLDOWN_SEC )); then
    return 0
  fi

  echo "$now" > "$rebind_file"
  log "UDC stayed ${state:-unknown} for $((now - since))s; force gadget rebind"
  FORCE_REBIND=1 "$SETUP_SCRIPT" || true
  echo "$now" > "$since_file"
}

main() {
  local enable_hid_output enable_keyboard enable_action_tcp enable_action_udp
  local hidg_device keyboard_hidg_device action_tcp_port action_udp_port gadget_name
  local setup_needed=0 restart_reason="" mode otg_mode current_udc_state

  enable_hid_output="$(cfg ENABLE_HID_OUTPUT 1)"
  enable_keyboard="$(cfg ENABLE_KEYBOARD_SYNC 1)"
  enable_action_tcp="$(cfg ENABLE_ACTION_TCP 1)"
  enable_action_udp="$(cfg ENABLE_ACTION_UDP 1)"
  hidg_device="$(cfg HIDG_DEVICE /dev/hidg0)"
  keyboard_hidg_device="$(cfg KEYBOARD_HIDG_DEVICE /dev/hidg1)"
  action_tcp_port="$(cfg ACTION_TCP_PORT 5567)"
  action_udp_port="$(cfg ACTION_UDP_PORT 5568)"
  gadget_name="$(cfg GADGET_NAME g1)"

  if ! systemctl is-active --quiet "$SERVICE_NAME"; then
    restart_service "service is not active"
    return 0
  fi

  if is_enabled_value "$enable_action_tcp"; then
    if ! check_action_tcp_port "$action_tcp_port"; then
      restart_reason="action TCP port ${action_tcp_port} is not listening"
    fi
  fi

  if is_enabled_value "$enable_action_udp"; then
    if ! check_action_udp_port "$action_udp_port"; then
      restart_reason="${restart_reason:-action UDP port ${action_udp_port} is not listening}"
    fi
  fi

  if is_enabled_value "$enable_hid_output"; then
    if ! has_udc; then
      setup_needed=1
    fi

    mode="$(read_first_existing /sys/kernel/debug/usb/fc000000.usb/mode || true)"
    otg_mode="$(read_first_existing /sys/devices/platform/fd5d0000.syscon/fd5d0000.syscon:usb2-phy@0/otg_mode || true)"
    if [[ "$mode" == "host" || "$otg_mode" == "host" ]]; then
      setup_needed=1
    fi

    if ! hid_nodes_ready "$hidg_device" "$enable_keyboard" "$keyboard_hidg_device"; then
      setup_needed=1
    fi

    if ! gadget_bound "$gadget_name"; then
      setup_needed=1
    fi

    if (( setup_needed == 1 )); then
      if [[ -x "$SETUP_SCRIPT" ]]; then
        log "repair HID gadget state"
        "$SETUP_SCRIPT" || true
        sleep 0.5
      fi

      mode="$(read_first_existing /sys/kernel/debug/usb/fc000000.usb/mode || true)"
      otg_mode="$(read_first_existing /sys/devices/platform/fd5d0000.syscon/fd5d0000.syscon:usb2-phy@0/otg_mode || true)"
      if ! has_udc; then
        restart_reason="${restart_reason:-UDC is missing}"
      elif [[ "$mode" == "host" || "$otg_mode" == "host" ]]; then
        restart_reason="${restart_reason:-USB role is still host}"
      elif ! hid_nodes_ready "$hidg_device" "$enable_keyboard" "$keyboard_hidg_device"; then
        restart_reason="${restart_reason:-HID device nodes are missing}"
      elif ! gadget_bound "$gadget_name"; then
        restart_reason="${restart_reason:-USB gadget is not bound}"
      fi
    fi

    current_udc_state="$(udc_state || true)"
    if [[ "$current_udc_state" == "configured" ]]; then
      rm -f \
        "${STATE_DIR}/udc-nonconfigured-since" \
        "${STATE_DIR}/last-udc-state"
    elif has_udc && gadget_bound "$gadget_name"; then
      repair_nonconfigured_udc "$current_udc_state"
    fi
  fi

  if [[ -n "$restart_reason" ]]; then
    restart_service "$restart_reason"
  fi
}

main "$@"
