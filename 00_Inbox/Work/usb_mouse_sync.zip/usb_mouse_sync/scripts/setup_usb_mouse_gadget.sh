#!/usr/bin/env bash
set -euo pipefail

GADGET_NAME="${GADGET_NAME:-g1}"
GADGET_DIR="/sys/kernel/config/usb_gadget/${GADGET_NAME}"
CONFIG_NAME="c.1"
MOUSE_FUNC_NAME="hid.usb0"
KEYBOARD_FUNC_NAME="hid.usb1"

VID="${USB_VID:-0x1d6b}"          # Linux Foundation (safe default for prototype)
PID="${USB_PID:-0x0104}"          # Multifunction Composite Gadget
BCD_DEVICE="${USB_BCD_DEVICE:-0x0100}"
BCD_USB="${USB_BCD_USB:-0x0200}"
SERIAL="${USB_SERIAL:-RK3588MOUSE0001}"
MANUFACTURER="${USB_MANUFACTURER:-RK3588}"
PRODUCT="${USB_PRODUCT:-USB Mouse Bridge}"
UDC_NAME="${UDC_NAME:-}"
HID_PROFILE="${HID_PROFILE:-extended5}"
# If target UDC is occupied by another gadget, reclaim it automatically.
# 1: reclaim, 0: fail fast.
RECLAIM_UDC="${RECLAIM_UDC:-1}"
ENABLE_KEYBOARD_SYNC="${ENABLE_KEYBOARD_SYNC:-1}"
FORCE_REBIND="${FORCE_REBIND:-0}"

HID_REPORT_LENGTH=5
HID_PROTOCOL=0
HID_SUBCLASS=0
# default 5-byte report: buttons, X, Y, wheel, hwheel
HID_REPORT_DESC_HEX='\x05\x01\x09\x02\xa1\x01\x09\x01\xa1\x00\x05\x09\x19\x01\x29\x05\x15\x00\x25\x01\x95\x05\x75\x01\x81\x02\x95\x01\x75\x03\x81\x03\x05\x01\x09\x30\x09\x31\x09\x38\x15\x81\x25\x7f\x75\x08\x95\x03\x81\x06\x05\x0c\x0a\x38\x02\x95\x01\x81\x06\xc0\xc0'

# Boot keyboard report: modifiers, reserved, 6 keycodes.
KB_REPORT_LENGTH=8
KB_PROTOCOL=1
KB_SUBCLASS=1
KB_REPORT_DESC_HEX='\x05\x01\x09\x06\xa1\x01\x05\x07\x19\xe0\x29\xe7\x15\x00\x25\x01\x75\x01\x95\x08\x81\x02\x95\x01\x75\x08\x81\x01\x95\x06\x75\x08\x15\x00\x25\x65\x05\x07\x19\x00\x29\x65\x81\x00\xc0'

case "${HID_PROFILE}" in
  boot3)
    # Compatibility-first profile for strict Android/embedded hosts.
    # Report: [buttons(3bits + padding), x, y]
    HID_REPORT_LENGTH=3
    HID_PROTOCOL=2
    HID_SUBCLASS=1
    HID_REPORT_DESC_HEX='\x05\x01\x09\x02\xa1\x01\x09\x01\xa1\x00\x05\x09\x19\x01\x29\x03\x15\x00\x25\x01\x95\x03\x75\x01\x81\x02\x95\x01\x75\x05\x81\x03\x05\x01\x09\x30\x09\x31\x15\x81\x25\x7f\x75\x08\x95\x02\x81\x06\xc0\xc0'
    ;;
  extended5)
    ;;
  *)
    echo "[ERROR] Unsupported HID_PROFILE: ${HID_PROFILE} (use boot3 or extended5)" >&2
    exit 1
    ;;
esac

if [[ $EUID -ne 0 ]]; then
  echo "[ERROR] Run as root" >&2
  exit 1
fi

if ! mountpoint -q /sys/kernel/config; then
  mount -t configfs none /sys/kernel/config
fi

if [[ ! -d /sys/kernel/config/usb_gadget ]]; then
  echo "[ERROR] /sys/kernel/config/usb_gadget not found" >&2
  exit 1
fi

list_udc() {
  ls /sys/class/udc 2>/dev/null || true
}

find_udc_holder() {
  local target_udc="$1"
  local g g_udc
  for g in /sys/kernel/config/usb_gadget/*; do
    [[ -d "$g" ]] || continue
    g_udc="$(cat "$g/UDC" 2>/dev/null || true)"
    if [[ "$g_udc" == "$target_udc" ]]; then
      basename "$g"
      return 0
    fi
  done
  return 1
}

release_udc_holder() {
  local holder="$1"
  if [[ -z "$holder" ]]; then
    return 1
  fi
  if [[ "$holder" == "$GADGET_NAME" ]]; then
    return 0
  fi

  if [[ "$RECLAIM_UDC" != "1" ]]; then
    echo "[ERROR] UDC is occupied by gadget '${holder}', and RECLAIM_UDC=0" >&2
    return 1
  fi

  echo "[WARN] Reclaiming UDC from gadget: ${holder}"
  if [[ -w "/sys/kernel/config/usb_gadget/${holder}/UDC" ]]; then
    echo "" > "/sys/kernel/config/usb_gadget/${holder}/UDC" || true
    sleep 0.1
  fi
  return 0
}

bind_target_udc() {
  local attempt current_udc holder

  for attempt in {1..20}; do
    current_udc="$(cat UDC 2>/dev/null || true)"
    if [[ "$current_udc" == "$UDC_NAME" ]]; then
      return 0
    fi

    if echo "$UDC_NAME" > UDC 2>/dev/null; then
      return 0
    fi

    holder="$(find_udc_holder "$UDC_NAME" || true)"
    if [[ -n "$holder" && "$holder" != "$GADGET_NAME" ]]; then
      release_udc_holder "$holder" || return 1
    fi
    sleep 0.1
  done

  holder="$(find_udc_holder "$UDC_NAME" || true)"
  if [[ -n "$holder" ]]; then
    echo "[ERROR] Failed to bind UDC ${UDC_NAME}; occupied by gadget: ${holder}" >&2
  else
    echo "[ERROR] Failed to bind UDC ${UDC_NAME}; holder unknown" >&2
  fi
  return 1
}

pick_udc() {
  local picked
  if [[ -n "${UDC_NAME}" ]]; then
    if [[ -e "/sys/class/udc/${UDC_NAME}" ]]; then
      echo "${UDC_NAME}"
      return 0
    fi
    return 1
  fi

  picked="$(list_udc | head -n1 || true)"
  if [[ -n "${picked}" ]]; then
    echo "${picked}"
    return 0
  fi
  return 1
}

wait_for_udc() {
  local timeout_ms="${1:-4000}"
  local elapsed=0
  while (( elapsed < timeout_ms )); do
    if pick_udc >/dev/null 2>&1; then
      return 0
    fi
    sleep 0.1
    elapsed=$((elapsed + 100))
  done
  return 1
}

show_runtime_hint() {
  for path in \
    /sys/devices/platform/fd5d0000.syscon/fd5d0000.syscon:usb2-phy@0/otg_mode \
    /sys/devices/platform/fd5d4000.syscon/fd5d4000.syscon:usb2-phy@4000/otg_mode; do
    [[ -f "${path}" ]] || continue
    echo "[INFO] $(basename "$(dirname "${path}")")/otg_mode=$(cat "${path}")"
  done

  for ext in /sys/class/extcon/extcon0 /sys/class/extcon/extcon3; do
    [[ -f "${ext}/state" ]] || continue
    echo "[INFO] ${ext} state:"
    sed 's/^/[INFO]   /' "${ext}/state"
  done
}

ensure_hid_node() {
  local func_name="$1"
  local node_path="$2"
  local func_dir="functions/${func_name}"
  local dev major minor

  if [[ ! -r "${func_dir}/dev" ]]; then
    return 0
  fi

  dev="$(cat "${func_dir}/dev" 2>/dev/null || true)"
  if [[ ! "${dev}" =~ ^[0-9]+:[0-9]+$ ]]; then
    return 0
  fi
  major="${dev%%:*}"
  minor="${dev##*:}"

  if [[ ! -c "${node_path}" ]]; then
    rm -f "${node_path}"
    mknod -m 0600 "${node_path}" c "${major}" "${minor}" || true
  fi
  if [[ -c "${node_path}" ]]; then
    chmod 0600 "${node_path}" || true
  fi
}

force_peripheral_mode() {
  local changed=0
  local debug_mode=/sys/kernel/debug/usb/fc000000.usb/mode
  local otg_candidates=()
  local link target

  if ! mountpoint -q /sys/kernel/debug; then
    mount -t debugfs none /sys/kernel/debug 2>/dev/null || true
  fi

  if [[ -w "${debug_mode}" ]]; then
    echo device > "${debug_mode}" || true
    echo "[INFO] Forced USB role by ${debug_mode}=device"
    changed=1
  fi

  for root in \
    /sys/devices/platform/usbdrd3_0/fc000000.usb \
    /sys/devices/platform/fc000000.usb; do
    [[ -d "${root}" ]] || continue
    for link in "${root}"/supplier:platform:*usb2-phy@*; do
      [[ -L "${link}" ]] || continue
      target="$(readlink -f "${link}")"
      if [[ -n "${target}" && -w "${target}/otg_mode" ]]; then
        otg_candidates+=("${target}/otg_mode")
      fi
    done
  done

  if [[ ${#otg_candidates[@]} -gt 0 ]]; then
    mapfile -t otg_candidates < <(printf '%s\n' "${otg_candidates[@]}" | awk '!seen[$0]++')
  fi
  if [[ ${#otg_candidates[@]} -eq 0 ]]; then
    # Board fallback: A588 OTG port is usually backed by usb2-phy@0.
    if [[ -w /sys/devices/platform/fd5d0000.syscon/fd5d0000.syscon:usb2-phy@0/otg_mode ]]; then
      otg_candidates+=(/sys/devices/platform/fd5d0000.syscon/fd5d0000.syscon:usb2-phy@0/otg_mode)
    fi
  fi

  for path in "${otg_candidates[@]}"; do
    if echo otg > "${path}" 2>/dev/null; then
      echo "[INFO] Forced USB role by ${path}=otg"
      changed=1
      continue
    fi
    if echo peripheral > "${path}" 2>/dev/null; then
      echo "[INFO] Forced USB role by ${path}=peripheral"
      changed=1
      continue
    fi
  done

  if [[ ${changed} -eq 1 ]]; then
    sleep 0.3
  fi
}

if ! wait_for_udc 1200; then
  echo "[WARN] No UDC found, attempting to switch OTG role to peripheral..."
  force_peripheral_mode
fi

if ! wait_for_udc 5000; then
  echo "[ERROR] No UDC found. OTG port may still be in host mode or no cable attached." >&2
  show_runtime_hint
  exit 1
fi

UDC_NAME="$(pick_udc)"

mkdir -p "$GADGET_DIR"
cd "$GADGET_DIR"

current_udc="$(cat UDC 2>/dev/null || true)"
if [[ "$current_udc" == "$UDC_NAME" && "$FORCE_REBIND" != "1" ]]; then
  echo "[OK] USB HID mouse gadget already active on UDC: $UDC_NAME"
  ensure_hid_node "$MOUSE_FUNC_NAME" /dev/hidg0
  if [[ "${ENABLE_KEYBOARD_SYNC}" == "1" ]]; then
    ensure_hid_node "$KEYBOARD_FUNC_NAME" /dev/hidg1
  fi
  echo "[INFO] HID nodes should appear as /dev/hidg0 (mouse) and /dev/hidg1 (keyboard, if enabled)"
  exit 0
fi

if [[ -n "$current_udc" ]]; then
  echo "[INFO] Unbinding gadget from UDC: $current_udc"
  echo "" > UDC || true
  sleep 0.2
fi

if [[ "$FORCE_REBIND" == "1" ]]; then
  echo "[INFO] Force USB gadget rebind"
  force_peripheral_mode
  if ! wait_for_udc 5000; then
    echo "[ERROR] UDC disappeared during forced rebind" >&2
    exit 1
  fi
  UDC_NAME="$(pick_udc)"

  # The gadget functions are already valid here. Rebinding only the UDC avoids
  # replacing hidg devices while the bridge process may still have them open.
  if [[ -d "functions/${MOUSE_FUNC_NAME}" && -L "configs/${CONFIG_NAME}/${MOUSE_FUNC_NAME}" ]] &&
     { [[ "${ENABLE_KEYBOARD_SYNC}" != "1" ]] ||
       [[ -d "functions/${KEYBOARD_FUNC_NAME}" && -L "configs/${CONFIG_NAME}/${KEYBOARD_FUNC_NAME}" ]]; }; then
    if ! bind_target_udc; then
      echo "[ERROR] Failed to rebind existing gadget to UDC ${UDC_NAME}" >&2
      exit 1
    fi
    ensure_hid_node "$MOUSE_FUNC_NAME" /dev/hidg0
    if [[ "${ENABLE_KEYBOARD_SYNC}" == "1" ]]; then
      ensure_hid_node "$KEYBOARD_FUNC_NAME" /dev/hidg1
    fi
    echo "[OK] Existing USB HID gadget rebound to UDC: $UDC_NAME"
    exit 0
  fi
fi

if [[ ! -f idVendor ]] || [[ "$(cat idVendor 2>/dev/null || true)" != "$VID" ]]; then
  echo "$VID" > idVendor
fi
if [[ ! -f idProduct ]] || [[ "$(cat idProduct 2>/dev/null || true)" != "$PID" ]]; then
  echo "$PID" > idProduct
fi
if [[ ! -f bcdDevice ]] || [[ "$(cat bcdDevice 2>/dev/null || true)" != "$BCD_DEVICE" ]]; then
  echo "$BCD_DEVICE" > bcdDevice
fi
if [[ ! -f bcdUSB ]] || [[ "$(cat bcdUSB 2>/dev/null || true)" != "$BCD_USB" ]]; then
  echo "$BCD_USB" > bcdUSB
fi

mkdir -p strings/0x409
echo "$SERIAL" > strings/0x409/serialnumber
echo "$MANUFACTURER" > strings/0x409/manufacturer
echo "$PRODUCT" > strings/0x409/product

mkdir -p "configs/${CONFIG_NAME}/strings/0x409"
if [[ "${ENABLE_KEYBOARD_SYNC}" == "1" ]]; then
  echo "USB Mouse+Keyboard" > "configs/${CONFIG_NAME}/strings/0x409/configuration"
else
  echo "USB Mouse" > "configs/${CONFIG_NAME}/strings/0x409/configuration"
fi
echo 120 > "configs/${CONFIG_NAME}/MaxPower"

setup_hid_func() {
  local func_name="$1"
  local protocol="$2"
  local subclass="$3"
  local report_length="$4"
  local report_desc_hex="$5"

  local func_dir="functions/${func_name}"
  local cfg_link="configs/${CONFIG_NAME}/${func_name}"

  if [[ -L "$cfg_link" ]]; then
    rm -f "$cfg_link"
  fi
  if [[ -d "$func_dir" ]]; then
    rmdir "$func_dir" 2>/dev/null || true
  fi
  mkdir -p "$func_dir"
  echo "$protocol" > "${func_dir}/protocol"
  echo "$subclass" > "${func_dir}/subclass"
  echo "$report_length" > "${func_dir}/report_length"
  # shellcheck disable=SC2059
  printf "$report_desc_hex" > "${func_dir}/report_desc"
  if [[ ! -L "$cfg_link" ]]; then
    rm -f "$cfg_link"
    ln -s "$func_dir" "configs/${CONFIG_NAME}/"
  fi
}

setup_hid_func "$MOUSE_FUNC_NAME" "${HID_PROTOCOL}" "${HID_SUBCLASS}" "${HID_REPORT_LENGTH}" "${HID_REPORT_DESC_HEX}"
if [[ "${ENABLE_KEYBOARD_SYNC}" == "1" ]]; then
  setup_hid_func "$KEYBOARD_FUNC_NAME" "${KB_PROTOCOL}" "${KB_SUBCLASS}" "${KB_REPORT_LENGTH}" "${KB_REPORT_DESC_HEX}"
else
  rm -f "configs/${CONFIG_NAME}/${KEYBOARD_FUNC_NAME}" || true
  rmdir "functions/${KEYBOARD_FUNC_NAME}" 2>/dev/null || true
fi

if ! bind_target_udc; then
  exit 1
fi

ensure_hid_node "$MOUSE_FUNC_NAME" /dev/hidg0
if [[ "${ENABLE_KEYBOARD_SYNC}" == "1" ]]; then
  ensure_hid_node "$KEYBOARD_FUNC_NAME" /dev/hidg1
fi

echo "[OK] USB HID gadget is up on UDC: $UDC_NAME"
echo "[INFO] HID nodes should appear as /dev/hidg0 (mouse) and /dev/hidg1 (keyboard, if enabled)"
