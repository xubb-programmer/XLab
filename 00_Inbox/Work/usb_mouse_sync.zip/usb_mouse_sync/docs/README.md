# RK3588 USB Mouse Sync (Android)

在 RK3588 (Ubuntu 20.04) 上把本机鼠标键盘事件转给 Android 手柄。当前版本每个节点都可同时具备三种能力：
- 采集本地 USB 鼠标键盘
- 通过一条 TCP 连接发送本地 HID report，并接收远端 HID report
- 把最终仲裁后的鼠标键盘数据写到 USB HID gadget 给手柄

## 1. 硬件检查结果（本机）

已确认：
- SoC/内核：`RK3588`, Linux `5.10.226`
- USB DRD：`usbdrd3_0` 为 `otg`
- Kernel config 启用：`CONFIG_USB_GADGET`, `CONFIG_USB_LIBCOMPOSITE`, `CONFIG_USB_CONFIGFS`, `CONFIG_USB_F_HID`

注意：
- 运行时需要 root 权限去写 `/sys/kernel/config/usb_gadget/*`。
- 需要用 OTG 口把 RK3588 连到 Android（手机做 host）。
- A588 官方文档提示：OTG 口默认可能是 `host`，需切到 `otg` 并重启（本项目脚本已自动尝试切换）。

本板落地部署请优先看：

- `docs/INSTALL_DEPLOY_RK3588.md`

## 2. 目录说明

- `src/usb_mouse_sync.py`：鼠标事件转 HID report（写 `/dev/hidg0`）
- `src/usb_keyboard_sync.py`：键盘事件转 HID report（写 `/dev/hidg1`）
- `src/usb_input_bridge.py`：统一桥接入口，单进程管理鼠标、键盘与 HID gadget
- `src/usb_mouse_sync_api.py`：本地 HTTP 配置 API，读写 `/etc/default/usb-mouse-sync`
- `src/usb_hid_actions.py`：一次性 HID 动作执行器，供 TCP/UDP/HTTP API 调用预设鼠标键盘动作
- `scripts/setup_usb_mouse_gadget.sh`：创建 HID gadget
- `scripts/teardown_usb_mouse_gadget.sh`：卸载 gadget
- `scripts/restore_otg_host_mode.sh`：停止桥接并把 OTG 口切回普通 USB host 模式
- `scripts/start_usb_input_bridge.sh`：统一桥接服务启动参数封装
- `systemd/usb-mouse-sync.service`：统一 systemd 服务；`ENABLE_HID_OUTPUT=1` 时建 gadget，停止后拆 gadget
- `systemd/usb-mouse-sync-api.service`：配置 API 服务
- `config/usb-mouse-sync.env.example`：环境配置模板
- `config/usb-mouse-sync-api.env.example`：配置 API 模板
- `config/actions.json.example`：一次性 HID 动作配置示例
- `docs/HTTP_API.md`：HTTP API 对接说明
- `scripts/install.sh`：安装脚本

## 3. 安装

```bash
cd /home/ztl/mousectl/usb_mouse_sync
chmod +x scripts/*.sh src/*.py
sudo ./scripts/install.sh
```

安装后会同时启用：
- `usb-mouse-sync.service`
- `usb-mouse-sync-api.service`

安装脚本会同时将两个服务设置为开机自启并立即启动。后续修改配置后执行：

```bash
sudo systemctl restart usb-mouse-sync.service usb-mouse-sync-api.service
```

部分 RK3588 系统开机早期 USB role/UDC 还未稳定，首次启动可能无法生成可用的 `/dev/hidg0`、`/dev/hidg1`。安装脚本会额外启用 `usb-mouse-sync-healthcheck.timer`，从开机后约 5 秒开始周期检查服务、Action TCP/UDP 端口、USB role、UDC、HID 节点和主机枚举状态。开机未插 USB 线、运行中拔线或重新插线后，如果 UDC 长时间没有恢复为 `configured`，healthcheck 会自动重新绑定 gadget；必要时才重启主服务。

## 4. 配置

```bash
sudo cp -n config/usb-mouse-sync.env.example /etc/default/usb-mouse-sync
sudo vi /etc/default/usb-mouse-sync
```

关键项：
- `ENABLE_HID_OUTPUT`：`1` 时把最终仲裁后的鼠标键盘数据写到手柄
- `ENABLE_INPUT_BRIDGE`：`1` 时持续采集/网络桥接；`0` 时只保持 gadget，供 TCP/UDP/HTTP 一次性动作使用
- `ENABLE_NETWORK`：`1` 时启用一条 TCP 连接，发送本地 report，接收远端 report
- `ENABLE_ACTION_TCP`：`1` 时启用独立的一次性动作 TCP 服务
- `ACTION_TCP_HOST` / `ACTION_TCP_PORT`：动作 TCP 监听地址和端口，默认 `0.0.0.0:5567`
- `ACTION_TCP_MAX_LINE_BYTES`：单条 JSON Lines 请求最大字节数
- `ACTION_TCP_QUEUE_SIZE`：TCP、UDP 共用的动作串行执行队列长度
- `ENABLE_ACTION_UDP`：`1` 时启用无响应的一次性动作 UDP 服务
- `ACTION_UDP_HOST` / `ACTION_UDP_PORT`：动作 UDP 监听地址和端口，默认 `0.0.0.0:5568`
- `ACTION_UDP_MAX_DATAGRAM_BYTES`：单个 UDP JSON 数据报最大字节数
- `ACTIONS_CONFIG_PATH`：动作配置文件，默认 `/etc/usb-mouse-sync/actions.json`
- `HID_LOCK_PATH`：持续 HID 输入、HTTP 动作、TCP 动作和 UDP 动作共用的跨进程锁文件
- `INPUT_PRIORITY`：`local`、`network`、`auto`
- `LOCAL_IDLE_TIMEOUT_MS`：`INPUT_PRIORITY=local/auto` 时，本地空闲多久后允许网络重新接管
- `UDC_NAME`：可选，固定为 `/sys/class/udc` 下实际名称
- `UDC_CONFIG_TIMEOUT_SEC`：UDC 未进入 `configured` 后等待正常枚举的时间，默认 10 秒
- `UDC_REBIND_COOLDOWN_SEC`：枚举持续异常时强制重绑定的最小间隔，默认 20 秒
- `TCP_START_GRACE_SEC`：开机或服务重启后等待 Action TCP 监听建立的时间，默认 15 秒，避免 healthcheck 与主服务启动竞争
- `UDP_START_GRACE_SEC`：开机或服务重启后等待 Action UDP 监听建立的时间，默认 15 秒
- `EVENT_DEVICE`：可选，固定鼠标设备（如 `/dev/input/event3`）
- `AUTO_REBIND_EVENT`：`1` 时鼠标拔插后自动重新绑定到新的 event 节点（无需重启服务）
- `ENABLE_KEYBOARD_SYNC`：`1` 启用键盘同步（默认）
- `KEYBOARD_EVENT_DEVICE`：可选，固定键盘设备（如 `/dev/input/event4`），留空自动探测
- `AUTO_REBIND_KEYBOARD_EVENT`：`1` 时键盘拔插后自动重绑
- `HID_PROFILE`：`boot3`（默认，兼容性优先）或 `extended5`（含滚轮/横滚）
- `MOVE_SCALE` / `WHEEL_SCALE`：灵敏度调节
- `HOME_ON_CONNECT`：`1` 时每次连上后先把光标“归位”到左上角，减小初始错位
- `HOME_STEPS`：归位强度（默认 24）
- `START_BIAS_X` / `START_BIAS_Y`：归位后额外偏移，可用于微调初始位置
- `MOUSE_MODE`：`relative` 或 `absolute-map`。默认推荐 `relative`（仅看手柄光标时最稳，不依赖板端屏幕坐标/分辨率）。
- `SRC_WIDTH`/`SRC_HEIGHT`：板端分辨率（如 `1920x1080`）
- `SRC_OFFSET_X`/`SRC_OFFSET_Y`：源坐标偏移（多屏扩展桌面时很有用）
- `DST_WIDTH`/`DST_HEIGHT`：手柄/手机分辨率（如 `1280x720`）
- `DST_OFFSET_X`/`DST_OFFSET_Y`：目标有效区域起点（用于去掉边栏/黑边）
- `DST_ACTIVE_WIDTH`/`DST_ACTIVE_HEIGHT`：目标有效区域大小（`0` 代表全屏）
- `USE_CURSOR_QUERY`：`1` 时用 `xdotool` 获取板端真实光标位置做绝对映射（仅 absolute-map 需要）
- `CURSOR_QUERY_CMD`：默认 `xdotool`
- `CURSOR_QUERY_USER`：可选，让服务以该用户身份执行光标查询（推荐填桌面登录用户）
- `CURSOR_DISPLAY`/`CURSOR_XAUTHORITY`/`CURSOR_XDG_RUNTIME_DIR`：可选，显式指定 X11 会话环境
- `CURSOR_TIMEOUT_MS`：光标查询超时，默认 `120`
- `ALIGN_ON_CONNECT`：`1` 时每次 HID 连通后自动做“目标端对齐到源端光标”（仅 absolute-map 有意义）
- `CONNECT_SETTLE_MS`：HID 刚连通后等待一小段时间再发首批 report，避免首包被主机丢弃
- `HOME_ROUNDS`：目标端归位轮数（每轮都会发送一组 `-127,-127`）
- `ALIGN_RETRIES` / `ALIGN_RETRY_INTERVAL_MS`：连接时读取源光标失败的重试次数与间隔
- `ALIGN_STEP_MAX` / `ALIGN_STEP_SLEEP_MS`：连接对齐时每包最大步长与包间间隔；可降低主机侧加速度导致的“对齐过冲”
- `SOURCE_HOME_ON_CONNECT`：`1` 时先把板端光标移动到左上角再映射（可选）
- `STRICT_ABSOLUTE_QUERY`：`1` 时绝对模式下查询失败不再回退相对模式，避免漂移
- `NETWORK_ROLE`：`client` 或 `server`
- `NETWORK_HOST` / `NETWORK_PORT`：网络对端地址或监听地址
- `NETWORK_RETRY_MS`：断线后的重连间隔
- `NETWORK_CONNECT_TIMEOUT_MS`：TCP 建连超时
- `NETWORK_QUEUE_SIZE`：本地 report 发送队列长度

仲裁与网络说明：
- 鼠标和键盘共用一条 TCP 连接，传输的是标准化 HID report，不是原始 `input_event`
- 只有本地采集到的数据会发到网络；从网络收到的数据只会参与本地 HID 输出，不会再回发网络，避免回环
- `INPUT_PRIORITY=local`：本地输入优先；本地空闲 `LOCAL_IDLE_TIMEOUT_MS` 后，网络可接管
- `INPUT_PRIORITY=network`：只要网络连接存在，网络输入优先；本地输入仍可继续发送到远端
- `INPUT_PRIORITY=auto`：谁最近开始活动谁优先；本地空闲超过 `LOCAL_IDLE_TIMEOUT_MS` 后，网络可重新接管
- 两端 `HID_PROFILE` 必须一致，否则鼠标 report 长度会不匹配

实现细节：如果首轮对齐失败，服务会在运行期间继续重试对齐，直到成功，不需要手动重启服务。

## 5. 启动

统一服务 `usb-mouse-sync.service` 在 `ENABLE_HID_OUTPUT=1` 时会自动创建 gadget；普通重启/停止服务会保留 gadget 和 peripheral role，避免健康检查自愈时破坏 USB 枚举。如果 `ENABLE_HID_OUTPUT=0`，则不会创建 gadget：

```bash
sudo systemctl restart usb-mouse-sync.service
sudo systemctl status usb-mouse-sync.service
```

配置 API：

```bash
sudo systemctl restart usb-mouse-sync-api.service
sudo systemctl status usb-mouse-sync-api.service
```

常见用法：

纯发送端，本地 USB 转网络：

```bash
ENABLE_HID_OUTPUT=0
ENABLE_NETWORK=1
INPUT_PRIORITY=local
NETWORK_ROLE=client
NETWORK_HOST=<接收端IP>
NETWORK_PORT=5566
```

接收端，网络转手柄，且即使本地又插上鼠标键盘也保持网络优先：

```bash
ENABLE_HID_OUTPUT=1
ENABLE_NETWORK=1
INPUT_PRIORITY=network
NETWORK_ROLE=server
NETWORK_HOST=0.0.0.0
NETWORK_PORT=5566
```

直接本地 USB 给手柄，不启用网络：

```bash
ENABLE_HID_OUTPUT=1
ENABLE_NETWORK=0
INPUT_PRIORITY=local
```

## 6. 调试

查看 gadget 是否拉起：

```bash
ls /sys/class/udc
ls -l /dev/hidg0
ls -l /dev/hidg1
```

查看日志：

```bash
journalctl -u usb-mouse-sync.service -u usb-mouse-sync-api.service -f
```

如果当前 `ENABLE_HID_OUTPUT=0`，服务不会创建 gadget，可以运行在普通 Linux 电脑上；如果 `ENABLE_HID_OUTPUT=1`，则需要目标机器具备 USB gadget 能力。

## 7. HTTP API

配置 API 默认监听 `127.0.0.1:18081`，配置文件是：

```bash
/etc/default/usb-mouse-sync-api
```

默认不鉴权；如果设置了 `API_AUTH_TOKEN`，调用时需要带：

```bash
Authorization: Bearer <token>
```

接口：
- `GET /health`
- `GET /api/v1/config`
- `GET /api/v1/schema`
- `PATCH /api/v1/config`
- `POST /api/v1/restart`
- `GET /api/v1/actions`
- `POST /api/v1/actions/<name>/run`

读取当前配置：

```bash
curl http://127.0.0.1:18081/api/v1/config
```

修改配置并自动重启主服务：

```bash
curl -X PATCH http://127.0.0.1:18081/api/v1/config \
  -H 'Content-Type: application/json' \
  -d '{
    "values": {
      "ENABLE_NETWORK": "1",
      "INPUT_PRIORITY": "network",
      "NETWORK_ROLE": "server",
      "NETWORK_HOST": "0.0.0.0",
      "NETWORK_PORT": 5566
    },
    "restart": true
  }'
```

只保存配置，不重启：

```bash
curl -X PATCH http://127.0.0.1:18081/api/v1/config \
  -H 'Content-Type: application/json' \
  -d '{
    "values": {
      "ENABLE_NETWORK": "0"
    },
    "restart": false
  }'
```

显式重启主服务：

```bash
curl -X POST http://127.0.0.1:18081/api/v1/restart
```

执行一次性 HID 动作：

```bash
curl -X POST http://127.0.0.1:18081/api/v1/actions/win_run/run \
  -H 'Content-Type: application/json' \
  -d '{
    "params": {
      "cmd": "notepad"
    }
  }'
```

动作配置默认放在 `/etc/usb-mouse-sync/actions.json`。字符串字段支持 `{name}` 占位，调用时从请求的 `params.name` 替换；例如配置里写 `"text": "{cmd}"`，调用时传 `"params": {"cmd": "notepad"}`。

### action.json 编写方法

`actions.json` 顶层必须是一个对象，里面的 `actions` 保存动作名称到动作步骤数组的映射：

```json
{
  "actions": {
    "win_run": [
      {"type": "key_combo", "keys": ["win", "r"], "after_ms": 500},
      {"type": "type_text", "text": "{cmd}"},
      {"type": "key", "key": "enter"}
    ]
  }
}
```

调用时 URL 里的动作名要和 `actions` 里的键一致：

```bash
curl -X POST http://127.0.0.1:18081/api/v1/actions/win_run/run \
  -H 'Content-Type: application/json' \
  -d '{"params":{"cmd":"notepad"}}'
```

占位规则：
- 只有字符串字段会做占位替换，例如 `text`、`key`、`button`。
- 写 `{name}` 表示从 HTTP 或 TCP 请求的 `params.name` 取值。
- 占位名只能包含字母、数字和下划线。
- 如果配置里要输入字面量 `{` 或 `}`，写成 `{{` 或 `}}`。
- 目前 `type_text` 按 US 键盘布局输入 ASCII 字符，不处理中文输入法状态。

每个步骤都必须有 `type`。除 `delay` 外，步骤执行后默认等待 `40ms`；可以用 `after_ms` 覆盖，设为 `0` 表示不额外等待。

支持的步骤：

| type | 用途 | 必填/常用字段 | 示例 |
| --- | --- | --- | --- |
| `delay` | 等待 | `ms` | `{"type":"delay","ms":500}` |
| `key` | 按一次单键 | `key`, 可选 `press_ms`, `after_ms` | `{"type":"key","key":"enter"}` |
| `key_combo` | 按一次组合键 | `keys`, 可选 `press_ms`, `after_ms` | `{"type":"key_combo","keys":["ctrl","alt","delete"]}` |
| `type_text` | 输入文本 | `text`, 可选 `press_ms`, `after_ms` | `{"type":"type_text","text":"abc123"}` |
| `mouse_move` | 相对移动鼠标 | `dx`, `dy`, 可选 `after_ms` | `{"type":"mouse_move","dx":100,"dy":-20}` |
| `mouse_click` | 鼠标点击 | `button`, 可选 `count`, `press_ms`, `after_ms` | `{"type":"mouse_click","button":"left","count":2}` |
| `mouse_scroll` | 鼠标滚轮 | `wheel`, 可选 `hwheel`, `after_ms` | `{"type":"mouse_scroll","wheel":-3}` |

键盘 `key` / `key_combo.keys` 可填值：

| 类型 | 可填值 |
| --- | --- |
| 修饰键 | `ctrl`, `control`, `left_ctrl`, `right_ctrl`, `shift`, `left_shift`, `right_shift`, `alt`, `left_alt`, `right_alt`, `win`, `windows`, `gui`, `left_gui`, `right_gui` |
| 字母数字 | `a` 到 `z`，`0` 到 `9` |
| 常用控制键 | `enter`, `return`, `esc`, `escape`, `backspace`, `tab`, `space`, `capslock` |
| 符号键 | `minus`, `equal`, `left_bracket`, `right_bracket`, `backslash`, `semicolon`, `quote`, `grave`, `comma`, `dot`, `period`, `slash` |
| 功能键 | `f1` 到 `f12` |
| 导航键 | `insert`, `home`, `pageup`, `delete`, `end`, `pagedown`, `right`, `left`, `down`, `up` |
| 其他键 | `printscreen`, `scrolllock`, `pause` |

`type_text.text` 可直接填写的字符：

```text
a-z A-Z 0-9
空格 回车 Tab
! @ # $ % ^ & * ( )
- _ = + [ ] { } \ | ; : ' " ` ~ , < . > / ?
```

鼠标字段对应关系：

| 字段 | 含义 | 可填值 |
| --- | --- | --- |
| `button` | 鼠标按钮 | `left`, `right`, `middle`, `side`, `extra` |
| `count` | 点击次数 | 正整数，默认 `1` |
| `dx` | 水平相对移动 | 整数，正数向右，负数向左 |
| `dy` | 垂直相对移动 | 整数，正数向下，负数向上 |
| `wheel` | 垂直滚轮 | 整数，通常正数向上、负数向下；需要 `HID_PROFILE=extended5` |
| `hwheel` | 水平滚轮 | 整数；需要 `HID_PROFILE=extended5` |
| `press_ms` | 按下保持时间 | 毫秒，默认 `30` |
| `after_ms` | 当前步骤后的等待时间 | 毫秒，默认 `40` |

注意：`HID_PROFILE=boot3` 兼容性最好，适合 Win7 基本键鼠动作，但鼠标 report 只有按钮和 X/Y 移动，不支持 `mouse_scroll`。如果需要滚轮，改用 `HID_PROFILE=extended5` 并重启 `usb-mouse-sync.service`。

除 HTTP API 外，一次性动作也可通过独立 TCP 或 UDP 端口调用。TCP 不复用鼠标键盘 report 的连接，默认监听 `0.0.0.0:5567`，接收 JSON 对象：

```text
{"name":"win_run","params":{"cmd":"notepad"},"request_id":"abc-001"}\n
```

服务返回一行 JSON：

```text
{"ok":true,"action":"win_run","steps":3,"request_id":"abc-001"}\n
```

UDP 默认监听 `0.0.0.0:5568`。每个 UDP 数据报包含一个完整 JSON 对象，不返回响应，也不要求 `request_id`：

```bash
printf '%s' '{"name":"target","params":{"elevate":100,"lat":23,"lon":123}}' \
  > /dev/udp/127.0.0.1/5568
```

TCP 和 UDP 的完整配置见 `docs/HTTP_API.md`。两种传输共用同一个动作 FIFO 队列、`actions.json` 和 `HID_LOCK_PATH`；HTTP 动作以及持续鼠标键盘同步也共用该 HID 锁。

如果目标是 Windows 电脑并只做外部触发动作，推荐：

```bash
ENABLE_HID_OUTPUT=1
ENABLE_INPUT_BRIDGE=0
ENABLE_KEYBOARD_SYNC=1
HID_PROFILE=boot3
```

说明：
- API 以原子方式更新 `/etc/default/usb-mouse-sync`
- 只允许修改受支持的配置键
- JSON 里传 `null` 可删除某个键，让服务回退到默认值或启动脚本默认行为

如果你临时想在不手动执行 `systemctl stop usb-mouse-sync.service` 的情况下直接恢复 OTG 口为普通 USB 口：

```bash
sudo /opt/usb-mouse-sync/scripts/restore_otg_host_mode.sh
```

它会停止当前统一服务 `usb-mouse-sync.service`，拆掉 HID gadget，并尝试把 `fc000000` OTG 口切回 host 模式。
为避免 healthcheck 或 `systemctl restart` 在恢复过程中把 OTG 口切回 host，单独执行 `systemctl stop usb-mouse-sync.service` 只停止进程并保留 gadget。需要恢复普通 USB host 模式时必须执行上述脚本。
如果系统里还残留旧版拆分服务，它也会顺带兼容停止。

查看 UDC 状态（用于判断主机是否真的完成枚举）：

```bash
cat /sys/class/udc/fc000000.usb/state
```
`configured` 代表主机已配置成功，服务会开始稳定写 HID report。

开机时不插 USB 线是允许的。之后插线时，正常情况下 UDC 会直接进入 `configured`；如果 role 或枚举卡住，healthcheck 会在 `UDC_CONFIG_TIMEOUT_SEC` 后只重绑定 UDC，不重建 HID function，也不停止 TCP Action 服务。
如果系统自带的 `rockchip` gadget 在重绑定期间抢占 UDC，脚本会自动解绑占用者并重试接管。

如果提示 `No UDC found`：
- 检查是否接在 OTG 口；
- 检查 Type-C 线是否支持数据；
- 某些板卡要先在设备树或 role switch 把该口切到 peripheral/otg。
- 当前脚本会自动尝试切换 role（`debugfs mode=device` 或 `otg_mode=peripheral`），失败时会在日志里打印 extcon/otg_mode 状态用于定位。
- 脚本支持幂等执行：如果 gadget 已经绑定在目标 UDC，会直接返回成功，不再因为重复绑定报 `Device or resource busy`。

绝对坐标模式下如果日志出现 `Cursor query returned code ... fallback to relative mapping`：
- 说明服务无法访问图形会话，当前会退回相对模式（会有位置漂移）。
- 建议在 `/etc/default/usb-mouse-sync` 增加：
  - `CURSOR_QUERY_USER=<桌面登录用户名>`
  - `CURSOR_DISPLAY=:0`
  - `CURSOR_XAUTHORITY=/run/user/<uid>/gdm/Xauthority`（或该用户的 `.Xauthority`）
  - `CURSOR_XDG_RUNTIME_DIR=/run/user/<uid>`

建议默认组合（只看手柄光标，免标定）：
- `HID_PROFILE=boot3`
- `MOUSE_MODE=relative`
- `USE_CURSOR_QUERY=0`
- `ALIGN_ON_CONNECT=0`
- `HOME_ON_CONNECT=1`

## 8. 已知边界

- 该实现发送标准相对坐标鼠标（非绝对触控）。
- 如果你的鼠标设备有高精度滚轮，会自动把 `HI_RES` 事件按 120 累积换算。
- 服务默认 root 运行（systemd），避免设备权限问题。
- 分辨率映射示例见 `docs/resolution_presets.md`。

## 9. 迁移到新板（一键）

在当前板子打包：

```bash
cd /home/ztl/mousectl/usb_mouse_sync
chmod +x scripts/package_release.sh scripts/one_click_setup.sh
./scripts/package_release.sh --with-current-config
```

会在 `/home/ztl/mousectl/dist` 生成 `usb_mouse_sync_bundle_*.tar.gz`。

在新板子安装：

```bash
tar -xzf usb_mouse_sync_bundle_*.tar.gz
cd usb_mouse_sync_bundle_*/usb_mouse_sync
sudo ./scripts/one_click_setup.sh --config keep
```

说明：
- `--config keep`：保留新板已有 `/etc/default/usb-mouse-sync`，若没有则使用包内配置
- `--config current`：强制使用打包时带上的当前配置（如果存在）
- `--config example`：强制使用模板配置
