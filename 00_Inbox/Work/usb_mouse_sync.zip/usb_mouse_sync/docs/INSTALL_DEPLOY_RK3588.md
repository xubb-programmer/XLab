# RK3588 本板安装部署说明

本文档用于在当前 RK3588 开发板上落地 `usb_mouse_sync`，并覆盖本板已确认的 USB 角色信息与常见问题处理。

## 1. 本板 USB 角色结论

已确认设备树中的控制器模式：

- `usbdrd3_0/usb@fc000000/dr_mode=otg`（可用于 HID gadget / device 模式）
- `usbdrd3_1/usb@fc400000/dr_mode=host`（固定 host）

结论：请把连 Android 的线插在 `fc000000` 对应的 OTG 口，`fc400000` 对应口不能用于 gadget。

快速检查命令：

```bash
for f in /sys/firmware/devicetree/base/usbdrd3_*/usb@*/dr_mode; do
  printf "%s: " "$f"
  tr -d '\0' < "$f"
  echo
done
```

## 2. 部署前准备

1. 进入项目目录：

```bash
cd /home/ztl/mouse/mousectl/usb_mouse_sync
chmod +x scripts/*.sh src/*.py
```

2. 如果你使用 `absolute-map + USE_CURSOR_QUERY=1`，请确认 `xdotool` 已安装（`relative` 默认不需要）：

```bash
command -v xdotool || echo "xdotool missing"
```

如果缺失（Ubuntu 20.04）：

```bash
sudo apt-get update
sudo apt-get install -y xdotool
```

## 3. 一键部署（推荐）

### 方式 A：直接使用 one-click

```bash
cd /home/ztl/mouse/mousectl/usb_mouse_sync
sudo ./scripts/one_click_setup.sh --skip-deps --config keep
```

说明：

- `--skip-deps`：跳过 apt 安装，适合离线环境；若缺依赖再补装。
- `--config keep`：保留已有 `/etc/default/usb-mouse-sync`，不存在时自动写入模板。

### 方式 B：使用本仓库新增的本板部署脚本

```bash
cd /home/ztl/mouse/mousectl/usb_mouse_sync
sudo ./scripts/deploy_local_board.sh --config keep --skip-deps
```

这个脚本会串行执行：安装、服务重启、healthcheck timer 状态检查、日志采样、`/dev/hidg0` 与 UDC state 检查。
键盘同步启用时还会检查 `/dev/hidg1`。
同时也会安装并启用 `usb-mouse-sync-api.service` 和 `usb-mouse-sync-healthcheck.timer`。

## 4. 首次配置建议

部署后检查 `/etc/default/usb-mouse-sync`，建议至少确认：

- `ENABLE_HID_OUTPUT=1`（本板直接给手柄时推荐）
- `ENABLE_NETWORK=0`（如果只是本板直接给手柄）
- `INPUT_PRIORITY=local`
- `HID_PROFILE=boot3`（安卓兼容优先；若无兼容问题可改回 `extended5`）
- `ENABLE_KEYBOARD_SYNC=1`
- `KEYBOARD_EVENT_DEVICE` 留空自动探测（或手工固定）
- `MOUSE_MODE=relative`（默认推荐，免分辨率/边界标定）
- `USE_CURSOR_QUERY=0`
- `STRICT_ABSOLUTE_QUERY=0`
- `ALIGN_ON_CONNECT=0`
- `HOME_ON_CONNECT=1`

如果你要用 `absolute-map` 再启用以下项：

- `USE_CURSOR_QUERY=1`
- `STRICT_ABSOLUTE_QUERY=1`
- `ALIGN_ON_CONNECT=1`
- `CURSOR_QUERY_USER=<桌面登录用户名>`
- `CURSOR_DISPLAY=:0`
- `CURSOR_XAUTHORITY=/run/user/<uid>/gdm/Xauthority`
- `CURSOR_XDG_RUNTIME_DIR=/run/user/<uid>`

如果要固定 UDC，增加：

```bash
UDC_NAME=fc000000.usb
UDC_STATE_PATH=/sys/class/udc/fc000000.usb/state
```

如果这块板要作为网络接收端给手柄，并且希望即使本地插了鼠标键盘也保持网络优先：

```bash
ENABLE_HID_OUTPUT=1
ENABLE_NETWORK=1
INPUT_PRIORITY=network
NETWORK_ROLE=server
NETWORK_HOST=0.0.0.0
NETWORK_PORT=5566
```

如果另一台普通电脑只负责采集并发网络数据：

```bash
ENABLE_HID_OUTPUT=0
ENABLE_NETWORK=1
INPUT_PRIORITY=local
NETWORK_ROLE=client
NETWORK_HOST=<RK3588接收端IP>
NETWORK_PORT=5566
```

注意：
- `ENABLE_HID_OUTPUT=0` 时不会创建 gadget
- 网络两端 `HID_PROFILE` 必须一致

## 5. 部署后验证

```bash
systemctl status usb-mouse-sync.service usb-mouse-sync-api.service usb-mouse-sync-healthcheck.timer --no-pager
journalctl -u usb-mouse-sync.service -u usb-mouse-sync-api.service -u usb-mouse-sync-healthcheck.service -n 120 --no-pager -l
ls -l /dev/hidg0
ls -l /dev/hidg1
cat /sys/class/udc/fc000000.usb/state
```

`state=configured` 通常表示 Android 侧已完成枚举，HID report 写入会稳定。
`usb-mouse-sync-healthcheck.timer` 会周期检查服务、Action TCP/UDP 端口、USB role、UDC、HID 节点和主机枚举状态；状态异常时会先尝试修复 gadget，必要时才重启主服务。开机未插线或运行中拔插 USB 线后，如果 UDC 持续未进入 `configured`，默认等待 10 秒后自动重绑定 gadget，并至少间隔 20 秒才会再次尝试。可通过 `/etc/default/usb-mouse-sync` 中的 `UDC_CONFIG_TIMEOUT_SEC` 和 `UDC_REBIND_COOLDOWN_SEC` 调整。

开机时主服务创建 gadget 和 Action TCP/UDP 监听需要短暂时间。healthcheck 默认通过 `TCP_START_GRACE_SEC=15` 和 `UDP_START_GRACE_SEC=15` 等待监听建立，不会在启动过程中立即误重启主服务。服务重启时保留 gadget 和 peripheral role；只有显式执行 `/opt/usb-mouse-sync/scripts/restore_otg_host_mode.sh` 才会拆除 gadget 并恢复 host 模式。

## 6. 常见问题与处理

1. `No UDC found`

- 确认线接在 OTG 口（`fc000000` 对应口）
- 确认数据线不是充电-only 线
- 先接 Android（host）再启动服务

2. `Cursor query cmd not found (xdotool)`

- 安装 `xdotool`
- 或者直接使用 `MOUSE_MODE=relative` + `USE_CURSOR_QUERY=0`（不依赖板端光标）

3. `Cursor query returned code ... fallback to relative mapping`

- 通常是 X11 环境变量不完整
- 补齐 `CURSOR_QUERY_USER/DISPLAY/XAUTHORITY/XDG_RUNTIME_DIR`

4. `sudo: a terminal is required to read the password`

- 当前 shell 无法交互输入 sudo 密码时，请切换到可交互终端执行本说明命令
- 或先 `sudo -s` 进入 root shell，再执行脚本

5. `UDC fc000000.usb is occupied by gadget: rockchip`

- 该板常见现象，系统自带 `usbdevice` 会创建 `rockchip` gadget 并占用 UDC
- 当前脚本默认 `RECLAIM_UDC=1`，会自动尝试从 `rockchip` 解绑后接管
- 如需禁止自动接管，可在 `/etc/default/usb-mouse-sync` 设置 `RECLAIM_UDC=0`

6. 重启服务耗时接近 1 分钟

- 常见原因是 `usb-mouse-sync.service` 停止超时（systemd 默认约 90 秒），不是 gadget 启动慢
- 本项目已将统一服务 `usb-mouse-sync.service` 设为 `TimeoutStopSec=8`，并把 HID fd 改为非阻塞打开以避免 stop 卡住
- 当前版本在停止 `usb-mouse-sync.service` 时，会自动拆 gadget 并把 OTG 口切回 host 模式
- 更新后重新执行安装脚本即可；安装脚本会自动执行 `daemon-reload`、设置开机自启并启动服务：
  - `sudo ./scripts/install.sh`
