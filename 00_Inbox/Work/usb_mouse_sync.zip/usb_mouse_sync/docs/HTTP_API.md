# HTTP API

本地配置 API 默认监听：

```text
http://127.0.0.1:18081
```

配置文件：

```text
/etc/default/usb-mouse-sync-api
```

如果设置了 `API_AUTH_TOKEN`，请求头需要带：

```text
Authorization: Bearer <token>
```

## Endpoints

### `GET /health`

用途：存活检查

响应示例：

```json
{"ok": true}
```

### `GET /api/v1/config`

用途：读取当前配置和主服务状态

响应示例：

```json
{
  "service": {
    "active": "active",
    "enabled": "enabled"
  },
  "values": {
    "ENABLE_HID_OUTPUT": "1",
    "ENABLE_NETWORK": "1",
    "INPUT_PRIORITY": "network",
    "NETWORK_ROLE": "server",
    "NETWORK_HOST": "0.0.0.0",
    "NETWORK_PORT": "5566",
    "HID_PROFILE": "boot3"
  }
}
```

### `GET /api/v1/schema`

用途：读取支持的配置键和类型约束，方便前端动态生成表单。

### `GET /api/v1/actions`

用途：读取已配置的一次性 HID 动作名称。

动作配置文件默认是：

```text
/etc/usb-mouse-sync/actions.json
```

### `PATCH /api/v1/config`

用途：部分更新配置，可选是否自动重启 `usb-mouse-sync.service`。

请求体格式：

```json
{
  "values": {
    "ENABLE_NETWORK": "1",
    "INPUT_PRIORITY": "network",
    "NETWORK_ROLE": "server",
    "NETWORK_HOST": "0.0.0.0",
    "NETWORK_PORT": 5566
  },
  "restart": true
}
```

说明：
- `values` 必填，且只需要带要修改的字段，不需要把所有字段都带上
- `restart` 可选，默认 `true`
- 传 `null` 表示删除某个键，让服务回退到默认值或启动脚本默认行为

示例：修改配置并自动重启

```bash
curl -X PATCH http://127.0.0.1:18081/api/v1/config \
  -H 'Content-Type: application/json' \
  -d '{
    "values": {
      "ENABLE_NETWORK": "1",
      "INPUT_PRIORITY": "network",
      "NETWORK_ROLE": "server",
      "NETWORK_HOST": "0.0.0.0",
      "NETWORK_PORT": 5566
    },
    "restart": true
  }'
```

示例：只保存，不重启

```bash
curl -X PATCH http://127.0.0.1:18081/api/v1/config \
  -H 'Content-Type: application/json' \
  -d '{
    "values": {
      "ENABLE_NETWORK": "0"
    },
    "restart": false
  }'
```

### `POST /api/v1/restart`

用途：显式重启 `usb-mouse-sync.service`

示例：

```bash
curl -X POST http://127.0.0.1:18081/api/v1/restart
```

### `POST /api/v1/actions/<name>/run`

用途：外部调用一次，按预设动作向目标电脑发送鼠标键盘 HID report。

该 HTTP 接口继续保留。除 HTTP 外，也可以使用主服务独立监听的 TCP 或 UDP 动作端口，协议见本文末尾。

请求体格式：

```json
{
  "params": {
    "cmd": "notepad"
  }
}
```

示例：

```bash
curl -X POST http://127.0.0.1:18081/api/v1/actions/win_run/run \
  -H 'Content-Type: application/json' \
  -d '{
    "params": {
      "cmd": "notepad"
    }
  }'
```

动作配置示例：

```json
{
  "actions": {
    "win_run": [
      {"type": "key_combo", "keys": ["win", "r"], "after_ms": 500},
      {"type": "type_text", "text": "{cmd}"},
      {"type": "key", "key": "enter"}
    ]
  }
}
```

占位说明：
- 字符串字段支持 `{name}` 占位，调用时从 `params.name` 替换。
- 如果配置里需要字面量 `{` 或 `}`，写成 `{{` 或 `}}`。
- 目前文本输入按 US 键盘布局发送 ASCII 字符，不处理中文输入法状态。

支持动作：
- `key`：`{"type":"key","key":"enter"}`
- `key_combo`：`{"type":"key_combo","keys":["ctrl","alt","delete"]}`
- `type_text`：`{"type":"type_text","text":"abc123"}`
- `mouse_move`：`{"type":"mouse_move","dx":100,"dy":50}`
- `mouse_click`：`{"type":"mouse_click","button":"left","count":1}`
- `mouse_scroll`：`{"type":"mouse_scroll","wheel":-3}`，需要 `HID_PROFILE=extended5`
- `delay`：`{"type":"delay","ms":500}`

如果只使用一次性动作，建议主配置：

```bash
ENABLE_HID_OUTPUT=1
ENABLE_INPUT_BRIDGE=0
ENABLE_KEYBOARD_SYNC=1
HID_PROFILE=boot3
```

## TCP Action API

一次性动作支持独立 TCP 端口，默认监听 `0.0.0.0:5567`。它不复用鼠标键盘 HID report 的 TCP 连接和端口。

配置项：

```bash
ENABLE_ACTION_TCP=1
ACTION_TCP_HOST=0.0.0.0
ACTION_TCP_PORT=5567
ACTION_TCP_MAX_LINE_BYTES=16384
ACTION_TCP_QUEUE_SIZE=32
```

TCP 接收 JSON 对象。推荐每条请求以换行符结束；服务端也兼容多行 pretty JSON。

```json
{"name":"win_run","params":{"cmd":"notepad"},"request_id":"abc-001"}
```

字段：

- `name`：`/etc/usb-mouse-sync/actions.json` 中的动作名称
- `params`：动作模板参数，例如 `{cmd}`、`{latitude}`、`{longitude}`；动作配置中的占位符可由 TCP 或 HTTP 请求提供
- `request_id`：可选，服务会原样放入响应

响应是一行 JSON。成功示例：

```json
{"ok":true,"action":"win_run","steps":3,"request_id":"abc-001"}
```

失败示例：

```json
{"ok":false,"error":"missing template param: cmd","request_id":"abc-001"}
```

动作由独立 worker 串行执行，TCP/UDP 接收线程不会直接执行动作。TCP 和 UDP 共用同一个 FIFO 动作队列；TCP、UDP、HTTP 动作和持续鼠标键盘同步共用 `HID_LOCK_PATH` 指定的跨进程锁，避免多个动作或普通输入同时写入 HID 设备。

TCP 动作服务不提供鉴权。若端口需要远程访问，建议通过防火墙限制来源；只允许本机访问时设置：

```bash
ACTION_TCP_HOST=127.0.0.1
```

只使用一次性动作时：

```bash
ENABLE_HID_OUTPUT=1
ENABLE_INPUT_BRIDGE=0
ENABLE_NETWORK=0
ENABLE_ACTION_TCP=1
ENABLE_ACTION_UDP=1
```

## UDP Action API

一次性动作同时支持无连接、无响应的 UDP 入口，默认监听 `0.0.0.0:5568`。TCP 入口 `0.0.0.0:5567` 保持不变。

配置项：

```bash
ENABLE_ACTION_UDP=1
ACTION_UDP_HOST=0.0.0.0
ACTION_UDP_PORT=5568
ACTION_UDP_MAX_DATAGRAM_BYTES=16384
```

每个 UDP 数据报必须包含一个完整 JSON 对象。格式与 TCP 请求相同，但 `request_id` 可以省略：

```json
{
  "name": "target",
  "params": {
    "elevate": 100,
    "lat": 23,
    "lon": 123
  }
}
```

Bash 本机测试示例：

```bash
printf '%s' '{"name":"target","params":{"elevate":100,"lat":23,"lon":123}}' \
  > /dev/udp/127.0.0.1/5568
```

UDP 服务不会发送成功或失败响应。无效 JSON、未知动作、参数缺失、队列已满或 HID 执行失败只记录到 `usb-mouse-sync.service` 日志。UDP 不做去重，同一数据报如果被发送多次，动作也会执行多次。

TCP 与 UDP 请求进入同一个 FIFO 队列，队列长度继续由 `ACTION_TCP_QUEUE_SIZE` 控制。

## Error Cases

- `400`：请求体非法、字段名不支持、字段值不合法
- `401`：开启 token 鉴权但未提供正确的 `Authorization`
- `404`：接口路径不存在
- `500`：配置写入成功但重启服务失败、动作配置非法、HID 设备不可写或动作执行失败
